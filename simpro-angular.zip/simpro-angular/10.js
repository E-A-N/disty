(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[10],{

/***/ "./node_modules/browser-nativefs/dist/legacy/file-open.mjs":
/*!*****************************************************************!*\
  !*** ./node_modules/browser-nativefs/dist/legacy/file-open.mjs ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(__webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// @license © 2020 Google LLC. Licensed under the Apache License, Version 2.0.
/* harmony default export */ __webpack_exports__["default"] = (async(e={})=>new Promise((t=>{const i=document.createElement("input");i.type="file";const n=[...e.mimeTypes?e.mimeTypes:[],e.extensions?e.extensions:[]].join();i.multiple=e.multiple||!1,i.accept=n||"*/*",i.addEventListener("change",(()=>{t(i.multiple?i.files:i.files[0])})),i.click()})));

/***/ })

}]);
//# sourceMappingURL=10.js.map