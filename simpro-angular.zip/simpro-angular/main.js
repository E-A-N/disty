(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-SG": "./node_modules/moment/locale/en-SG.js",
	"./en-SG.js": "./node_modules/moment/locale/en-SG.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) { // check for number or string
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return id;
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./node_modules/webpack/buildin/global.js":
/*!***********************************!*\
  !*** (webpack)/buildin/global.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || new Function("return this")();
} catch (e) {
	// This works if the window reference is available
	if (typeof window === "object") g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _user_user_list_user_list_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./user/user-list/user-list.component */ "./src/app/user/user-list/user-list.component.ts");
/* harmony import */ var _scenario_scenario_scenario_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./scenario/scenario/scenario.component */ "./src/app/scenario/scenario/scenario.component.ts");






var routes = [
    { path: '', redirectTo: '/preference', pathMatch: 'full' },
    { path: 'login', component: _login_login_component__WEBPACK_IMPORTED_MODULE_3__["LoginComponent"] },
    { path: 'client-accounts', component: _user_user_list_user_list_component__WEBPACK_IMPORTED_MODULE_4__["UserListComponent"] },
    { path: 'scenario', component: _scenario_scenario_scenario_component__WEBPACK_IMPORTED_MODULE_5__["ScenarioComponent"] },
    { path: '**', redirectTo: '/preference' }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { useHash: true })],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--The content below is only a placeholder and can be replaced.-->\n<div class=\"wrapper\">\n\n    <div *ngIf=\"!uAuthService.isloggedIn()\">\n        <app-login></app-login>\n    </div>\n    <div *ngIf=\"uAuthService.isloggedIn()\">\n        <div>\n            <app-header></app-header>\n            <app-home></app-home>\n        </div>\n\n\n    </div>\n\n</div>\n\n\n\n\n\n\n\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _connection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./connection.service */ "./src/app/connection.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var _service_user_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./service/user-auth.service */ "./src/app/service/user-auth.service.ts");
/* harmony import */ var _startup_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./startup.service */ "./src/app/startup.service.ts");
/* harmony import */ var _service_utilities_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./service/utilities.service */ "./src/app/service/utilities.service.ts");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/fesm5/ngx-spinner.js");
/* harmony import */ var _service_users_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./service/users.service */ "./src/app/service/users.service.ts");
/* harmony import */ var _core_header_header_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./core/header/header.service */ "./src/app/core/header/header.service.ts");











// interface myData {
//   obj: Object;
// }
var AppComponent = /** @class */ (function () {
    // Dependency injection of service
    function AppComponent(spinner, svc, http, utilityService, uAuthService, startupService, utilitiesService, usersService, headerService) {
        var _this = this;
        this.spinner = spinner;
        this.svc = svc;
        this.http = http;
        this.utilityService = utilityService;
        this.uAuthService = uAuthService;
        this.startupService = startupService;
        this.utilitiesService = utilitiesService;
        this.usersService = usersService;
        this.headerService = headerService;
        this.title = 'simpro-angular';
        this.isInitialLoad = false;
        this.isFinishedLoading = false;
        this.counter = 0;
        this.utilitiesService.utilities$.subscribe(function (utls) {
            _this.utlList = utls;
        });
        document.getElementById('loading').style.display = 'none';
        this.getUsers().then(function (response1) {
            if (_this.uAuthService.getLevel() === '1') {
                _this.spinner.show();
                // Get utility id associated to user
                _this.getUserUtilities().then(function (res) { return _this.headerService.setInitialUtility(); });
                setTimeout(function () {
                    // this.headerService.setInitialUtility();
                    _this.spinner.hide();
                }, 2000);
            }
            setTimeout(function () {
                _this.headerService.setInitialUtility();
            }, 2000);
        });
    }
    AppComponent.prototype.ngOnInit = function () {
    };
    AppComponent.prototype.ngAfterContentInit = function () {
    };
    AppComponent.prototype.ngAfterViewInit = function () {
    };
    AppComponent.prototype.getUsers = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new Promise(function (resolve, reject) {
                            _this.svc.doGet('api/users/').subscribe(function (response) {
                                _this.response = Object.values(response);
                                _this.users = _this.response[0];
                                _this.usersService.setUsers(_this.response[0]);
                                resolve(true);
                            }, function (err) {
                            });
                        })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    AppComponent.prototype.getUtilities = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new Promise(function (resolve, reject) {
                            if (_this.uAuthService.getLevel() === '1') {
                                // Get utility id associated to user
                                _this.spinner.show();
                                _this.utilitiesService.resetUtilities();
                                var user_1 = _this.users.filter(function (usr) { return usr.user === _this.uAuthService.getUser(); });
                                var _loop_1 = function (i) {
                                    _this.svc.doGet('api/utility/' + user_1[0].accesUtilitiesName[i].id).subscribe(function (response) {
                                        var data = Object.values(response)[0];
                                        _this.utilitiesService.addUtilities(user_1[0].accesUtilitiesName[i].id, user_1[0].accesUtilitiesName[i].name, user_1[0].accesUtilitiesName[i].name.split('_upload')[0], data[0]);
                                    });
                                };
                                for (var i in user_1[0].accesUtilitiesName) {
                                    _loop_1(i);
                                }
                                _this.spinner.hide();
                                _this.isFinishedLoading = true;
                            }
                            else {
                                _this.svc.doGet('api/utilities').subscribe(function (response) {
                                    var data = Object.values(response)[0];
                                    _this.utilitiesService.resetUtilities();
                                    for (var i = 0; i < data.length; i++) {
                                        _this.utilitiesService.addUtilities(data[i].id, data[i].name, data[i].name.toString().split('_upload')[0], data[i].utlXml);
                                    }
                                }, function (err) {
                                });
                            }
                            resolve(true);
                        })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    AppComponent.prototype.getUserUtilities = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new Promise(function (resolve, reject) {
                            var user = _this.users.filter(function (usr) { return usr.user === _this.uAuthService.getUser(); });
                            var utlList = _this.utlList;
                            _this.utilitiesService.resetUtilities();
                            var _loop_2 = function (i) {
                                var data = utlList.filter(function (utl) { return utl.name === user[0].accesUtilitiesName[i].name; });
                                _this.utilitiesService.addUtilities(user[0].accesUtilitiesName[i].id, user[0].accesUtilitiesName[i].name, user[0].accesUtilitiesName[i].name.split('_upload')[0], data[0].utl_xml);
                            };
                            for (var i in user[0].accesUtilitiesName) {
                                _loop_2(i);
                            }
                            resolve(true);
                        })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ngx_spinner__WEBPACK_IMPORTED_MODULE_8__["NgxSpinnerService"],
            _connection_service__WEBPACK_IMPORTED_MODULE_2__["ConnectionService"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"],
            _service_utility_service__WEBPACK_IMPORTED_MODULE_4__["UtilityService"],
            _service_user_auth_service__WEBPACK_IMPORTED_MODULE_5__["UserAuthService"],
            _startup_service__WEBPACK_IMPORTED_MODULE_6__["StartupService"],
            _service_utilities_service__WEBPACK_IMPORTED_MODULE_7__["UtilitiesService"],
            _service_users_service__WEBPACK_IMPORTED_MODULE_9__["UsersService"],
            _core_header_header_service__WEBPACK_IMPORTED_MODULE_10__["HeaderService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: startupServiceFactory, AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "startupServiceFactory", function() { return startupServiceFactory; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _connection_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./connection.service */ "./src/app/connection.service.ts");
/* harmony import */ var _core_core_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./core/core.module */ "./src/app/core/core.module.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _startup_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./startup.service */ "./src/app/startup.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/fesm5/ngx-spinner.js");
/* harmony import */ var _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @syncfusion/ej2-angular-charts */ "./node_modules/@syncfusion/ej2-angular-charts/@syncfusion/ej2-angular-charts.es5.js");
/* harmony import */ var _scenario_scenario_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./scenario/scenario.module */ "./src/app/scenario/scenario.module.ts");
/* harmony import */ var _resizable_resizable_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./resizable/resizable.module */ "./src/app/resizable/resizable.module.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_material_table__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/table */ "./node_modules/@angular/material/esm5/table.es5.js");



















function startupServiceFactory(startupService) {
    return function () { return startupService.load(); };
}
var AppModule = /** @class */ (function () {
    // Starting point
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"],
                _login_login_component__WEBPACK_IMPORTED_MODULE_9__["LoginComponent"],
                _home_home_component__WEBPACK_IMPORTED_MODULE_10__["HomeComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _core_core_module__WEBPACK_IMPORTED_MODULE_7__["CoreModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"],
                ngx_spinner__WEBPACK_IMPORTED_MODULE_13__["NgxSpinnerModule"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_14__["ChartModule"],
                _scenario_scenario_module__WEBPACK_IMPORTED_MODULE_15__["ScenarioModule"],
                _resizable_resizable_module__WEBPACK_IMPORTED_MODULE_16__["ResizableModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_17__["BrowserAnimationsModule"],
                _angular_material_table__WEBPACK_IMPORTED_MODULE_18__["MatTableModule"]
            ],
            providers: [
                _angular_common__WEBPACK_IMPORTED_MODULE_12__["DatePipe"],
                _connection_service__WEBPACK_IMPORTED_MODULE_6__["ConnectionService"],
                {
                    provide: _angular_core__WEBPACK_IMPORTED_MODULE_2__["APP_INITIALIZER"],
                    useFactory: startupServiceFactory,
                    deps: [_startup_service__WEBPACK_IMPORTED_MODULE_11__["StartupService"]],
                    multi: true
                }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]]
        })
        // Starting point
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/auth.guard.ts":
/*!*******************************!*\
  !*** ./src/app/auth.guard.ts ***!
  \*******************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _service_user_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./service/user-auth.service */ "./src/app/service/user-auth.service.ts");




var AuthGuard = /** @class */ (function () {
    function AuthGuard(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    AuthGuard.prototype.canActivate = function (next, state) {
        var url = state.url;
        return this.checkUserLevel(next, url);
    };
    AuthGuard.prototype.canActivateChild = function (next, state) {
        return this.canActivate(next, state);
        // return this.checkUserLevel(next, state.url);
    };
    AuthGuard.prototype.canLoad = function (route, segments) {
        return true;
    };
    AuthGuard.prototype.checkUserLogin = function (route, url) {
        if (this.authService.isLoggedIn()) {
            var userRole = this.authService.getRole();
            if (route.data.role && route.data.role.indexOf(userRole) === -1) {
                this.router.navigate(['/preference']);
                return false;
            }
            return true;
        }
        this.router.navigate(['/preference']);
        return false;
    };
    AuthGuard.prototype.checkUserLevel = function (route, url) {
        if (this.authService.getEnableElasticity()) {
            return true;
        }
        this.router.navigate(['']);
        return false;
    };
    AuthGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_service_user_auth_service__WEBPACK_IMPORTED_MODULE_3__["UserAuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], AuthGuard);
    return AuthGuard;
}());



/***/ }),

/***/ "./src/app/connection.service.ts":
/*!***************************************!*\
  !*** ./src/app/connection.service.ts ***!
  \***************************************/
/*! exports provided: ConnectionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConnectionService", function() { return ConnectionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_3__);




var ConnectionService = /** @class */ (function () {
    function ConnectionService(http) {
        this.http = http;
        //url = "http://54.91.165.25/";
        //url = 'http://localhost:8000/';
        this.url = "https://52.45.76.127";
    }
    //url = 'https://simprov2-server.tmtgonline.com/';
    ConnectionService.prototype.doRequest = function (user, passwd, salt, param) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
        //const encodedPassword = this.EncodePassword(passwd, salt);
        var encodedPassword = this.EncodePasswordMD5(passwd, salt);
        var xwsse = this.BuildXWsseHeader(user, '' + encodedPassword);
        headers = headers.append('Authorization', 'Authorization profile="UsernameToken"');
        headers = headers.append('x-wsse', xwsse);
        return this.http.get(this.url + param, { headers: headers });
    };
    ConnectionService.prototype.doPost = function (path, data) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
        headers = headers.append('Accept', 'application/json');
        headers = headers.append('Access-Control-Allow-Origin', '*');
        headers = headers.append('Access-Control-Allow-Methods', 'POST, PUT, GET, OPTIONS, DELETE');
        return this.http.post(this.url + path, JSON.stringify(data), { headers: headers });
    };
    ConnectionService.prototype.doGet = function (path) {
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]();
        return this.http.get(this.url + path, { headers: headers });
    };
    ConnectionService.prototype.intercept = function (request, next) {
        request = request.clone({
            setHeaders: {
                Authorization: 'Api-Key '
            }
        });
        return next.handle(request);
    };
    ConnectionService.prototype.BuildXWsseHeader = function (username, passwordEncoded) {
        var nonce = this.GenerateNonce();
        var createdDate = this.GenerateCreatedDate();
        //const passwordDigest = this.GeneratePasswordDigest(nonce, createdDate, passwordEncoded);
        var passwordDigest = this.GeneratePasswordDOMDigest(nonce, createdDate, passwordEncoded);
        // tslint:disable-next-line:max-line-length
        return 'UsernameToken Username="' + username + '", PasswordDigest="' + passwordDigest + '", Nonce="' + nonce + '", Created="' + createdDate + '"';
    };
    ConnectionService.prototype.GenerateNonce = function () {
        var nonce = Math.random().toString(36).substring(2);
        return crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8.parse(nonce).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Base64);
    };
    ConnectionService.prototype.GeneratePasswordDigest = function (nonce, createdDate, passwordEncoded) {
        var nonce64 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Base64.parse(nonce);
        //let debugDNONCE = nonce64.toString(CryptoJS.enc.Base64);
        var sha1 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["SHA1"](nonce64.concat(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8.parse(createdDate).concat(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8.parse(passwordEncoded))));
        var result = sha1.toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Base64);
        return result;
    };
    ConnectionService.prototype.GeneratePasswordDOMDigest = function (nonce, createdDate, passwordEncoded) {
        var decodeNonce = atob(nonce);
        var sha1 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["SHA1"](decodeNonce + createdDate + passwordEncoded);
        var rawDigest = sha1.toString();
        var result = btoa(rawDigest);
        return result;
    };
    ConnectionService.prototype.EncodePasswordMD5 = function (pass, salt) {
        // pass = "1234";
        // salt = "frdqwy0ey884sokcw4ogwsw84s440cs";
        var salted = pass + '{' + salt + '}';
        var encoded = crypto_js__WEBPACK_IMPORTED_MODULE_3__["MD5"](salted).toString();
        return encoded;
    };
    ConnectionService.prototype.GenerateCreatedDate = function () {
        return new Date().toISOString();
    };
    ConnectionService.prototype.EncodePassword = function (password, salt) {
        var salted = password + '{' + salt + '}';
        var passwordEncoded = crypto_js__WEBPACK_IMPORTED_MODULE_3__["SHA512"](salted);
        for (var i = 1; i < 5000; i++) {
            passwordEncoded = crypto_js__WEBPACK_IMPORTED_MODULE_3__["SHA512"](passwordEncoded.toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Latin1).concat(salted));
        }
        passwordEncoded = crypto_js__WEBPACK_IMPORTED_MODULE_3__["SHA512"](passwordEncoded.toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Latin1).concat(salted));
        return passwordEncoded.toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Base64);
    };
    ConnectionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], ConnectionService);
    return ConnectionService;
}());



/***/ }),

/***/ "./src/app/core/core-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/core/core-routing.module.ts ***!
  \*********************************************/
/*! exports provided: CoreRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoreRoutingModule", function() { return CoreRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _utility_utility_list_utility_list_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utility/utility-list/utility-list.component */ "./src/app/utility/utility-list/utility-list.component.ts");
/* harmony import */ var _user_user_list_user_list_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../user/user-list/user-list.component */ "./src/app/user/user-list/user-list.component.ts");
/* harmony import */ var _preference_preference_preference_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../preference/preference/preference.component */ "./src/app/preference/preference/preference.component.ts");
/* harmony import */ var _preference_ideal_preference_ideal_preference_ideal_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../preference-ideal/preference-ideal/preference-ideal.component */ "./src/app/preference-ideal/preference-ideal/preference-ideal.component.ts");
/* harmony import */ var _elasticity_elasticity_elasticity_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../elasticity/elasticity/elasticity.component */ "./src/app/elasticity/elasticity/elasticity.component.ts");
/* harmony import */ var _sensitivity_sensitivity_sensitivity_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../sensitivity/sensitivity/sensitivity.component */ "./src/app/sensitivity/sensitivity/sensitivity.component.ts");
/* harmony import */ var _auth_guard__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../auth.guard */ "./src/app/auth.guard.ts");











var routes = [
    { path: 'client-accounts', component: _user_user_list_user_list_component__WEBPACK_IMPORTED_MODULE_5__["UserListComponent"] },
    { path: 'utility', component: _utility_utility_list_utility_list_component__WEBPACK_IMPORTED_MODULE_4__["UtilityListComponent"] },
    { path: 'preference', component: _preference_preference_preference_component__WEBPACK_IMPORTED_MODULE_6__["PreferenceComponent"] },
    { path: 'preference-ideal', component: _preference_ideal_preference_ideal_preference_ideal_component__WEBPACK_IMPORTED_MODULE_7__["PreferenceIdealComponent"] },
    { path: 'elasticity', component: _elasticity_elasticity_elasticity_component__WEBPACK_IMPORTED_MODULE_8__["ElasticityComponent"],
        canActivate: [_auth_guard__WEBPACK_IMPORTED_MODULE_10__["AuthGuard"]] },
    { path: 'sensitivity', component: _sensitivity_sensitivity_sensitivity_component__WEBPACK_IMPORTED_MODULE_9__["SensitivityComponent"] }
];
var CoreRoutingModule = /** @class */ (function () {
    function CoreRoutingModule() {
    }
    CoreRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forRoot(routes),
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"]]
        })
    ], CoreRoutingModule);
    return CoreRoutingModule;
}());



/***/ }),

/***/ "./src/app/core/core.module.ts":
/*!*************************************!*\
  !*** ./src/app/core/core.module.ts ***!
  \*************************************/
/*! exports provided: CoreModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoreModule", function() { return CoreModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./header/header.component */ "./src/app/core/header/header.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _core_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./core-routing.module */ "./src/app/core/core-routing.module.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var _service_product_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../service/product.service */ "./src/app/service/product.service.ts");
/* harmony import */ var _service_scenario_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../service/scenario.service */ "./src/app/service/scenario.service.ts");
/* harmony import */ var _service_utilities_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../service/utilities.service */ "./src/app/service/utilities.service.ts");
/* harmony import */ var _service_user_auth_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../service/user-auth.service */ "./src/app/service/user-auth.service.ts");
/* harmony import */ var ng2_charts__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ng2-charts */ "./node_modules/ng2-charts/fesm5/ng2-charts.js");
/* harmony import */ var _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./navbar/navbar.component */ "./src/app/core/navbar/navbar.component.ts");
/* harmony import */ var _utility_utility_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../utility/utility.module */ "./src/app/utility/utility.module.ts");
/* harmony import */ var _user_user_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../user/user.module */ "./src/app/user/user.module.ts");
/* harmony import */ var _preference_preference_module__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../preference/preference.module */ "./src/app/preference/preference.module.ts");
/* harmony import */ var _preference_ideal_preference_ideal_module__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../preference-ideal/preference-ideal.module */ "./src/app/preference-ideal/preference-ideal.module.ts");
/* harmony import */ var _elasticity_elasticity_module__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../elasticity/elasticity.module */ "./src/app/elasticity/elasticity.module.ts");
/* harmony import */ var _sensitivity_sensitivity_module__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../sensitivity/sensitivity.module */ "./src/app/sensitivity/sensitivity.module.ts");
/* harmony import */ var _resizable_resizable_module__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../resizable/resizable.module */ "./src/app/resizable/resizable.module.ts");






















var CoreModule = /** @class */ (function () {
    function CoreModule() {
    }
    CoreModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_header_header_component__WEBPACK_IMPORTED_MODULE_3__["HeaderComponent"], _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_14__["NavbarComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _core_routing_module__WEBPACK_IMPORTED_MODULE_6__["CoreRoutingModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_7__["NgbModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"],
                ng2_charts__WEBPACK_IMPORTED_MODULE_13__["ChartsModule"],
                _utility_utility_module__WEBPACK_IMPORTED_MODULE_15__["UtilityModule"],
                _user_user_module__WEBPACK_IMPORTED_MODULE_16__["UserModule"],
                _preference_preference_module__WEBPACK_IMPORTED_MODULE_17__["PreferenceModule"],
                _preference_ideal_preference_ideal_module__WEBPACK_IMPORTED_MODULE_18__["PreferenceIdealModule"],
                _elasticity_elasticity_module__WEBPACK_IMPORTED_MODULE_19__["ElasticityModule"],
                _sensitivity_sensitivity_module__WEBPACK_IMPORTED_MODULE_20__["SensitivityModule"],
                _resizable_resizable_module__WEBPACK_IMPORTED_MODULE_21__["ResizableModule"]
            ],
            exports: [
                // HomeComponent,
                _header_header_component__WEBPACK_IMPORTED_MODULE_3__["HeaderComponent"],
                // LoginComponent,
                _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_14__["NavbarComponent"]
            ],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"]],
            providers: [
                _service_utility_service__WEBPACK_IMPORTED_MODULE_8__["UtilityService"],
                _service_product_service__WEBPACK_IMPORTED_MODULE_9__["ProductService"],
                _service_scenario_service__WEBPACK_IMPORTED_MODULE_10__["ScenarioService"],
                _service_utilities_service__WEBPACK_IMPORTED_MODULE_11__["UtilitiesService"],
                _service_user_auth_service__WEBPACK_IMPORTED_MODULE_12__["UserAuthService"]
            ]
        })
    ], CoreModule);
    return CoreModule;
}());



/***/ }),

/***/ "./src/app/core/header/header.component.css":
/*!**************************************************!*\
  !*** ./src/app/core/header/header.component.css ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n\r\n.main-header{\r\n    /*box-shadow: 5px 5px 5px grey;*/\r\n    height: 15%;\r\n    display: -webkit-box;\r\n    display: flex;\r\n    padding-left: 0px !important;\r\n\r\n}\r\n.nav{\r\n\r\n}\r\n.topnav {\r\n    overflow: hidden;\r\n    background-color: #ddd;\r\n    width: 100%;\r\n}\r\n.topnav a {\r\n    float: left;\r\n    display: block;\r\n    color: black;\r\n    text-align: center;\r\n    padding: 10px 10px;\r\n    text-decoration: none;\r\n    font-size: 14px;\r\n}\r\n.topnav a:hover {\r\n    background-color: #f2f2f2;\r\n    color: black;\r\n}\r\n.topnav a.active {\r\n    background-color: #4b4b4b;\r\n    color: white;\r\n}\r\n.shadow {\r\n    box-shadow: 0 3px 5px rgba(57, 63, 72, 0.3);\r\n}\r\n.topnav .icon {\r\n    display: none;\r\n}\r\n@media screen and (max-width: 600px) {\r\n    .topnav a:not(:first-child) {display: none;}\r\n    .topnav a.icon {\r\n        float: right;\r\n        display: block;\r\n    }\r\n}\r\n@media screen and (max-width: 600px) {\r\n    .topnav.responsive {position: relative;}\r\n    .topnav.responsive .icon {\r\n        position: absolute;\r\n        right: 0;\r\n        top: 0;\r\n    }\r\n    .topnav.responsive a {\r\n        float: none;\r\n        display: block;\r\n        text-align: left;\r\n    }\r\n}\r\n/*.navlink{*/\r\n/*    color: #4b4b4b;*/\r\n/*    font-family: Lato;*/\r\n/*    font-size: 1em !important;*/\r\n/*    font-style: normal;*/\r\n/*    align: center;*/\r\n/*    justify-content: space-around;*/\r\n/*}*/\r\n/*.navlink:hover{*/\r\n/*    background-color: #d3d3d3;*/\r\n/*    justify-content: space-around;*/\r\n/*}*/\r\n/*.navlink:active{*/\r\n/*    background-color: #d3d3d3;*/\r\n/*    justify-content: space-around;*/\r\n/*}*/\r\n.btn-primary {\r\n    background-color: #2a6496;;\r\n    border-color: #2a6496;\r\n}\r\n/*.btn-blk {*/\r\n/*    background-color: #4b4b4b;*/\r\n/*    border-color: #4b4b4b;*/\r\n/*    color: #F0F0F0;*/\r\n/*    justify-content: space-around;*/\r\n/*    font-size: 1em;*/\r\n/*}*/\r\ntable {\r\n    width: 100%;\r\n    font: 14px Verdana;\r\n    table-layout: fixed;\r\n}\r\ntable, th, td {\r\n    border: solid 1px #999999;\r\n    border-collapse: collapse;\r\n    padding: 2px 3px;\r\n    text-align: center;\r\n    font-family: Lato, sans-serif;\r\n}\r\nth {\r\n    font-weight: bold;\r\n}\r\ntable tr.highlight {\r\n    background-color: #4b4b4b !important;\r\n    color: #ffffff;\r\n}\r\na.disabled {\r\n    pointer-events: none;\r\n    cursor: default;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29yZS9oZWFkZXIvaGVhZGVyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQTtJQUNJLGdDQUFnQztJQUNoQyxXQUFXO0lBQ1gsb0JBQWE7SUFBYixhQUFhO0lBQ2IsNEJBQTRCOztBQUVoQztBQUNBOztBQUVBO0FBQ0E7SUFDSSxnQkFBZ0I7SUFDaEIsc0JBQXNCO0lBQ3RCLFdBQVc7QUFDZjtBQUVBO0lBQ0ksV0FBVztJQUNYLGNBQWM7SUFDZCxZQUFZO0lBQ1osa0JBQWtCO0lBQ2xCLGtCQUFrQjtJQUNsQixxQkFBcUI7SUFDckIsZUFBZTtBQUNuQjtBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEI7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCO0FBRUE7SUFHSSwyQ0FBMkM7QUFDL0M7QUFFQTtJQUNJLGFBQWE7QUFDakI7QUFFQTtJQUNJLDZCQUE2QixhQUFhLENBQUM7SUFDM0M7UUFDSSxZQUFZO1FBQ1osY0FBYztJQUNsQjtBQUNKO0FBRUE7SUFDSSxvQkFBb0Isa0JBQWtCLENBQUM7SUFDdkM7UUFDSSxrQkFBa0I7UUFDbEIsUUFBUTtRQUNSLE1BQU07SUFDVjtJQUNBO1FBQ0ksV0FBVztRQUNYLGNBQWM7UUFDZCxnQkFBZ0I7SUFDcEI7QUFDSjtBQUVBLFlBQVk7QUFDWixzQkFBc0I7QUFDdEIseUJBQXlCO0FBQ3pCLGlDQUFpQztBQUNqQywwQkFBMEI7QUFDMUIscUJBQXFCO0FBQ3JCLHFDQUFxQztBQUNyQyxJQUFJO0FBRUosa0JBQWtCO0FBQ2xCLGlDQUFpQztBQUNqQyxxQ0FBcUM7QUFFckMsSUFBSTtBQUVKLG1CQUFtQjtBQUNuQixpQ0FBaUM7QUFDakMscUNBQXFDO0FBQ3JDLElBQUk7QUFFSjtJQUNJLHlCQUF5QjtJQUN6QixxQkFBcUI7QUFDekI7QUFFQSxhQUFhO0FBQ2IsaUNBQWlDO0FBQ2pDLDZCQUE2QjtBQUM3QixzQkFBc0I7QUFDdEIscUNBQXFDO0FBQ3JDLHNCQUFzQjtBQUN0QixJQUFJO0FBR0o7SUFDSSxXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLG1CQUFtQjtBQUN2QjtBQUNBO0lBQ0kseUJBQXlCO0lBQ3pCLHlCQUF5QjtJQUN6QixnQkFBZ0I7SUFDaEIsa0JBQWtCO0lBQ2xCLDZCQUE2QjtBQUNqQztBQUNBO0lBQ0ksaUJBQWlCO0FBQ3JCO0FBRUE7SUFDSSxvQ0FBb0M7SUFDcEMsY0FBYztBQUNsQjtBQUdBO0lBQ0ksb0JBQW9CO0lBQ3BCLGVBQWU7QUFDbkIiLCJmaWxlIjoic3JjL2FwcC9jb3JlL2hlYWRlci9oZWFkZXIuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5cclxuLm1haW4taGVhZGVye1xyXG4gICAgLypib3gtc2hhZG93OiA1cHggNXB4IDVweCBncmV5OyovXHJcbiAgICBoZWlnaHQ6IDE1JTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDBweCAhaW1wb3J0YW50O1xyXG5cclxufVxyXG4ubmF2e1xyXG5cclxufVxyXG4udG9wbmF2IHtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZGRkO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi50b3BuYXYgYSB7XHJcbiAgICBmbG9hdDogbGVmdDtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcGFkZGluZzogMTBweCAxMHB4O1xyXG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG59XHJcblxyXG4udG9wbmF2IGE6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2YyZjJmMjtcclxuICAgIGNvbG9yOiBibGFjaztcclxufVxyXG5cclxuLnRvcG5hdiBhLmFjdGl2ZSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNGI0YjRiO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4uc2hhZG93IHtcclxuICAgIC13ZWJraXQtYm94LXNoYWRvdzogMCAzcHggNXB4IHJnYmEoNTcsIDYzLCA3MiwgMC4zKTtcclxuICAgIC1tb3otYm94LXNoYWRvdzogMCAzcHggNXB4IHJnYmEoNTcsIDYzLCA3MiwgMC4zKTtcclxuICAgIGJveC1zaGFkb3c6IDAgM3B4IDVweCByZ2JhKDU3LCA2MywgNzIsIDAuMyk7XHJcbn1cclxuXHJcbi50b3BuYXYgLmljb24ge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxufVxyXG5cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNjAwcHgpIHtcclxuICAgIC50b3BuYXYgYTpub3QoOmZpcnN0LWNoaWxkKSB7ZGlzcGxheTogbm9uZTt9XHJcbiAgICAudG9wbmF2IGEuaWNvbiB7XHJcbiAgICAgICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgfVxyXG59XHJcblxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA2MDBweCkge1xyXG4gICAgLnRvcG5hdi5yZXNwb25zaXZlIHtwb3NpdGlvbjogcmVsYXRpdmU7fVxyXG4gICAgLnRvcG5hdi5yZXNwb25zaXZlIC5pY29uIHtcclxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgcmlnaHQ6IDA7XHJcbiAgICAgICAgdG9wOiAwO1xyXG4gICAgfVxyXG4gICAgLnRvcG5hdi5yZXNwb25zaXZlIGEge1xyXG4gICAgICAgIGZsb2F0OiBub25lO1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICB9XHJcbn1cclxuXHJcbi8qLm5hdmxpbmt7Ki9cclxuLyogICAgY29sb3I6ICM0YjRiNGI7Ki9cclxuLyogICAgZm9udC1mYW1pbHk6IExhdG87Ki9cclxuLyogICAgZm9udC1zaXplOiAxZW0gIWltcG9ydGFudDsqL1xyXG4vKiAgICBmb250LXN0eWxlOiBub3JtYWw7Ki9cclxuLyogICAgYWxpZ246IGNlbnRlcjsqL1xyXG4vKiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDsqL1xyXG4vKn0qL1xyXG5cclxuLyoubmF2bGluazpob3ZlcnsqL1xyXG4vKiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZDNkM2QzOyovXHJcbi8qICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kOyovXHJcblxyXG4vKn0qL1xyXG5cclxuLyoubmF2bGluazphY3RpdmV7Ki9cclxuLyogICAgYmFja2dyb3VuZC1jb2xvcjogI2QzZDNkMzsqL1xyXG4vKiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDsqL1xyXG4vKn0qL1xyXG5cclxuLmJ0bi1wcmltYXJ5IHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMyYTY0OTY7O1xyXG4gICAgYm9yZGVyLWNvbG9yOiAjMmE2NDk2O1xyXG59XHJcblxyXG4vKi5idG4tYmxrIHsqL1xyXG4vKiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNGI0YjRiOyovXHJcbi8qICAgIGJvcmRlci1jb2xvcjogIzRiNGI0YjsqL1xyXG4vKiAgICBjb2xvcjogI0YwRjBGMDsqL1xyXG4vKiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDsqL1xyXG4vKiAgICBmb250LXNpemU6IDFlbTsqL1xyXG4vKn0qL1xyXG5cclxuXHJcbnRhYmxlIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZm9udDogMTRweCBWZXJkYW5hO1xyXG4gICAgdGFibGUtbGF5b3V0OiBmaXhlZDtcclxufVxyXG50YWJsZSwgdGgsIHRkIHtcclxuICAgIGJvcmRlcjogc29saWQgMXB4ICM5OTk5OTk7XHJcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG4gICAgcGFkZGluZzogMnB4IDNweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtZmFtaWx5OiBMYXRvLCBzYW5zLXNlcmlmO1xyXG59XHJcbnRoIHtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcblxyXG50YWJsZSB0ci5oaWdobGlnaHQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzRiNGI0YiAhaW1wb3J0YW50O1xyXG4gICAgY29sb3I6ICNmZmZmZmY7XHJcbn1cclxuXHJcblxyXG5hLmRpc2FibGVkIHtcclxuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xyXG4gICAgY3Vyc29yOiBkZWZhdWx0O1xyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/core/header/header.component.html":
/*!***************************************************!*\
  !*** ./src/app/core/header/header.component.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div (window:unload)=\"doUnload()\" class=\"form-inline main-header fixed-top shadow\"\n     style=\" padding-left: 10px; width: 100%; background-color: #FFFFFF; border-bottom: #808080 solid .5px; position: sticky!important;\">\n    <div class=\"row\" style=\"width: 105%; border-top: #2a6496 3px solid; border-bottom: #808080 solid .5px; margin-right: 0px!important\">\n        <div class=\"col-2\">\n            <img src=\"../../../assets/images/tmtg.png\" width=\"80%\">\n        </div>\n        <div class=\"col-9 form-group\">\n            <div class=\"row\" style=\"width: 80%\">\n                <div class=\"col\">\n                    <label style=\"padding-right: 3em\"> Choose your project</label>\n                </div>\n                <div class=\"col-7 form-group\">\n                    <select class=\"selectpicker\" style=\"width: 100%\"\n                            *ngIf=\"utlSvc.utilities$\" [(ngModel)]=\"headerService.utility.name\"\n                            (change)=\"headerService.changeUtl($event)\" >\n                        <option *ngFor=\"let utility of utlSvc.utilities$ | async\"\n                                value=\"{{utility.name}}\">{{utility.fileName}}</option>\n                    </select>\n                </div>\n                <div class=\"col-1 form-group\">\n                    <button id=\"defineProduct\" type=\"button\" class=\"btn btn-sm btn-danger\" style=\"background-color: #AA1636!important;\" (click)=\"defineProduct()\" target=\"_blank\">\n                        <strong><span class=\"btn-label\" style=\"font-size: 1em\"><i class=\"fa fa-edit\"></i>Define Product</span></strong></button>\n\n                </div>\n            </div>\n        </div>\n        <div class=\"col-1 form-group\" align=\"right\">\n            <div class=\"row\">\n\n                <button id=\"dlBtn\" type=\"button\" class=\"btn btn-sm btn-primary\" (click)=\"userAuthService.logout()\" style=\"width: 100%\">\n                    <span class=\"btn-label\" style=\"font-size: 1em\"><i class=\"fa fa-sign-out\"></i>Logout</span>\n                </button>\n            </div>\n        </div>\n    </div>\n    <div class=\"topnav\" id=\"myTopnav\">\n        <a [routerLinkActive]=\"['active']\" [hidden]=\"userAuthService.getLevel() === '1'\" routerLink=\"/client-accounts\">Client Accounts</a>\n        <a [routerLinkActive]=\"['active']\" [hidden]=\"userAuthService.getLevel() === '1'\" routerLink=\"/utility\">Manage Utilities</a>\n        <a [routerLinkActive]=\"['active']\" routerLink=\"/preference\">Preference relative to other products</a>\n        <a [routerLinkActive]=\"['active']\" routerLink=\"/preference-ideal\">Preference relative to ideal</a>\n        <a [routerLinkActive]=\"['active']\" [ngStyle]=\"{'display': (utilManagementService.priceAtt === '') ? 'none': 'block'}\" routerLink=\"/sensitivity\">Price Sensitivity</a>\n        <a [routerLinkActive]=\"['active']\" [ngStyle]=\"{'display': (utilManagementService.priceAtt === '' || headerService.disableElasticityHeader.toString() === 'true') ? 'none': 'block'}\" routerLink=\"/elasticity\">Price Elasticity</a>\n        <button type=\"button\" class=\"btn shadow\" style=\"float: right\" (mousedown)=\"showHelpDesk()\"><span><i class=\"fa fa-info\"></i></span> Help Desk</button>\n        <div class=\"chat-popup\" id=\"myForm\">\n            <form class=\"form-container\" style=\"font-size: .7em!important\">\n                <h5>Help Desk</h5>\n                <p>Table:</p>\n                <p>{{message}}</p>\n\n                <button type=\"button\" class=\"btn btn-primary btn-sm\" (click)=\"showHelpDesk()\">Close</button>\n            </form>\n        </div>\n    </div>\n\n</div>\n\n"

/***/ }),

/***/ "./src/app/core/header/header.component.ts":
/*!*************************************************!*\
  !*** ./src/app/core/header/header.component.ts ***!
  \*************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _connection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../connection.service */ "./src/app/connection.service.ts");
/* harmony import */ var _service_utilities_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../service/utilities.service */ "./src/app/service/utilities.service.ts");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var _service_user_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../service/user-auth.service */ "./src/app/service/user-auth.service.ts");
/* harmony import */ var _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../product/productmanagement.service */ "./src/app/product/productmanagement.service.ts");
/* harmony import */ var _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../utility/utilitymanagement.service */ "./src/app/utility/utilitymanagement.service.ts");
/* harmony import */ var _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../scenario/scenariomanagement.service */ "./src/app/scenario/scenariomanagement.service.ts");
/* harmony import */ var _sensitivity_sensitivity_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../sensitivity/sensitivity.service */ "./src/app/sensitivity/sensitivity.service.ts");
/* harmony import */ var _header_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./header.service */ "./src/app/core/header/header.service.ts");
/* harmony import */ var _scenario_scenario_scenario_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../scenario/scenario/scenario.component */ "./src/app/scenario/scenario/scenario.component.ts");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/fesm5/ngx-spinner.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");














var HeaderComponent = /** @class */ (function () {
    // @ViewChild(ResizableDirective) resizable: ResizableDirective;
    function HeaderComponent(svc, utlSvc, utilitySvc, userAuthService, prodService, utilManagementService, sceManagementService, sensiService, headerService, r, moduleLoader, injector, viewContainerRef, spinner, router) {
        this.svc = svc;
        this.utlSvc = utlSvc;
        this.utilitySvc = utilitySvc;
        this.userAuthService = userAuthService;
        this.prodService = prodService;
        this.utilManagementService = utilManagementService;
        this.sceManagementService = sceManagementService;
        this.sensiService = sensiService;
        this.headerService = headerService;
        this.r = r;
        this.moduleLoader = moduleLoader;
        this.injector = injector;
        this.viewContainerRef = viewContainerRef;
        this.spinner = spinner;
        this.router = router;
        this.active = false;
        this.windowRef = null;
        this.spinner.show();
    }
    HeaderComponent.prototype.ngOnInit = function () {
    };
    HeaderComponent.prototype.ngAfterContentInit = function () {
        this.headerService.setInitialUtility();
        this.spinner.hide();
    };
    HeaderComponent.prototype.ngAfterViewInit = function () {
    };
    HeaderComponent.prototype.ngOnChanges = function () {
        var helpdesk = document.getElementById('myForm');
        if (helpdesk.style.display === 'block') {
            helpdesk.style.display = 'none';
        }
    };
    HeaderComponent.prototype.defineProduct = function () {
        var _this = this;
        if (this.windowRef !== null) {
            this.doUnload();
        }
        this.windowRef = window.open('', '', 'toolbar=0, width=1000, height=500');
        this.windowRef.document.title = 'Define Product';
        var factory = this.r.resolveComponentFactory(_scenario_scenario_scenario_component__WEBPACK_IMPORTED_MODULE_11__["ScenarioComponent"]);
        var comp = this.viewContainerRef.createComponent(factory);
        // in case you also need to inject an input to the child,
        // like the windows reference
        comp.instance.myPar = this.windowRef.document.body;
        comp.instance.tables = this.windowRef.document.getElementsByTagName('table');
        var sceInstance = comp.instance;
        for (var i = 0; i < comp.instance.tables.length; i++) {
            this.resizableGrid(comp.instance.tables[i]);
        }
        // add your freshly baked component on the windows
        this.windowRef.document.body.appendChild(comp.location.nativeElement);
        this.windowRef.document.body.addEventListener('mouseover', function () {
            var tables = _this.windowRef.document.getElementsByTagName('table');
            for (var i = 0; i < tables.length; i++) {
                _this.resizableGrid(i);
            }
        });
    };
    HeaderComponent.prototype.ngOnDestroy = function () {
        this.windowRef.close();
    };
    HeaderComponent.prototype.doUnload = function () {
        this.windowRef.close();
    };
    HeaderComponent.prototype.showHelpDesk = function () {
        switch (this.router.url) {
            case '/preference':
                this.message = 'Demonstrates the preference for different respondent groups or types.';
                break;
            case '/preference-ideal':
                this.message = 'Average preference for products relative to ideal presented in tabular format that can easily be' +
                    ' exported or printed.\nShows percentage to one decimal ';
                break;
            case '/sensitivity':
                this.message = 'The price sensitivity tab provides immediate output of preference for one product that has price ' +
                    'varied while holding price constant for all other products. You may choose the price range and price increments' +
                    ' for the product whose price you wish to vary on the left. The Y axis shows preference share of each product, ' +
                    'while the X axis shows the price of the chosen product. Typically, preference share for the chosen product will ' +
                    'decrease as the price increases.';
                break;
            case '/elasticity':
                this.message = '< 1: Inelastic: Price can be increased with less decrease in units. It means the price can be increased ' +
                    'to improve revenues.\n= 1: Unit Elasticity: At this price level, an increase in price will be equally offset by ' +
                    'a decrease in units.\n1: Elastic: A price increase will be accompanied by a greater decrease in units. It means ' +
                    'that a price increase will result in lower total revenue.';
                break;
        }
        var helpdesk = document.getElementById('myForm');
        if (helpdesk.style.display === 'block') {
            helpdesk.style.display = 'none';
        }
        else {
            helpdesk.style.display = 'block';
        }
    };
    HeaderComponent.prototype.resizableGrid = function (cnt) {
        // console.log(table);
        var row = this.windowRef.document.getElementsByTagName('table')[cnt].getElementsByTagName('tr')[0];
        var cols = row ? row.children : undefined;
        if (!cols) {
            return;
        }
        this.windowRef.document.getElementsByTagName('table')[cnt].style.overflow = 'hidden';
        var tableHeight = this.windowRef.document.getElementsByTagName('table')[cnt].offsetHeight;
        for (var i = 0; i < cols.length; i++) {
            var div = this.createDiv(tableHeight);
            cols[i].appendChild(div);
            cols[i].style.position = 'relative';
            this.setListeners(div);
        }
    };
    HeaderComponent.prototype.setListeners = function (div) {
        var _this = this;
        var pageX, curCol, nxtCol, curColWidth, nxtColWidth;
        div.addEventListener('mousedown', function (e) {
            curCol = e.target.parentElement;
            nxtCol = curCol.nextElementSibling;
            pageX = e.pageX;
            var padding = _this.paddingDiff(curCol);
            curColWidth = curCol.offsetWidth - padding;
            if (nxtCol) {
                nxtColWidth = nxtCol.offsetWidth - padding;
            }
        });
        div.addEventListener('mouseover', function (e) {
            e.target.style.borderRight = '2px solid #0000ff';
        });
        div.addEventListener('mouseout', function (e) {
            e.target.style.borderRight = '';
        });
        this.windowRef.document.addEventListener('mousemove', function (e) {
            if (curCol) {
                var diffX = e.pageX - pageX;
                if (nxtCol) {
                    nxtCol.style.width = (nxtColWidth - (diffX)) + 'px';
                }
                curCol.style.width = (curColWidth + diffX) + 'px';
            }
        });
        this.windowRef.document.addEventListener('mouseup', function (e) {
            curCol = undefined;
            nxtCol = undefined;
            pageX = undefined;
            nxtColWidth = undefined;
            curColWidth = undefined;
        });
    };
    HeaderComponent.prototype.createDiv = function (height) {
        var div = this.windowRef.document.createElement('div');
        div.style.top = '0';
        div.style.right = '0';
        div.style.width = '5px';
        div.style.position = 'absolute';
        div.style.cursor = 'col-resize';
        div.style.userSelect = 'none';
        div.style.height = height + 'px';
        return div;
    };
    HeaderComponent.prototype.paddingDiff = function (col) {
        if (this.getStyleVal(col, 'box-sizing') == 'border-box') {
            return 0;
        }
        var padLeft = this.getStyleVal(col, 'padding-left');
        var padRight = this.getStyleVal(col, 'padding-right');
        // tslint:disable-next-line:radix
        return (parseInt(padLeft) + parseInt(padRight));
    };
    HeaderComponent.prototype.getStyleVal = function (elm, css) {
        return (window.getComputedStyle(elm, null).getPropertyValue(css));
    };
    HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/core/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.css */ "./src/app/core/header/header.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_connection_service__WEBPACK_IMPORTED_MODULE_2__["ConnectionService"],
            _service_utilities_service__WEBPACK_IMPORTED_MODULE_3__["UtilitiesService"],
            _service_utility_service__WEBPACK_IMPORTED_MODULE_4__["UtilityService"],
            _service_user_auth_service__WEBPACK_IMPORTED_MODULE_5__["UserAuthService"],
            _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_6__["ProductmanagementService"],
            _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_7__["UtilitymanagementService"],
            _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_8__["ScenariomanagementService"],
            _sensitivity_sensitivity_service__WEBPACK_IMPORTED_MODULE_9__["SensitivityService"],
            _header_service__WEBPACK_IMPORTED_MODULE_10__["HeaderService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ComponentFactoryResolver"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModuleFactoryLoader"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["Injector"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"],
            ngx_spinner__WEBPACK_IMPORTED_MODULE_12__["NgxSpinnerService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_13__["Router"]])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/core/header/header.service.ts":
/*!***********************************************!*\
  !*** ./src/app/core/header/header.service.ts ***!
  \***********************************************/
/*! exports provided: HeaderService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderService", function() { return HeaderService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _models_Utility__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../models/Utility */ "./src/app/models/Utility.ts");
/* harmony import */ var _connection_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../connection.service */ "./src/app/connection.service.ts");
/* harmony import */ var _service_utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../service/utilities.service */ "./src/app/service/utilities.service.ts");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var _service_user_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../service/user-auth.service */ "./src/app/service/user-auth.service.ts");
/* harmony import */ var _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../product/productmanagement.service */ "./src/app/product/productmanagement.service.ts");
/* harmony import */ var _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../utility/utilitymanagement.service */ "./src/app/utility/utilitymanagement.service.ts");
/* harmony import */ var _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../scenario/scenariomanagement.service */ "./src/app/scenario/scenariomanagement.service.ts");
/* harmony import */ var xml2js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! xml2js */ "./node_modules/xml2js/lib/xml2js.js");
/* harmony import */ var xml2js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(xml2js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _service_scenario_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../service/scenario.service */ "./src/app/service/scenario.service.ts");












var HeaderService = /** @class */ (function () {
    function HeaderService(svc, utlSvc, utilitySvc, userAuthService, prodService, utilManagementService, sceManagementService, scenariosService) {
        var _this = this;
        this.svc = svc;
        this.utlSvc = utlSvc;
        this.utilitySvc = utilitySvc;
        this.userAuthService = userAuthService;
        this.prodService = prodService;
        this.utilManagementService = utilManagementService;
        this.sceManagementService = sceManagementService;
        this.scenariosService = scenariosService;
        this.initial = true;
        this.utlSvc.utilities$.subscribe(function (utls) {
            _this.utilityList = utls;
        });
        this.utilitySvc.cast.subscribe(function (utility) { return _this.utility = utility; });
    }
    HeaderService.prototype.ngOnInit = function () {
    };
    HeaderService.prototype.setInitialUtility = function () {
        if (this.utility.id === undefined) {
            this.utility = Object.assign({}, this.utilityList[0]);
            this.utilManagementService.parseXMLFile(this.utility.utl_xml);
            this.disableElasticityHeader = this.utilManagementService.disableElasticity;
            // this.authService.setEnableElasticity(this.utilManagementService.disableElasticity as boolean);
            sessionStorage.setItem('ELASTICITY', this.utilManagementService.disableElasticity);
            this.getPriceAttributes();
            this.getProductList(this.utility.utl_xml, this.utility.name);
            this.prodService.convertToJson();
            this.prodService.getAttributes();
            this.productList = new Array();
            this.productList = this.sceManagementService.selectedScenario.products;
        }
    };
    HeaderService.prototype.changeUtl = function (event) {
        try {
            var utility = void 0;
            var name_1 = event.target.value;
            this.scenariosService.resetScenario();
            utility = JSON.parse(JSON.stringify(this.utilityList.filter(function (utl) { return utl.name === name_1; })[0]));
            this.utilManagementService.parseXMLFile(utility.utl_xml);
            this.disableElasticityHeader = (this.utilManagementService.disableElasticity);
            sessionStorage.setItem('ELASTICITY', this.utilManagementService.disableElasticity);
            // this.authService.setEnableElasticity(this.utilManagementService.disableElasticity as boolean);
            this.getPriceAttributes();
            this.getProductList(utility.utl_xml, utility.name);
            this.prodService.convertToJson();
            this.prodService.getAttributes();
            this.productList = new Array();
            this.productList = this.sceManagementService.selectedScenario.products;
        }
        catch (e) {
            console.log(e);
        }
    };
    HeaderService.prototype.getProductList = function (data, name) {
        var utility = new _models_Utility__WEBPACK_IMPORTED_MODULE_2__["Utility"]();
        utility.name = name;
        xml2js__WEBPACK_IMPORTED_MODULE_10___default.a.parseString(data, { explicitArray: false }, function (error, result) {
            if (error) {
                throw new Error(error);
            }
            else {
                utility.fileName = result.utility.$.name;
                utility.utl_xml = result.utility.references;
                utility.utl_val = result.utility.values.col;
            }
        });
        this.utilitySvc.editUtility(utility);
    };
    HeaderService.prototype.getPriceAttributes = function () {
        this.priceRange = new Array();
        this.priceRange = this.utilManagementService.attLevels[this.utilManagementService.priceAtt];
        this.priceMin = Number(this.priceRange[0]);
        this.priceMax = Number(this.priceRange[this.priceRange.length - 1]);
        this.increment = 0;
        this.priceMin2 = Number(this.priceRange[0]);
        this.priceMax2 = Number(this.priceRange[this.priceRange.length - 1]);
        this.increment2 = 0;
    };
    HeaderService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_connection_service__WEBPACK_IMPORTED_MODULE_3__["ConnectionService"],
            _service_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"],
            _service_utility_service__WEBPACK_IMPORTED_MODULE_5__["UtilityService"],
            _service_user_auth_service__WEBPACK_IMPORTED_MODULE_6__["UserAuthService"],
            _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_7__["ProductmanagementService"],
            _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_8__["UtilitymanagementService"],
            _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_9__["ScenariomanagementService"],
            _service_scenario_service__WEBPACK_IMPORTED_MODULE_11__["ScenarioService"]])
    ], HeaderService);
    return HeaderService;
}());



/***/ }),

/***/ "./src/app/core/navbar/navbar.component.css":
/*!**************************************************!*\
  !*** ./src/app/core/navbar/navbar.component.css ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvcmUvbmF2YmFyL25hdmJhci5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/core/navbar/navbar.component.html":
/*!***************************************************!*\
  !*** ./src/app/core/navbar/navbar.component.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav class=\"navbar navbar-inverse\">\n  <div class=\"container-fluid\">\n    <div class=\"navbar-header\">\n      <a class=\"navbar-brand\" href=\"#\">WebSiteName</a>\n    </div>\n    <ul class=\"nav navbar-nav\">\n      <li class=\"active\"><a href=\"#\">Home</a></li>\n      <li><a href=\"#\">Page 1</a></li>\n      <li><a href=\"#\">Page 2</a></li>\n      <li><a href=\"#\">Page 3</a></li>\n    </ul>\n  </div>\n</nav>\n"

/***/ }),

/***/ "./src/app/core/navbar/navbar.component.ts":
/*!*************************************************!*\
  !*** ./src/app/core/navbar/navbar.component.ts ***!
  \*************************************************/
/*! exports provided: NavbarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavbarComponent", function() { return NavbarComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var NavbarComponent = /** @class */ (function () {
    function NavbarComponent() {
    }
    NavbarComponent.prototype.ngOnInit = function () {
    };
    NavbarComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-navbar',
            template: __webpack_require__(/*! ./navbar.component.html */ "./src/app/core/navbar/navbar.component.html"),
            styles: [__webpack_require__(/*! ./navbar.component.css */ "./src/app/core/navbar/navbar.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], NavbarComponent);
    return NavbarComponent;
}());



/***/ }),

/***/ "./src/app/elasticity/elasticity.module.ts":
/*!*************************************************!*\
  !*** ./src/app/elasticity/elasticity.module.ts ***!
  \*************************************************/
/*! exports provided: ElasticityModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ElasticityModule", function() { return ElasticityModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _elasticity_elasticity_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./elasticity/elasticity.component */ "./src/app/elasticity/elasticity/elasticity.component.ts");
/* harmony import */ var _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @syncfusion/ej2-angular-charts */ "./node_modules/@syncfusion/ej2-angular-charts/@syncfusion/ej2-angular-charts.es5.js");
/* harmony import */ var _scenario_scenario_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../scenario/scenario.module */ "./src/app/scenario/scenario.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _resizable_resizable_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../resizable/resizable.module */ "./src/app/resizable/resizable.module.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var angular_split__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! angular-split */ "./node_modules/angular-split/fesm5/angular-split.js");











var ElasticityModule = /** @class */ (function () {
    function ElasticityModule() {
    }
    ElasticityModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_elasticity_elasticity_component__WEBPACK_IMPORTED_MODULE_3__["ElasticityComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_4__["ChartModule"],
                _scenario_scenario_module__WEBPACK_IMPORTED_MODULE_5__["ScenarioModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
                _resizable_resizable_module__WEBPACK_IMPORTED_MODULE_7__["ResizableModule"],
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__["BrowserModule"],
                angular_split__WEBPACK_IMPORTED_MODULE_9__["AngularSplitModule"]
            ],
            exports: [
                _elasticity_elasticity_component__WEBPACK_IMPORTED_MODULE_3__["ElasticityComponent"]
            ],
            providers: [
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_4__["BarSeriesService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_4__["ColumnSeriesService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_4__["CategoryService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_4__["StackingColumnSeriesService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_4__["DateTimeService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_4__["ScrollBarService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_4__["LineSeriesService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_4__["ChartAnnotationService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_4__["RangeColumnSeriesService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_4__["StackingColumnSeriesService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_4__["LegendService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_4__["TooltipService"]
            ]
        })
    ], ElasticityModule);
    return ElasticityModule;
}());



/***/ }),

/***/ "./src/app/elasticity/elasticity.service.ts":
/*!**************************************************!*\
  !*** ./src/app/elasticity/elasticity.service.ts ***!
  \**************************************************/
/*! exports provided: ElasticityService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ElasticityService", function() { return ElasticityService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _core_header_header_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../core/header/header.service */ "./src/app/core/header/header.service.ts");
/* harmony import */ var _sensitivity_sensitivity_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../sensitivity/sensitivity.service */ "./src/app/sensitivity/sensitivity.service.ts");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utility/utilitymanagement.service */ "./src/app/utility/utilitymanagement.service.ts");
/* harmony import */ var _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../product/productmanagement.service */ "./src/app/product/productmanagement.service.ts");







var ElasticityService = /** @class */ (function () {
    function ElasticityService(sensiService, utilManagementService, prodManagementService, headerService) {
        this.sensiService = sensiService;
        this.utilManagementService = utilManagementService;
        this.prodManagementService = prodManagementService;
        this.headerService = headerService;
        // this.increment = 0;
    }
    ElasticityService.prototype.ngOnInit = function () {
    };
    ElasticityService.prototype.calculate = function () {
        var _this = this;
        if (this.headerService.priceMax2 > this.headerService.priceMin2 && this.headerService.increment2 > 0) {
            this.setPrice();
            this.getSensitivity();
            this.getElasticity();
            this.getRevenue();
            this.getAdjustedRevenue();
            this.elasticityChart = new Array();
            this.elasticity.forEach(function (value, key) {
                value.forEach(function (elasticityVal, elasticityKey) {
                    _this.elasticityChart.push({ price: elasticityKey, elasticity: elasticityVal });
                });
            });
            this.revenueChart = new Array();
            this.adjustedRevenue.forEach(function (value, key) {
                value.forEach(function (revenueVal, revenueKey) {
                    _this.revenueChart.push({ price: revenueKey, revenue: revenueVal });
                });
            });
        }
        else {
            this.message = 'Error! Please check your price parameters. Price increment should be at least 1% of price range.';
        }
    };
    ElasticityService.prototype.getSensitivity = function () {
        var product = new Map();
        // Get price sensitivity
        this.calculateSensi();
        this.getRelativeTotal();
        // Get total
        this.relativeTotal.forEach(function (value, key) { return product.set(key, Number(value[0])); });
        this.sensitivity = new Map();
        this.sensitivity.set(this.selectedProduct.name, product);
    };
    ElasticityService.prototype.calculateSensi = function () {
        this.relativeResult = new Map();
        if (this.headerService.priceMin2 < this.headerService.priceMax2 && this.headerService.increment2 > 0) {
            for (var i = this.headerService.priceMin2; i <= this.headerService.priceMax2; i += this.headerService.increment2) {
                // Set current product attribute
                var currentProduct = JSON.parse(JSON.stringify(this.selectedProduct));
                currentProduct.attribute = this.selectedProduct.attribute;
                currentProduct.attributeValues[this.utilManagementService.priceAtt] = i.toString();
                // Get relative result
                this.relativeResult.set(i, this.utilManagementService.getRelativeResult([currentProduct]));
            }
        }
        else {
            this.message = 'Error! Please check your price parameters.';
        }
    };
    ElasticityService.prototype.selectSegmentLevel = function (level, segment) {
        var _this = this;
        var segmentPositions = [];
        var selectedLevel = 0;
        var product = new Map();
        this.selectedLevel = level;
        // Get segment positions
        for (var i = 0; i < this.prodManagementService.segments.length; i++) {
            if (this.prodManagementService.segments[i]['cell_1'] === segment) {
                segmentPositions = this.utilManagementService.getSegmentValues(this.prodManagementService.segmentPositions[i]);
                // Get levelId
                var cnt = 0;
                for (var n in this.prodManagementService.segments[i]) {
                    if (String(this.prodManagementService.segments[i]['cell_3_' + cnt]) === String(level)) {
                        selectedLevel = cnt;
                    }
                    cnt++;
                }
            }
        }
        if (this.headerService.priceMax2 > this.headerService.priceMin2 && this.headerService.increment2 > 0) {
            this.setPrice();
            this.calculateSensi();
            this.getRelativeTotalByLevel(segmentPositions, selectedLevel);
            // Get total
            this.relativeTotal.forEach(function (value, key) { return product.set(key, Number(value[0])); });
            this.sensitivity = new Map();
            this.sensitivity.set(this.selectedProduct.name, product);
            this.getElasticity();
            this.getRevenue();
            this.getAdjustedRevenue();
            this.elasticityChart = new Array();
            this.elasticity.forEach(function (value, key) {
                value.forEach(function (elasticityVal, elasticityKey) {
                    _this.elasticityChart.push({ price: elasticityKey, elasticity: elasticityVal });
                });
            });
            this.revenueChart = new Array();
            this.adjustedRevenue.forEach(function (value, key) {
                value.forEach(function (revenueVal, revenueKey) {
                    _this.revenueChart.push({ price: revenueKey, revenue: revenueVal });
                });
            });
        }
        else {
            this.message = 'Error! Please check your price parameters!';
        }
    };
    ElasticityService.prototype.getRelativeTotal = function () {
        var _this = this;
        this.relativeTotal = new Map();
        this.relativeResult.forEach(function (result, key) {
            var temp = new Array();
            var _loop_1 = function (i) {
                var sum = 0;
                result[i].forEach(function (a) { return sum += a; });
                temp.push((sum / result[i].length).toFixed(1));
            };
            for (var i in result) {
                _loop_1(i);
            }
            _this.relativeTotal.set(key, temp);
        });
    };
    ElasticityService.prototype.getRelativeTotalByLevel = function (segmentPositions, selectedLevel) {
        var _this = this;
        this.relativeTotal = new Map();
        this.relativeResult.forEach(function (result, key) {
            var temp = new Array();
            var _loop_2 = function (i) {
                var sum = 0;
                var cnt = 0;
                var length_1 = 0;
                result[i].forEach(function (a) {
                    if (Number(segmentPositions[cnt++]) === selectedLevel) {
                        sum += a;
                        length_1++;
                    }
                });
                if (sum !== 0) {
                    temp.push((sum / length_1).toFixed(1));
                }
                else {
                    temp.push(0);
                }
            };
            for (var i in result) {
                _loop_2(i);
            }
            _this.relativeTotal.set(key, temp);
        });
    };
    ElasticityService.prototype.setPrice = function () {
        var key = 0;
        this.price = new Map();
        for (var i = Number(this.headerService.priceMin2); i <= Number(this.headerService.priceMax2); i += this.headerService.increment2) {
            this.price.set(key++, Number(i.toFixed(1)));
        }
    };
    ElasticityService.prototype.getElasticity = function () {
        var _this = this;
        var product;
        var price = 0;
        var previousKey;
        this.elasticity = new Map();
        this.sensitivity.forEach(function (products, productkey) {
            var elasticityTemp = new Map();
            products.forEach(function (value, key) {
                if (Object(util__WEBPACK_IMPORTED_MODULE_4__["isUndefined"])(previousKey)) {
                    elasticityTemp.set(key, 0);
                    previousKey = key;
                }
                else {
                    product = (value - products.get(previousKey)) / value;
                    price = (key - previousKey) / key;
                    elasticityTemp.set(key, (Math.abs(product / price)).toFixed(2));
                    previousKey = key;
                }
            });
            _this.elasticity.set(productkey, elasticityTemp);
        });
    };
    ElasticityService.prototype.getRevenue = function () {
        var _this = this;
        this.revenue = new Map();
        this.sensitivity.forEach(function (products, productkey) {
            products.forEach(function (value, key) { return _this.revenue.set(Number(key.toFixed(2)), (value * key).toFixed(1)); });
        });
    };
    ElasticityService.prototype.getAdjustedRevenue = function () {
        var maxRev = 0;
        var minRev = 0;
        var tempAdjRev = new Map();
        this.adjustedRevenue = new Map();
        // Get min revenue
        this.revenue.forEach(function (value, key) {
            if (minRev === 0) {
                minRev = parseFloat(value);
            }
            else if (parseFloat(value) < minRev) {
                minRev = parseFloat(value);
            }
        });
        // Get maximum revenue
        this.revenue.forEach(function (value, key) {
            if (key === 0) {
                maxRev = parseFloat(value);
            }
            else if (parseFloat(value) > maxRev) {
                maxRev = parseFloat(value);
            }
        });
        this.revenue.forEach(function (value, key) {
            tempAdjRev.set(key, (((value - minRev) / (maxRev - minRev)).toFixed(1)));
        });
        this.adjustedRevenue.set(this.selectedProduct.name, tempAdjRev);
    };
    ElasticityService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_sensitivity_sensitivity_service__WEBPACK_IMPORTED_MODULE_3__["SensitivityService"],
            _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_5__["UtilitymanagementService"],
            _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_6__["ProductmanagementService"],
            _core_header_header_service__WEBPACK_IMPORTED_MODULE_2__["HeaderService"]])
    ], ElasticityService);
    return ElasticityService;
}());



/***/ }),

/***/ "./src/app/elasticity/elasticity/elasticity.component.css":
/*!****************************************************************!*\
  !*** ./src/app/elasticity/elasticity/elasticity.component.css ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n\r\n\r\n\r\n\r\n.collapsible {\r\n    background-color: #f7f7f7;\r\n    cursor: pointer;\r\n    /*padding-left: 5px;*/\r\n    width: 100%;\r\n    border: #f7f7f7;\r\n    text-align: left;\r\n    outline: none;\r\n    font-size: 14px;\r\n    margin: 0px;\r\n    padding-top: .2%;\r\n    padding-bottom: .2%;\r\n    -webkit-transition: 0.4s;\r\n    transition: 0.4s;\r\n}\r\n\r\nbutton.collapsible:after {\r\n    /*content: 'Collapse';*/\r\n    color: white;\r\n    background-color: #2a6496;\r\n    /*margin-right: 10px;*/\r\n    float: right;\r\n    align: middle;\r\n}\r\n\r\nbutton.collapsible.active:after {\r\n    /*content: 'Expand';*/\r\n}\r\n\r\n.active, .collapsible:hover {\r\n    background-color: #f7f7f7;\r\n}\r\n\r\n.content {\r\n    padding: 0 18px;\r\n    display: block;\r\n    overflow: hidden;\r\n    /*background-color: #fafafa;*/\r\n    border: none;\r\n}\r\n\r\n.resizable-div {\r\n    resize: vertical;\r\n    overflow: auto;\r\n    border: 1px solid #e1e1e1;\r\n}\r\n\r\n.shadow {\r\n    box-shadow: 0 3px 5px rgba(57, 63, 72, 0.3);\r\n}\r\n\r\n.btn-primary {\r\n    background-color: #2a6496;\r\n    border-color: #2a6496;\r\n}\r\n\r\ntable {\r\n    display: block;\r\n    overflow-y: auto!important;\r\n    border: none;\r\n    width: 100vw;\r\n    margin-bottom: 0;\r\n    table-layout: fixed\r\n}\r\n\r\ntable td, .table th {\r\n    padding: 5px!important;\r\n    font-size: .8em;\r\n    width: 100vw;\r\n}\r\n\r\nul li.highlight {\r\n    background-color: #DCDCDC !important;\r\n\r\n}\r\n\r\nul li {\r\n    cursor: pointer;\r\n}\r\n\r\n/* Splitter*/\r\n\r\n/*#loader {*/\r\n\r\n/*    color: #008cff;*/\r\n\r\n/*    height: 40px;*/\r\n\r\n/*    left: 45%;*/\r\n\r\n/*    position: absolute;*/\r\n\r\n/*    top: 45%;*/\r\n\r\n/*    width: 30%;*/\r\n\r\n/*}*/\r\n\r\n/*.content {*/\r\n\r\n/*    padding: 9px;*/\r\n\r\n/*}*/\r\n\r\n/*#left-pane-content,*/\r\n\r\n/*#middle-pane-content,*/\r\n\r\n/*#last-pane-content {*/\r\n\r\n/*    text-align: left;*/\r\n\r\n/*    !*align-items: normal;*!*/\r\n\r\n/*    justify-content: left;*/\r\n\r\n/*    display: flex;*/\r\n\r\n/*    height: 80vh;*/\r\n\r\n/*    margin: 20px;*/\r\n\r\n/*    overflow: hidden;*/\r\n\r\n/*}*/\r\n\r\n/*#panetext {*/\r\n\r\n/*    font-size: 11px;*/\r\n\r\n/*}*/\r\n\r\n/*#container {*/\r\n\r\n/*    margin: 0px auto;*/\r\n\r\n/*}*/\r\n\r\n/*#template_container {*/\r\n\r\n/*    margin: 60px auto;*/\r\n\r\n/*}*/\r\n\r\n/*.auto-size-content, .template {*/\r\n\r\n/*    padding: 9px;*/\r\n\r\n/*}*/\r\n\r\n/*#loader {*/\r\n\r\n/*    color: #008cff;*/\r\n\r\n/*    height: 40px;*/\r\n\r\n/*    left: 45%;*/\r\n\r\n/*    position: absolute;*/\r\n\r\n/*    top: 45%;*/\r\n\r\n/*    width: 30%;*/\r\n\r\n/*}*/\r\n\r\n/*#code-text {*/\r\n\r\n/*    margin-left: 5px;*/\r\n\r\n/*}*/\r\n\r\n/*.code-preview {*/\r\n\r\n/*    margin-top: 15px;*/\r\n\r\n/*    font-size: 12px;*/\r\n\r\n/*}*/\r\n\r\n/*.h3 {*/\r\n\r\n/*    font-size: 14px;*/\r\n\r\n/*    margin: 4px;*/\r\n\r\n/*}*/\r\n\r\n/*.content {*/\r\n\r\n/*    padding: 12px;*/\r\n\r\n/*}*/\r\n\r\n/*.splitter-image {*/\r\n\r\n/*    margin: 0 auto;*/\r\n\r\n/*    display: flex;*/\r\n\r\n/*    height: 115px;*/\r\n\r\n/*    margin-top: 10px;*/\r\n\r\n/*}*/\r\n\r\n/*#container {*/\r\n\r\n/*    margin: 30px;*/\r\n\r\n/*}*/\r\n\r\n/*#load-content-container {*/\r\n\r\n/*    margin: 60px auto;*/\r\n\r\n/*}*/\r\n\r\n\r\n\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZWxhc3RpY2l0eS9lbGFzdGljaXR5L2VsYXN0aWNpdHkuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUtBO0lBQ0kseUJBQXlCO0lBQ3pCLGVBQWU7SUFDZixxQkFBcUI7SUFDckIsV0FBVztJQUNYLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsYUFBYTtJQUNiLGVBQWU7SUFDZixXQUFXO0lBQ1gsZ0JBQWdCO0lBQ2hCLG1CQUFtQjtJQUNuQix3QkFBZ0I7SUFBaEIsZ0JBQWdCO0FBQ3BCOztBQUVBO0lBQ0ksdUJBQXVCO0lBQ3ZCLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsc0JBQXNCO0lBQ3RCLFlBQVk7SUFDWixhQUFhO0FBQ2pCOztBQUVBO0lBQ0kscUJBQXFCO0FBQ3pCOztBQUVBO0lBQ0kseUJBQXlCO0FBQzdCOztBQUVBO0lBQ0ksZUFBZTtJQUNmLGNBQWM7SUFDZCxnQkFBZ0I7SUFDaEIsNkJBQTZCO0lBQzdCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLHlCQUF5QjtBQUM3Qjs7QUFFQTtJQUdJLDJDQUEyQztBQUMvQzs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixxQkFBcUI7QUFDekI7O0FBRUE7SUFDSSxjQUFjO0lBQ2QsMEJBQTBCO0lBQzFCLFlBQVk7SUFDWixZQUFZO0lBQ1osZ0JBQWdCO0lBQ2hCO0FBQ0o7O0FBRUE7SUFDSSxzQkFBc0I7SUFDdEIsZUFBZTtJQUNmLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxvQ0FBb0M7O0FBRXhDOztBQUVBO0lBQ0ksZUFBZTtBQUNuQjs7QUFFQSxZQUFZOztBQUNaLFlBQVk7O0FBQ1osc0JBQXNCOztBQUN0QixvQkFBb0I7O0FBQ3BCLGlCQUFpQjs7QUFDakIsMEJBQTBCOztBQUMxQixnQkFBZ0I7O0FBQ2hCLGtCQUFrQjs7QUFDbEIsSUFBSTs7QUFFSixhQUFhOztBQUNiLG9CQUFvQjs7QUFDcEIsSUFBSTs7QUFFSixzQkFBc0I7O0FBQ3RCLHdCQUF3Qjs7QUFDeEIsdUJBQXVCOztBQUN2Qix3QkFBd0I7O0FBQ3hCLCtCQUErQjs7QUFDL0IsNkJBQTZCOztBQUM3QixxQkFBcUI7O0FBQ3JCLG9CQUFvQjs7QUFDcEIsb0JBQW9COztBQUNwQix3QkFBd0I7O0FBQ3hCLElBQUk7O0FBRUosY0FBYzs7QUFDZCx1QkFBdUI7O0FBQ3ZCLElBQUk7O0FBRUosZUFBZTs7QUFDZix3QkFBd0I7O0FBQ3hCLElBQUk7O0FBRUosd0JBQXdCOztBQUN4Qix5QkFBeUI7O0FBQ3pCLElBQUk7O0FBRUosa0NBQWtDOztBQUNsQyxvQkFBb0I7O0FBQ3BCLElBQUk7O0FBRUosWUFBWTs7QUFDWixzQkFBc0I7O0FBQ3RCLG9CQUFvQjs7QUFDcEIsaUJBQWlCOztBQUNqQiwwQkFBMEI7O0FBQzFCLGdCQUFnQjs7QUFDaEIsa0JBQWtCOztBQUNsQixJQUFJOztBQUVKLGVBQWU7O0FBQ2Ysd0JBQXdCOztBQUN4QixJQUFJOztBQUVKLGtCQUFrQjs7QUFDbEIsd0JBQXdCOztBQUN4Qix1QkFBdUI7O0FBQ3ZCLElBQUk7O0FBRUosUUFBUTs7QUFDUix1QkFBdUI7O0FBQ3ZCLG1CQUFtQjs7QUFDbkIsSUFBSTs7QUFFSixhQUFhOztBQUNiLHFCQUFxQjs7QUFDckIsSUFBSTs7QUFFSixvQkFBb0I7O0FBQ3BCLHNCQUFzQjs7QUFDdEIscUJBQXFCOztBQUNyQixxQkFBcUI7O0FBQ3JCLHdCQUF3Qjs7QUFDeEIsSUFBSTs7QUFFSixlQUFlOztBQUNmLG9CQUFvQjs7QUFDcEIsSUFBSTs7QUFFSiw0QkFBNEI7O0FBQzVCLHlCQUF5Qjs7QUFDekIsSUFBSSIsImZpbGUiOiJzcmMvYXBwL2VsYXN0aWNpdHkvZWxhc3RpY2l0eS9lbGFzdGljaXR5LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuXHJcblxyXG5cclxuXHJcbi5jb2xsYXBzaWJsZSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjdmN2Y3O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgLypwYWRkaW5nLWxlZnQ6IDVweDsqL1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3JkZXI6ICNmN2Y3Zjc7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgb3V0bGluZTogbm9uZTtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gICAgcGFkZGluZy10b3A6IC4yJTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAuMiU7XHJcbiAgICB0cmFuc2l0aW9uOiAwLjRzO1xyXG59XHJcblxyXG5idXR0b24uY29sbGFwc2libGU6YWZ0ZXIge1xyXG4gICAgLypjb250ZW50OiAnQ29sbGFwc2UnOyovXHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMmE2NDk2O1xyXG4gICAgLyptYXJnaW4tcmlnaHQ6IDEwcHg7Ki9cclxuICAgIGZsb2F0OiByaWdodDtcclxuICAgIGFsaWduOiBtaWRkbGU7XHJcbn1cclxuXHJcbmJ1dHRvbi5jb2xsYXBzaWJsZS5hY3RpdmU6YWZ0ZXIge1xyXG4gICAgLypjb250ZW50OiAnRXhwYW5kJzsqL1xyXG59XHJcblxyXG4uYWN0aXZlLCAuY29sbGFwc2libGU6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2Y3ZjdmNztcclxufVxyXG5cclxuLmNvbnRlbnQge1xyXG4gICAgcGFkZGluZzogMCAxOHB4O1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgLypiYWNrZ3JvdW5kLWNvbG9yOiAjZmFmYWZhOyovXHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbn1cclxuXHJcbi5yZXNpemFibGUtZGl2IHtcclxuICAgIHJlc2l6ZTogdmVydGljYWw7XHJcbiAgICBvdmVyZmxvdzogYXV0bztcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlMWUxZTE7XHJcbn1cclxuXHJcbi5zaGFkb3cge1xyXG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDNweCA1cHggcmdiYSg1NywgNjMsIDcyLCAwLjMpO1xyXG4gICAgLW1vei1ib3gtc2hhZG93OiAwIDNweCA1cHggcmdiYSg1NywgNjMsIDcyLCAwLjMpO1xyXG4gICAgYm94LXNoYWRvdzogMCAzcHggNXB4IHJnYmEoNTcsIDYzLCA3MiwgMC4zKTtcclxufVxyXG5cclxuLmJ0bi1wcmltYXJ5IHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMyYTY0OTY7XHJcbiAgICBib3JkZXItY29sb3I6ICMyYTY0OTY7XHJcbn1cclxuXHJcbnRhYmxlIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgb3ZlcmZsb3cteTogYXV0byFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICB3aWR0aDogMTAwdnc7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwO1xyXG4gICAgdGFibGUtbGF5b3V0OiBmaXhlZFxyXG59XHJcblxyXG50YWJsZSB0ZCwgLnRhYmxlIHRoIHtcclxuICAgIHBhZGRpbmc6IDVweCFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXNpemU6IC44ZW07XHJcbiAgICB3aWR0aDogMTAwdnc7XHJcbn1cclxuXHJcbnVsIGxpLmhpZ2hsaWdodCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRENEQ0RDICFpbXBvcnRhbnQ7XHJcblxyXG59XHJcblxyXG51bCBsaSB7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi8qIFNwbGl0dGVyKi9cclxuLyojbG9hZGVyIHsqL1xyXG4vKiAgICBjb2xvcjogIzAwOGNmZjsqL1xyXG4vKiAgICBoZWlnaHQ6IDQwcHg7Ki9cclxuLyogICAgbGVmdDogNDUlOyovXHJcbi8qICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTsqL1xyXG4vKiAgICB0b3A6IDQ1JTsqL1xyXG4vKiAgICB3aWR0aDogMzAlOyovXHJcbi8qfSovXHJcblxyXG4vKi5jb250ZW50IHsqL1xyXG4vKiAgICBwYWRkaW5nOiA5cHg7Ki9cclxuLyp9Ki9cclxuXHJcbi8qI2xlZnQtcGFuZS1jb250ZW50LCovXHJcbi8qI21pZGRsZS1wYW5lLWNvbnRlbnQsKi9cclxuLyojbGFzdC1wYW5lLWNvbnRlbnQgeyovXHJcbi8qICAgIHRleHQtYWxpZ246IGxlZnQ7Ki9cclxuLyogICAgISphbGlnbi1pdGVtczogbm9ybWFsOyohKi9cclxuLyogICAganVzdGlmeS1jb250ZW50OiBsZWZ0OyovXHJcbi8qICAgIGRpc3BsYXk6IGZsZXg7Ki9cclxuLyogICAgaGVpZ2h0OiA4MHZoOyovXHJcbi8qICAgIG1hcmdpbjogMjBweDsqL1xyXG4vKiAgICBvdmVyZmxvdzogaGlkZGVuOyovXHJcbi8qfSovXHJcblxyXG4vKiNwYW5ldGV4dCB7Ki9cclxuLyogICAgZm9udC1zaXplOiAxMXB4OyovXHJcbi8qfSovXHJcblxyXG4vKiNjb250YWluZXIgeyovXHJcbi8qICAgIG1hcmdpbjogMHB4IGF1dG87Ki9cclxuLyp9Ki9cclxuXHJcbi8qI3RlbXBsYXRlX2NvbnRhaW5lciB7Ki9cclxuLyogICAgbWFyZ2luOiA2MHB4IGF1dG87Ki9cclxuLyp9Ki9cclxuXHJcbi8qLmF1dG8tc2l6ZS1jb250ZW50LCAudGVtcGxhdGUgeyovXHJcbi8qICAgIHBhZGRpbmc6IDlweDsqL1xyXG4vKn0qL1xyXG5cclxuLyojbG9hZGVyIHsqL1xyXG4vKiAgICBjb2xvcjogIzAwOGNmZjsqL1xyXG4vKiAgICBoZWlnaHQ6IDQwcHg7Ki9cclxuLyogICAgbGVmdDogNDUlOyovXHJcbi8qICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTsqL1xyXG4vKiAgICB0b3A6IDQ1JTsqL1xyXG4vKiAgICB3aWR0aDogMzAlOyovXHJcbi8qfSovXHJcblxyXG4vKiNjb2RlLXRleHQgeyovXHJcbi8qICAgIG1hcmdpbi1sZWZ0OiA1cHg7Ki9cclxuLyp9Ki9cclxuXHJcbi8qLmNvZGUtcHJldmlldyB7Ki9cclxuLyogICAgbWFyZ2luLXRvcDogMTVweDsqL1xyXG4vKiAgICBmb250LXNpemU6IDEycHg7Ki9cclxuLyp9Ki9cclxuXHJcbi8qLmgzIHsqL1xyXG4vKiAgICBmb250LXNpemU6IDE0cHg7Ki9cclxuLyogICAgbWFyZ2luOiA0cHg7Ki9cclxuLyp9Ki9cclxuXHJcbi8qLmNvbnRlbnQgeyovXHJcbi8qICAgIHBhZGRpbmc6IDEycHg7Ki9cclxuLyp9Ki9cclxuXHJcbi8qLnNwbGl0dGVyLWltYWdlIHsqL1xyXG4vKiAgICBtYXJnaW46IDAgYXV0bzsqL1xyXG4vKiAgICBkaXNwbGF5OiBmbGV4OyovXHJcbi8qICAgIGhlaWdodDogMTE1cHg7Ki9cclxuLyogICAgbWFyZ2luLXRvcDogMTBweDsqL1xyXG4vKn0qL1xyXG5cclxuLyojY29udGFpbmVyIHsqL1xyXG4vKiAgICBtYXJnaW46IDMwcHg7Ki9cclxuLyp9Ki9cclxuXHJcbi8qI2xvYWQtY29udGVudC1jb250YWluZXIgeyovXHJcbi8qICAgIG1hcmdpbjogNjBweCBhdXRvOyovXHJcbi8qfSovXHJcblxyXG5cclxuXHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/elasticity/elasticity/elasticity.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/elasticity/elasticity/elasticity.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"main\">\n    <div style=\"width: 100%; height: 82vh; \">\n        <as-split direction=\"horizontal\" (dragEnd)=\"refreshChart()\">\n            <as-split-area [size]=\"20\">\n                <as-split direction=\"vertical\">\n                    <as-split-area [size]=\"45\">\n                        <div class=\"row\" style=\"margin-right: .2%!important; font-size: .9em\">\n                            <div class=\"col\">\n                                <p>Select Product and Price Range</p>\n                                <select class=\"selectpicker\" style=\"width: 100%\"\n                                        (change)=\"selectPriceAttribute($event)\">\n                                    <option>{{utilManagementService.productSet[utilManagementService.priceAtt]}}</option>\n                                </select>\n                                <select class=\"selectpicker\" style=\"width: 100%; margin-top: 5%\"\n                                        (change)=\"selectProduct($event)\">\n                                    <option *ngFor=\"let product of sceManagementService.selectedScenario.products\">{{product.name}}</option>\n                                </select>\n\n                                <!--                        <div class=\"row\" style=\"width: 100%; margin-right: .5%; margin-left: .5%\">-->\n                                <div class=\"row\"\n                                     style=\"padding-top: 5%;width: 100%; margin-right: .5%; margin-left: .5%\">\n                                    <div class=\"col-6\" style=\"padding-left: 0; padding-right: 0\">Start Price</div>\n                                    <div class=\"col-6\" style=\"padding-left: 0; padding-right: 0\">\n                                        <select class=\"selectpicker\" style=\"width: 100%\"\n                                                (change)=\"selectPriceMin($event)\">\n                                            <option>Select</option>\n                                            <option *ngFor=\"let price of headerService.priceRange\"\n                                                    [selected]=\"price == headerService.priceMin2\">{{price}}</option>\n                                        </select>\n                                    </div>\n                                </div>\n                                <div class=\"row\"\n                                     style=\"padding-top: 5%;width: 100%; margin-right: .5%; margin-left: .5%\">\n                                    <div class=\"col-6\" style=\"padding-left: 0; padding-right: 0\">End Price</div>\n                                    <div class=\"col-6\" style=\"padding-left: 0; padding-right: 0\">\n                                        <select class=\"selectpicker\" style=\"width: 100%\"\n                                                (change)=\"selectPriceMax($event)\">\n                                            <option>Select</option>\n                                            <option *ngFor=\"let price of headerService.priceRange\"\n                                                    [selected]=\"price == headerService.priceMax2\">{{price}}</option>\n                                        </select>\n                                    </div>\n                                </div>\n                                <div class=\"row\"\n                                     style=\"padding-top: 5%;width: 100%; margin-right: .5%; margin-left: .5%\">\n                                    <div class=\"col-6\" style=\"padding-left: 0; padding-right: 0\">Increment</div>\n                                    <div class=\"col-6\" style=\"padding-left: 0; padding-right: 0\">\n                                        <input type=\"number\" style=\"width: 100%\"\n                                               [(ngModel)]=\"headerService.increment2\">\n                                    </div>\n                                </div>\n                                <div class=\"row\"\n                                     style=\"padding-top: 5%;width: 100%; margin-right: .5%; margin-left: .5%\">\n                                    <button class=\"btn btn-sm btn-primary\" style=\"width: 100%\"\n                                            (click)=\"calculate()\">Calculate\n                                    </button>\n\n                                </div>\n                                <div class=\"row\"\n                                     style=\"padding-top: 5%;color: darkred; width: 100%; margin-right: .5%; margin-left: .5%\">\n                                    <span>{{elasticityService.message}}</span>\n                                </div>\n\n                                <!--                        </div>-->\n\n                            </div>\n                        </div>\n                    </as-split-area>\n                    <as-split-area [size]=\"55\">\n                        <div id='segmentSection' class=\"row\"\n                             style=\"padding-top: 5%;width: 100%; margin-right: .5%; margin-left: .5%; display: none; font-size: .9em!important\">\n                            <p>Select Segment</p>\n                            <ul id=\"myUL\">\n                                <li [ngClass]=\"{'highlight': segment['cell_1'] == elasticityService.selectedLevel}\"\n                                    (mousedown)=\"toggleTree(segment['cell_1'])\"\n                                    *ngFor=\"let segment of prodManagementService.segments; let i = index\"><span\n                                        class=\"caret\">{{segment['cell_1']}}</span>\n                                    <ul class=\"nested\">\n                                        <li [ngClass]=\"{'highlight': level == elasticityService.selectedLevel}\"\n                                            (click)=\"calculateLevel(level, segment['cell_1'])\"\n                                            *ngFor=\"let level of prodManagementService.segmentLevels[i]\">\n                                            <span><i class=\"fa fa-minus\"></i></span> {{level}}</li>\n                                    </ul>\n                                </li>\n                            </ul>\n                        </div>\n                    </as-split-area>\n                </as-split>\n            </as-split-area>\n            <as-split-area [size]=\"80\" (dragEnd)=\"refreshChart()\">\n                <as-split direction=\"vertical\" (dragEnd)=\"refreshChart()\">\n                    <as-split-area [size]=\"33\">\n<!--                        <button id=\"collapseBtn\" class=\"collapsible\"-->\n<!--                                (click)=\"collapsePanel('elasticityTable', 'collapseBtn')\"-->\n<!--                                style=\"background-color: #2a6496; color: white;\">-->\n<!--                            Elasticity-->\n<!--                        </button>-->\n                        <button id=\"collapseBtn\" class=\"collapsible\"\n                                style=\"background-color: #2a6496; color: white;\">\n                            Elasticity\n                        </button>\n                        <div class=\"col\" style=\"overflow: hidden!important; height: 88%;width: 80%; margin-left: 10%; align-content: center\" id=\"chart-div\">\n                            <ejs-chart #chart style=\"height: 100%; width: 100%; alignment: center; margin-top: 0%\" id=\"elasticity-chart-container\"\n                                       [zoomSettings]=\"zoom\" [title]=\"title\"\n                                       [tooltip]=\"tooltip\" [primaryXAxis]=\"xAxis\" [primaryYAxis]=\"yAxis\"\n                                       [palettes]=\"colorService.color$ | async\">\n                                <e-series-collection>\n                                    <e-series [dataSource]='chartData' type='Line' xName='Price'\n                                              yName='Product' [marker]='marker'\n                                              name=\"{{elasticityService.selectedProduct.name}}\"></e-series>\n                                </e-series-collection>\n                            </ejs-chart>\n\n                                    <button id=\"exportBtn\" class=\"btn btn-sm btn-primary btn-block\"\n                                            style=\"width: 15%; right: .5%; color: #fff; bottom: 5%; margin-right: 3%; position: absolute;z-index: 99999!important; \"\n                                            (click)=\"openModal(exportModal)\" disabled>Export in Excel\n                                    </button>\n\n\n                        </div>\n                    </as-split-area>\n                    <as-split-area [size]=\"11\">\n\n                        <div id=\"elasticityTable\" class=\"row content\" style=\"margin: .1%; padding: 0!important;overflow-y: hidden!important\">\n<!--                            <span>Elasticity Table</span>-->\n                            <table class=\"table\" *ngIf=\"this.elasticityService.elasticity === undefined\"\n                                   style=\"overflow: hidden; alignment: left; margin-top: .2%; width: 100%; display: inline-block\">\n                                <tbody>\n                                <tr>\n                                    <td style=\"width: 100vw; height: 14px\"></td>\n                                </tr>\n                                <tr>\n                                    <td style=\"width: 100vw; height: 14px\"></td>\n                                </tr>\n                                <tr>\n                                    <td style=\"width: 100vw; height: 14px\"></td>\n                                </tr>\n                                <tr>\n                                    <td style=\"width: 100vw; height: 14px\"></td>\n                                </tr>\n                                </tbody>\n                            </table>\n                            <table class=\"table table-bordered table-hover\" style=\"alignment: left;\"\n                                   *ngIf=\"this.elasticityService.elasticity !== undefined\">\n                                <thead class=\"thead-light\">\n                                <tr *ngFor=\"let prod of elasticityService.adjustedRevenue | keyvalue\">\n                                    <th></th>\n                                    <th *ngFor=\"let elasticity of prod.value | keyvalue\">{{elasticity.key}}</th>\n                                </tr>\n                                </thead>\n                                <tbody>\n                                <tr *ngFor=\"let prod of elasticityService.elasticity | keyvalue\">\n                                    <td>{{prod.key}}</td>\n                                    <td *ngFor=\"let elasticity of prod.value | keyvalue\"> {{ elasticity.value}}</td>\n                                </tr>\n                                </tbody>\n                            </table>\n\n                        </div>\n\n                    </as-split-area>\n                    <as-split-area [size]=\"31\">\n<!--                        <button id=\"collapseBtn2\" class=\"collapsible\"-->\n<!--                                (click)=\"collapsePanel('revenueTable', 'collapseBtn2')\"-->\n<!--                                style=\"background-color: #2a6496; color: white;\">-->\n<!--                            Adjusted Revenue-->\n<!--                        </button>-->\n                        <button id=\"collapseBtn2\" class=\"collapsible\"\n                                style=\"background-color: #2a6496; color: white;\">\n                            Adjusted Revenue\n                        </button>\n                        <div class=\"col\" style=\"overflow: hidden!important; height: 88%; width: 80%; margin-left: 10%; align-content: center\" id=\"rev-chart-div\">\n                            <ejs-chart #chart2 style=\"height: 100%; width: 100%;\" [title]=\"title\"\n                                       id=\"revenue-chart-container\" [tooltip]=\"tooltip2\"\n                                       [primaryXAxis]=\"xAxis2\" [primaryYAxis]=\"yAxis2\"\n                                       [palettes]=\"colorService.color$ | async\">\n                                <e-series-collection>\n                                    <e-series [dataSource]='chartData2' type='Line' xName='Price'\n                                              yName='Product' [marker]='marker'\n                                              name=\"{{elasticityService.selectedProduct.name}}\"></e-series>\n                                </e-series-collection>\n                            </ejs-chart>\n                        </div>\n\n                    </as-split-area>\n                    <as-split-area [size]=\"11\">\n\n\n                        <div id=\"revenueTable\" class=\"row content\" style=\"margin: .1%; padding: 0!important;\">\n<!--                            <span>Adjusted Revenue Table</span>-->\n                            <table class=\"table\" *ngIf=\"this.elasticityService.revenue === undefined\"\n                                   style=\"overflow: auto; alignment: left; margin-top: .2%; width: 100%; display: inline-block\">\n                                <tbody >\n                                <tr>\n                                    <td style=\"width: 100vw; height: 14px\"></td>\n                                </tr>\n                                <tr>\n                                    <td style=\"width: 100vw; height: 14px\"></td>\n                                </tr>\n                                <tr>\n                                    <td style=\"width: 100vw; height: 14px\"></td>\n                                </tr>\n                                <tr>\n                                    <td style=\"width: 100vw; height: 14px\"></td>\n                                </tr>\n                                </tbody>\n                            </table>\n                            <table class=\"table table-bordered\" style=\"alignment: left;\" *ngIf=\"this.elasticityService.revenue !== undefined\">\n                                <thead class=\"thead-light\">\n                                <tr *ngFor=\"let prod of elasticityService.adjustedRevenue | keyvalue\">\n                                    <th></th>\n                                    <th\n                                            *ngFor=\"let elasticity of prod.value | keyvalue\">{{elasticity.key}}</th>\n                                </tr>\n                                </thead>\n\n                                <tbody >\n                                <tr>\n                                    <td>{{elasticityService.selectedProduct.name}}</td>\n                                    <td *ngFor=\"let rev of elasticityService.revenue | keyvalue\">{{rev.value}}</td>\n                                </tr>\n                                </tbody>\n\n                            </table>\n                        </div>\n\n                    </as-split-area>\n\n                    <as-split-area [size]=\"14\">\n<!--                        <button id=\"collapseBtn3\" class=\"collapsible\"-->\n<!--                                (click)=\"collapsePanel('productDiv', 'collapseBtn3')\"-->\n<!--                                style=\"margin: 0px!important; background-color: #2a6496; color: white;\">Products-->\n<!--                        </button>-->\n                        <button id=\"collapseBtn3\" class=\"collapsible\"\n                                style=\"margin: 0px!important; background-color: #2a6496; color: white;\">Products\n                        </button>\n                        <div id=\"productDiv\" class=\"row content\" style=\"margin: .1%; padding: 0%!important\">\n                            <table class=\"table\" *ngIf=\"elasticityService.selectedProduct === undefined\"\n                                   style=\"overflow: auto; alignment: left; margin-top: .2%; width: 100%; display: inline-block\">\n                                <tbody>\n                                <tr>\n                                    <td style=\"width: 100vw; height: 14px\"></td>\n                                </tr>\n                                <tr>\n                                    <td style=\"width: 100vw; height: 14px\"></td>\n                                </tr>\n                                <tr>\n                                    <td style=\"width: 100vw; height: 14px\"></td>\n                                </tr>\n                                <tr>\n                                    <td style=\"width: 100vw; height: 14px\"></td>\n                                </tr>\n                                </tbody>\n                            </table>\n                            <table class=\"table table-bordered table-hover\" *ngIf=\"elasticityService.selectedProduct !== undefined\"\n                                   style=\"width: 100%; alignment: left;\">\n                                <thead class=\"thead-light\">\n                                <tr>\n                                    <th></th>\n                                    <th\n                                            *ngFor=\"let att of elasticityService.selectedProduct.attribute | keyvalue: returnZero\">{{att.key}}</th>\n                                </tr>\n                                </thead>\n                                <tbody >\n\n                                <tr>\n                                    <td>{{elasticityService.selectedProduct.name}}</td>\n                                    <td *ngFor=\"let att of elasticityService.selectedProduct.attributeValues\">{{att}}</td>\n                                </tr>\n\n                                </tbody>\n\n                            </table>\n\n                        </div>\n\n                    </as-split-area>\n                </as-split>\n            </as-split-area>\n\n            <button class=\"open-button shadow p-3 mb-5 rounded\" (mousedown)=\"showHelpDesk()\">Help Desk</button>\n\n            <div class=\"chat-popup\" id=\"myForm\">\n                <form class=\"form-container\">\n                    <h5>Help Desk</h5>\n                    <ul>\n                        <li>< 1: Inelastic: Price can be increased with less decrease in units. It means the price can\n                            be increased to improve revenues.\n                        </li>\n                        <li>= 1: Unit Elasticity: At this price level, an increase in price will be equally offset by a\n                            decrease in units.\n                        </li>\n                        <li> 1: Elastic: A price increase will be accompanied by a greater decrease in units. It means\n                            that a price increase will result in lower total revenue.\n                        </li>\n                    </ul>\n                    <!--            <textarea id=\"msg\" required readonly>This is a preference description</textarea>-->\n                    <button type=\"button\" class=\"btn btn-primary\" (click)=\"showHelpDesk()\">Close</button>\n                </form>\n            </div>\n        </as-split>\n    </div>\n\n    <!-- Message Modal -->\n    <ng-template #messageModal let-modal>\n        <div class=\"modal-header\">\n            <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\n                <span aria-hidden=\"true\">&times;</span>\n            </button>\n        </div>\n        <div class=\"modal-body\" style=\"padding-left: 10px\">\n            <p>{{exportStatus}}</p>\n        </div>\n    </ng-template>\n    <!-- export Modal -->\n    <ng-template #exportModal let-modal style=\"width: 100vw\">\n        <div class=\"modal-header\">\n            <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\n                <span aria-hidden=\"true\">&times;</span>\n            </button>\n        </div>\n        <div class=\"modal-body\" style=\"padding-left: 10px\">\n            <div class=\"row\" style=\"padding: 5%\">\n\n                <button class=\"btn btn-sm btn-primary btn-block shadow-lg\"\n                        (click)=\"saveFile(messageModal); modal.dismiss()\" style=\"font-size: .8em\">Append to an existing file</button>\n            </div>\n            <div class=\"row\" style=\"padding: 5%\">\n                <button class=\"btn btn-sm btn-primary btn-block shadow-lg\"\n                        (click)=\"exportAsExcelFile(messageModal); modal.dismiss()\" style=\"font-size: .8em\">Save as new file</button>\n\n\n            </div>\n        </div>\n        <div class=\"modal-footer\">\n\n        </div>\n    </ng-template>\n\n</div>\n\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\n"

/***/ }),

/***/ "./src/app/elasticity/elasticity/elasticity.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/elasticity/elasticity/elasticity.component.ts ***!
  \***************************************************************/
/*! exports provided: ElasticityComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ElasticityComponent", function() { return ElasticityComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @syncfusion/ej2-angular-charts */ "./node_modules/@syncfusion/ej2-angular-charts/@syncfusion/ej2-angular-charts.es5.js");
/* harmony import */ var _elasticity_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../elasticity.service */ "./src/app/elasticity/elasticity.service.ts");
/* harmony import */ var _core_header_header_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../core/header/header.service */ "./src/app/core/header/header.service.ts");
/* harmony import */ var _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../scenario/scenariomanagement.service */ "./src/app/scenario/scenariomanagement.service.ts");
/* harmony import */ var _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../utility/utilitymanagement.service */ "./src/app/utility/utilitymanagement.service.ts");
/* harmony import */ var _service_chart_color_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../service/chart-color.service */ "./src/app/service/chart-color.service.ts");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! exceljs/dist/exceljs.min.js */ "./node_modules/exceljs/dist/exceljs.min.js");
/* harmony import */ var exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../product/productmanagement.service */ "./src/app/product/productmanagement.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var browser_nativefs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! browser-nativefs */ "./node_modules/browser-nativefs/dist/index.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! xlsx */ "./node_modules/xlsx/xlsx.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_14__);















var ElasticityComponent = /** @class */ (function () {
    function ElasticityComponent(modalService, elasticityService, headerService, sceManagementService, utilManagementService, colorService, utilityService, prodManagementService, router) {
        var _this = this;
        this.modalService = modalService;
        this.elasticityService = elasticityService;
        this.headerService = headerService;
        this.sceManagementService = sceManagementService;
        this.utilManagementService = utilManagementService;
        this.colorService = colorService;
        this.utilityService = utilityService;
        this.prodManagementService = prodManagementService;
        this.router = router;
        this.marker = {
            visible: true,
            height: 10,
            width: 10
        };
        if (this.elasticityService.relativeResult === undefined) {
            this.chartData = [];
            this.chartData2 = [];
        }
        this.utilityService.cast.subscribe(function (utl) {
            if ((utilManagementService.priceAtt === '') || headerService.disableElasticityHeader.toString() === 'true') {
                _this.router.navigate(['/preference']);
            }
            _this.utility = utl;
            _this.elasticityService.message = '';
            _this.xAxis = {
                valueType: 'Category',
                title: 'Price'
            };
            _this.yAxis = {
                minimum: 0,
                interval: 2,
                title: 'Elasticity'
            };
            _this.xAxis2 = {
                valueType: 'Category',
                title: 'Price'
            };
            _this.yAxis2 = {
                minimum: 0,
                maximum: 1,
                title: 'Adjusted Revenue'
            };
            _this.tooltip = { enable: true, header: 'Elasticity', format: '<b>${point.x} : ${point.y}</b>' };
            _this.tooltip2 = { enable: true, header: 'Adjusted Revenue', format: '<b>${point.x} : ${point.y}</b>' };
            _this.zoom = {
                enableMouseWheelZooming: true,
                enableDeferredZooming: true,
                enablePinchZooming: true,
                enableSelectionZooming: true
            };
            if (_this.headerService.increment === 0) {
                _this.resetValues();
            }
            if (_this.elasticityService.selectedProduct === undefined)
                _this.elasticityService.selectedProduct = _this.sceManagementService.selectedScenario.products[0];
            /* Calculate min increment */
            _this.elasticityService.minIncrement = (Number(_this.headerService.priceRange[_this.headerService.priceRange.length - 1]) -
                Number(_this.headerService.priceRange[0])) * .01;
        });
    }
    ElasticityComponent.prototype.ngAfterViewInit = function () {
    };
    ElasticityComponent.prototype.ngOnInit = function () {
        if (this.elasticityService.relativeResult === undefined)
            this.elasticityService.selectedProduct = this.sceManagementService.selectedScenario.products[0];
        if (this.elasticityService.relativeResult !== undefined)
            this.calculate();
        this.segmentLevels = [];
        for (var i in this.prodManagementService.segments) {
            var cnt = 0;
            var temp = [];
            while (this.prodManagementService.segments[i]['cell_3_' + cnt]) {
                temp.push(this.prodManagementService.segments[i]['cell_3_' + (cnt++)]);
            }
            this.segmentLevels.push(temp);
        }
    };
    ElasticityComponent.prototype.showHelpDesk = function () {
        var helpdesk = document.getElementById('myForm');
        if (helpdesk.style.display === 'none') {
            helpdesk.style.display = 'block';
        }
        else {
            helpdesk.style.display = 'none';
        }
    };
    ElasticityComponent.prototype.openModal = function (targetModal) {
        this.modalService.open(targetModal, {
            centered: true,
            backdrop: 'static',
            size: 'sm'
        });
    };
    ElasticityComponent.prototype.returnZero = function () {
        return 0;
    };
    ElasticityComponent.prototype.refreshChart = function () {
        this.chartObj.refresh();
        this.chartObj2.refresh();
    };
    ElasticityComponent.prototype.selectPriceAttribute = function (event) {
    };
    ElasticityComponent.prototype.toggleTree = function (segment) {
        this.elasticityService.selectedLevel = segment;
        var toggler = document.getElementsByClassName('caret');
        for (var i = 0; i < toggler.length; i++) {
            toggler[i].addEventListener('click', function () {
                this.parentElement.querySelector('.nested').classList.toggle('active');
                this.classList.toggle('caret-down');
            });
        }
        this.calculate();
    };
    ElasticityComponent.prototype.selectProduct = function (event) {
        this.productList = this.sceManagementService.selectedScenario.products;
        var product = this.productList.find(function (prod) { return prod.name === event.target.value; });
        if (this.elasticityService.selectedProduct.name !== product.name) {
            // this.elasticityService.elasticity = undefined;
            this.elasticityService.selectedProduct = product;
            this.resetValues();
        }
    };
    ElasticityComponent.prototype.selectPriceMin = function (event) {
        this.headerService.priceMin2 = Number(event.target.value);
    };
    ElasticityComponent.prototype.selectPriceMax = function (event) {
        this.headerService.priceMax2 = Number(event.target.value);
    };
    ElasticityComponent.prototype.resetValues = function () {
        this.elasticityService.elasticity = undefined;
        this.elasticityService.adjustedRevenue = undefined;
        this.elasticityService.relativeTotal = undefined;
        /* Enable export button*/
        if (document.getElementById('exportBtn'))
            document.getElementById('exportBtn').disabled = true;
        /* Hide segment section*/
        if (document.getElementById('segmentSection'))
            document.getElementById('segmentSection').style.display = 'none';
    };
    ElasticityComponent.prototype.calculate = function () {
        var _this = this;
        try {
            this.chartData = [];
            this.chartData2 = [];
            this.elasticityService.message = '';
            if (this.headerService.priceMin2 !== 0 && this.headerService.priceMax2 !== 0 && this.headerService.increment2 >= this.elasticityService.minIncrement) {
                this.elasticityService.calculate();
                this.elasticityService.elasticity.forEach(function (value, key) {
                    value.forEach(function (value2, key2) {
                        _this.chartData.push({ Price: key2, Product: value2 });
                    });
                });
                this.elasticityService.adjustedRevenue.forEach(function (value, key) {
                    value.forEach(function (value2, key2) {
                        _this.chartData2.push({ Price: key2, Product: value2 });
                    });
                });
                if (this.elasticityService.selectedLevel) {
                    this.title = this.elasticityService.selectedLevel + ': Total';
                }
            }
            else {
                this.elasticityService.message = 'Error! Please check price parameters. Price increment should be at least 1% of price range.';
            }
            if (this.elasticityService.selectedLevel) {
                this.title = this.elasticityService.selectedLevel + ': Total';
            }
        }
        catch (e) {
            this.title = '';
            this.elasticityService.elasticity = undefined;
            this.elasticityService.adjustedRevenue = undefined;
            this.elasticityService.message = 'Error! Please check price parameters!';
        }
        if (this.elasticityService.relativeTotal !== undefined) {
            /* Enable export button*/
            document.getElementById('exportBtn').disabled = false;
            document.getElementById('segmentSection').style.display = 'block';
        }
    };
    ElasticityComponent.prototype.calculateLevel = function (level, segment) {
        var _this = this;
        try {
            // const toggler = document.getElementsByClassName('caret');
            // for (let i = 0; i < toggler.length; i++) {
            //     console.log(toggler[i], toggler[i].id);
            //     if (toggler[i].id === level) {
            //         toggler[i].className = 'caret-down';
            //     } else {
            //         toggler[i].className = 'caret';
            //     }
            // }
            /* Enable export button*/
            document.getElementById('exportBtn').disabled = false;
            this.chartData = [];
            this.chartData2 = [];
            this.elasticityService.message = '';
            this.elasticityService.selectedProduct = this.sceManagementService.selectedScenario.products[0];
            this.elasticityService.selectSegmentLevel(level, segment);
            this.elasticityService.elasticity.forEach(function (value, key) {
                value.forEach(function (value2, key2) {
                    _this.chartData.push({ Price: key2, Product: value2 });
                });
            });
            this.elasticityService.adjustedRevenue.forEach(function (value, key) {
                value.forEach(function (value2, key2) {
                    _this.chartData2.push({ Price: key2, Product: value2 });
                });
            });
            this.title = segment + ': ' + level;
        }
        catch (e) {
            this.title
                = '';
            this.elasticityService.message = 'Error! Please check price parameters!';
        }
    };
    ElasticityComponent.prototype.exportAsExcelFile = function (targetModal) {
        var _this = this;
        var sce = this.sceManagementService.selectedScenario;
        var workbook = new exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_10__["Workbook"]();
        var title = 'SimPRO Price Elasticity';
        var worksheet = workbook.addWorksheet('Price Elasticity');
        // const worksheet2 = workbook.addWorksheet('Chart');
        // Add Row and formatting
        // const titleRow = worksheet.addRow([title]);
        // titleRow.font = {name: 'Arial', family: 4, size: 13, underline: 'double', bold: true};
        worksheet.addRow([]);
        worksheet.addRow([this.utility.name]);
        var sceRow = worksheet.addRow([sce.name, sce.savingDate]);
        sceRow.font = { name: 'Arial' };
        worksheet.addRow([]);
        // Product table
        var tableRow = worksheet.addRow(['Table of Products']);
        tableRow.font = { bold: true };
        tableRow.alignment = { vertical: 'middle', horizontal: 'left' };
        var header = new Array();
        header.push('Product');
        sce.products[0].attribute.forEach(function (value, key) {
            header.push(key);
        });
        var headRow = worksheet.addRow(header);
        headRow.font = { bold: true };
        var _loop_1 = function (prod) {
            var product = new Array();
            product.push(prod.name);
            prod.attributeValues.forEach(function (value, key) {
                product.push(value);
            });
            var prodTable = worksheet.addRow(product);
        };
        for (var _i = 0, _a = sce.products; _i < _a.length; _i++) {
            var prod = _a[_i];
            _loop_1(prod);
        }
        worksheet.addRow([[], []]);
        // Elasticity table
        var simulation = worksheet.addRow(['Elasticity']);
        simulation.font = { name: 'Arial', family: 4, size: 12, italic: true };
        var elasticityRow = [];
        var headerRow = [];
        headerRow.push('Product');
        this.elasticityService.elasticity.forEach(function (value, key) {
            var temp = [];
            temp.push(key);
            value.forEach(function (value2, key2) {
                headerRow.push(key2);
                temp.push(value2);
            });
            elasticityRow.push(temp);
        });
        var rowHeader = worksheet.addRow(headerRow);
        rowHeader.font = { bold: true };
        var elasticityTableRow = worksheet.addRows(elasticityRow);
        worksheet.addRows(['']);
        worksheet.addRows(['']);
        // Revenue Table
        var revenueRow = [];
        var revHeaderRow = [];
        revHeaderRow.push('Product');
        this.elasticityService.adjustedRevenue.forEach(function (value, key) {
            var temp = [];
            temp.push(key);
            value.forEach(function (value2, key2) {
                revHeaderRow.push(key2);
            });
            _this.elasticityService.revenue.forEach(function (value3, key3) {
                temp.push(value3);
            });
            var revRow = revenueRow.push(temp);
        });
        var revRowHeader = worksheet.addRow(revHeaderRow);
        revRowHeader.font = { bold: true };
        revRowHeader.alignment = { vertical: 'middle', horizontal: 'left' };
        worksheet.addRows(revenueRow);
        // Wrap cells
        for (var rowIndex = 1; rowIndex < worksheet.rowCount; rowIndex++) {
            worksheet.getRow(rowIndex).alignment = { vertical: 'middle', horizontal: 'left' };
        }
        // Add Elasticity Chart Image
        // html2canvas(document.querySelector('#elasticity-chart-container')).then(canvas => {
        //     let image = canvas.toDataURL('image/png', 1.0);
        //     image = image.replace(/^data:image\/(png|jpg);base64,/, '');
        //     const imageId1 = workbook.addImage({
        //         base64: image,
        //         extension: 'png',
        //     });
        //
        //     worksheet2.addImage(imageId1, 'M2:U8');
        // });
        // Add Revenue Chart Image
        // html2canvas(document.querySelector('#revenue-chart-container')).then(canvas => {
        //     let image = canvas.toDataURL('image/png', 1.0);
        //     image = image.replace(/^data:image\/(png|jpg);base64,/, '');
        //     const imageId1 = workbook.addImage({
        //         base64: image,
        //         extension: 'png',
        //     });
        //
        //     worksheet2.addImage(imageId1, 'C25:Q45');
        // });
        setTimeout(function () {
            workbook.xlsx.writeBuffer().then(function (data2) {
                var blob = new Blob([data2], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                // fs.saveAs(blob, 'TMTG_simpro_export.xlsx');
                var options = {
                    // Suggested file name to use, defaults to `''`.
                    fileName: 'TMTG_simpro_export.xlsx',
                    // Suggested file extensions (with leading '.'), defaults to `''`.
                    extensions: ['.xlsx'],
                };
                // Optional file handle to save back to an existing file.
                // This will only work with the File System Access API.
                // Get a `FileHandle` from the `handle` property of the `Blob`
                // you receive from `fileOpen()` (this is non-standard).
                // const handle = previouslyOpenedBlob.handle;
                _this.saveAsNewFile(targetModal, blob, options).then(function (e) {
                    _this.exportStatus = 'File successfully exported.';
                    _this.modalService.open(targetModal, {
                        centered: true,
                        backdrop: 'static',
                        size: 'sm'
                    });
                }).catch(function (e) {
                    _this.exportStatus = 'Error! Please make sure file is closed.';
                    _this.modalService.open(targetModal, {
                        centered: true,
                        backdrop: 'static',
                        size: 'sm'
                    });
                });
            });
        }, 2500);
    };
    ElasticityComponent.prototype.saveFile = function (targetModal) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var workbook, fileReader, options2, blob;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        workbook = new exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_10__["Workbook"]();
                        fileReader = new FileReader();
                        options2 = {
                            // List of allowed MIME types, defaults to `*/*`.
                            mimeTypes: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
                            // List of allowed file extensions (with leading '.'), defaults to `''`.
                            extensions: ['.xlsx'],
                            // Set to `true` for allowing multiple files, defaults to `false`.
                            multiple: false,
                        };
                        return [4 /*yield*/, Object(browser_nativefs__WEBPACK_IMPORTED_MODULE_13__["fileOpen"])(options2)];
                    case 1:
                        blob = _a.sent();
                        // @ts-ignore
                        fileReader.readAsBinaryString(new Blob([blob], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
                        fileReader.onload = function (z) {
                            var wb = xlsx__WEBPACK_IMPORTED_MODULE_14__["read"](fileReader.result, { type: 'binary' });
                            var sheetNames = wb.SheetNames;
                            // Copy sheets
                            if (sheetNames.indexOf('Price Elasticity') < 0) {
                                workbook.addWorksheet('Price Elasticity');
                            }
                            for (var j in sheetNames) {
                                var workSheet = workbook.addWorksheet(sheetNames[j]);
                                workSheet.addRow([]);
                                // Add Row and formatting
                                // const title = 'SimPRO Price Sensitivity';
                                // const titleRow = workSheet.addRow([title]);
                                // titleRow.font = {name: 'Arial', family: 4, size: 13, underline: 'double', bold: true};
                                // Add utility name
                                var rows = xlsx__WEBPACK_IMPORTED_MODULE_14__["utils"].sheet_to_json(wb.Sheets[sheetNames[j]], { raw: false });
                                workSheet.addRow([Object.keys(rows[0])[0]]);
                                for (var _i = 0, _a = xlsx__WEBPACK_IMPORTED_MODULE_14__["utils"].sheet_to_json(wb.Sheets[sheetNames[j]], { raw: false }); _i < _a.length; _i++) {
                                    var i = _a[_i];
                                    var tempArr = [];
                                    for (var n in i) {
                                        tempArr.push(i[n]);
                                    }
                                    if (tempArr[0] === 'Table of Products' || tempArr[0] === 'Simulation') {
                                        workSheet.addRow([]);
                                        var row = workSheet.addRow(tempArr);
                                        row.font = { bold: true, italic: true };
                                        row.alignment = { vertical: 'middle', horizontal: 'left' };
                                    }
                                    else if (tempArr[0] === 'Product') {
                                        var row = workSheet.addRow(tempArr);
                                        row.font = { bold: true };
                                        row.alignment = { vertical: 'middle', horizontal: 'left' };
                                    }
                                    else {
                                        var row = workSheet.addRow(tempArr);
                                        row.alignment = { vertical: 'middle', horizontal: 'left' };
                                    }
                                }
                            }
                            // @ts-ignore
                            _this.addSheet(workbook.getWorksheet('Price Elasticity'), workbook, blob.handle, targetModal);
                        };
                        return [2 /*return*/];
                }
            });
        });
    };
    ElasticityComponent.prototype.addSheet = function (worksheet, workbook, fileHandle, targetModal) {
        var _this = this;
        worksheet.addRow([]);
        var sce = this.sceManagementService.selectedScenario;
        // Add Row and formatting
        // const title = 'SimPRO Price Elasticity';
        // const titleRow = worksheet.addRow([title]);
        // titleRow.font = {name: 'Arial', family: 4, size: 13, underline: 'double', bold: true};
        worksheet.addRow([]);
        worksheet.addRow([this.utility.name]);
        // Add Row and formatting
        var sceRow = worksheet.addRow([sce.name, sce.savingDate]);
        sceRow.alignment = { vertical: 'middle', horizontal: 'left' };
        worksheet.addRow([]);
        // Product table
        var tableRow = worksheet.addRow(['Table of Products']);
        tableRow.font = { bold: true, italic: true };
        tableRow.alignment = { vertical: 'middle', horizontal: 'left' };
        var header = new Array();
        header.push('Product');
        sce.products[0].attribute.forEach(function (value, key) {
            header.push(key);
        });
        var headRow = worksheet.addRow(header);
        headRow.font = { bold: true };
        var _loop_2 = function (prod) {
            var product = new Array();
            product.push(prod.name);
            prod.attributeValues.forEach(function (value, key) {
                product.push(value);
            });
            var prodTable = worksheet.addRow(product);
        };
        for (var _i = 0, _a = sce.products; _i < _a.length; _i++) {
            var prod = _a[_i];
            _loop_2(prod);
        }
        worksheet.addRows([[], []]);
        // Elasticity table
        var simulation = worksheet.addRow(['Elasticity']);
        simulation.font = { bold: true, family: 4, italic: true };
        var elasticityRow = [];
        var headerRow = [];
        headerRow.push('Product');
        this.elasticityService.elasticity.forEach(function (value, key) {
            var temp = [];
            temp.push(key);
            value.forEach(function (value2, key2) {
                headerRow.push(key2);
                temp.push(value2);
            });
            elasticityRow.push(temp);
        });
        var rowHeader = worksheet.addRow(headerRow);
        rowHeader.font = { bold: true };
        var elasticityTableRow = worksheet.addRows(elasticityRow);
        worksheet.addRows(['']);
        worksheet.addRows(['']);
        // Revenue Table
        var simulationRev = worksheet.addRow(['Adjusted Revenue']);
        simulationRev.font = { bold: true, family: 4, italic: true };
        var revenueRow = [];
        var revHeaderRow = [];
        revHeaderRow.push('Product');
        this.elasticityService.adjustedRevenue.forEach(function (value, key) {
            var temp = [];
            temp.push(key);
            value.forEach(function (value2, key2) {
                revHeaderRow.push(key2);
                // temp.push(value2);
            });
            _this.elasticityService.revenue.forEach(function (value3, key3) {
                temp.push(value3);
            });
            var revRow = revenueRow.push(temp);
        });
        var revRowHeader = worksheet.addRow(revHeaderRow);
        revRowHeader.font = { bold: true };
        revRowHeader.alignment = { vertical: 'middle', horizontal: 'left' };
        worksheet.addRows(revenueRow);
        // Wrap cells
        for (var rowIndex = 1; rowIndex < worksheet.rowCount; rowIndex++) {
            worksheet.getRow(rowIndex).alignment = { vertical: 'middle', horizontal: 'left' };
        }
        setTimeout(function () {
            workbook.xlsx.writeBuffer().then(function (data2) {
                var blob = new Blob([data2], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                var options = {
                    // Suggested file name to use, defaults to `''`.
                    fileName: 'TMTG_simpro_export.xlsx',
                    // Suggested file extensions (with leading '.'), defaults to `''`.
                    extensions: ['.xlsx'],
                };
                // this.saveAsNewFile(targetModal, blob, options).then((z) => {
                _this.writeFile(fileHandle, data2).then(function (z) {
                    _this.exportStatus = 'File successfully exported.';
                    _this.modalService.open(targetModal, {
                        centered: true,
                        backdrop: 'static',
                        size: 'sm'
                    });
                }).catch(function (e) {
                    _this.exportStatus = 'Error! Please make sure file is closed.';
                    _this.modalService.open(targetModal, {
                        centered: true,
                        backdrop: 'static',
                        size: 'sm'
                    });
                });
            });
        }, 1500);
    };
    ElasticityComponent.prototype.saveAsNewFile = function (targetModal, blob, options) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Object(browser_nativefs__WEBPACK_IMPORTED_MODULE_13__["fileSave"])(blob, options)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ElasticityComponent.prototype.writeFile = function (fileHandle, contents) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var writable;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, fileHandle.createWritable()];
                    case 1:
                        writable = _a.sent();
                        // Write the contents of the file to the stream.
                        return [4 /*yield*/, writable.write(contents)];
                    case 2:
                        // Write the contents of the file to the stream.
                        _a.sent();
                        // Close the file and write the contents to disk.
                        return [4 /*yield*/, writable.close()];
                    case 3:
                        // Close the file and write the contents to disk.
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ElasticityComponent.prototype.resizableGrid = function (tableId) {
        var row = document.getElementById(tableId).getElementsByTagName('tr')[0];
        var cols = row ? row.children : undefined;
        if (!cols)
            return;
        document.getElementById(tableId).style.overflow = 'hidden';
        var tableHeight = document.getElementById(tableId).offsetHeight;
        for (var i = 0; i < cols.length; i++) {
            var div = this.createDiv(tableHeight);
            cols[i].appendChild(div);
            cols[i].style.position = 'relative';
            this.setListeners(div);
        }
    };
    ElasticityComponent.prototype.setListeners = function (div) {
        var _this = this;
        var pageX, curCol, nxtCol, curColWidth, nxtColWidth;
        div.addEventListener('mousedown', function (e) {
            curCol = e.target.parentElement;
            nxtCol = curCol.nextElementSibling;
            pageX = e.pageX;
            var padding = _this.paddingDiff(curCol);
            curColWidth = curCol.offsetWidth - padding;
            if (nxtCol) {
                nxtColWidth = nxtCol.offsetWidth - padding;
            }
        });
        div.addEventListener('mouseover', function (e) {
            e.target.style.borderRight = '2px solid #0000ff';
        });
        div.addEventListener('mouseout', function (e) {
            e.target.style.borderRight = '';
        });
        window.document.addEventListener('mousemove', function (e) {
            if (curCol) {
                var diffX = e.pageX - pageX;
                if (nxtCol) {
                    nxtCol.style.width = (nxtColWidth - (diffX)) + 'px';
                }
                curCol.style.width = (curColWidth + diffX) + 'px';
            }
        });
        document.addEventListener('mouseup', function (e) {
            curCol = undefined;
            nxtCol = undefined;
            pageX = undefined;
            nxtColWidth = undefined;
            curColWidth = undefined;
        });
    };
    ElasticityComponent.prototype.createDiv = function (height) {
        var div = window.document.createElement('div');
        div.style.top = '0';
        div.style.right = '0';
        div.style.width = '5px';
        div.style.position = 'absolute';
        div.style.cursor = 'col-resize';
        div.style.userSelect = 'none';
        div.style.height = height + 'px';
        return div;
    };
    ElasticityComponent.prototype.paddingDiff = function (col) {
        if (this.getStyleVal(col, 'box-sizing') === 'border-box') {
            return 0;
        }
        var padLeft = this.getStyleVal(col, 'padding-left');
        var padRight = this.getStyleVal(col, 'padding-right');
        // tslint:disable-next-line:radix
        return (parseInt(padLeft) + parseInt(padRight));
    };
    ElasticityComponent.prototype.getStyleVal = function (elm, css) {
        return (window.getComputedStyle(elm, null).getPropertyValue(css));
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('chart'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_3__["ChartComponent"])
    ], ElasticityComponent.prototype, "chartObj", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('chart2'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_3__["ChartComponent"])
    ], ElasticityComponent.prototype, "chartObj2", void 0);
    ElasticityComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-elasticity',
            template: __webpack_require__(/*! ./elasticity.component.html */ "./src/app/elasticity/elasticity/elasticity.component.html"),
            styles: [__webpack_require__(/*! ./elasticity.component.css */ "./src/app/elasticity/elasticity/elasticity.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__["NgbModal"],
            _elasticity_service__WEBPACK_IMPORTED_MODULE_4__["ElasticityService"],
            _core_header_header_service__WEBPACK_IMPORTED_MODULE_5__["HeaderService"],
            _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_6__["ScenariomanagementService"],
            _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_7__["UtilitymanagementService"],
            _service_chart_color_service__WEBPACK_IMPORTED_MODULE_8__["ChartColorService"],
            _service_utility_service__WEBPACK_IMPORTED_MODULE_9__["UtilityService"],
            _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_11__["ProductmanagementService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_12__["Router"]])
    ], ElasticityComponent);
    return ElasticityComponent;
}());



/***/ }),

/***/ "./src/app/home/home.component.css":
/*!*****************************************!*\
  !*** ./src/app/home/home.component.css ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/home/home.component.html":
/*!******************************************!*\
  !*** ./src/app/home/home.component.html ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<router-outlet>\n    <ngx-spinner bdColor=\"rgba(0, 0, 0, 0.8)\" size = \"medium\" color=\"#fff\"type = \"ball-spin\" [fullScreen] = \"true\"><p style=\"color: white\" > Loading... </p></ngx-spinner>\n</router-outlet>\n\n"

/***/ }),

/***/ "./src/app/home/home.component.ts":
/*!****************************************!*\
  !*** ./src/app/home/home.component.ts ***!
  \****************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _connection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../connection.service */ "./src/app/connection.service.ts");
/* harmony import */ var _service_utilities_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/utilities.service */ "./src/app/service/utilities.service.ts");
/* harmony import */ var _service_users_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../service/users.service */ "./src/app/service/users.service.ts");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/fesm5/ngx-spinner.js");
/* harmony import */ var _service_user_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../service/user-auth.service */ "./src/app/service/user-auth.service.ts");







var HomeComponent = /** @class */ (function () {
    function HomeComponent(connectionService, utilitiesService, usersService, spinner, userAuthService) {
        // this.spinner.show();
        // this.connectionService.doGet('api/users/').subscribe((response) => {
        //     this.response = Object.values(response);
        //     this.usersService.setUsers(this.response[0]);
        //     this.spinner.hide();
        // });
        this.connectionService = connectionService;
        this.utilitiesService = utilitiesService;
        this.usersService = usersService;
        this.spinner = spinner;
        this.userAuthService = userAuthService;
        this.mini = true;
    }
    HomeComponent.prototype.ngOnInit = function () {
    };
    HomeComponent.prototype.setScenario = function () {
        // this.sceService.addScenarios('Scenario', this.productList);
    };
    HomeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.component.html */ "./src/app/home/home.component.html"),
            styles: [__webpack_require__(/*! ./home.component.css */ "./src/app/home/home.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_connection_service__WEBPACK_IMPORTED_MODULE_2__["ConnectionService"],
            _service_utilities_service__WEBPACK_IMPORTED_MODULE_3__["UtilitiesService"],
            _service_users_service__WEBPACK_IMPORTED_MODULE_4__["UsersService"],
            ngx_spinner__WEBPACK_IMPORTED_MODULE_5__["NgxSpinnerService"],
            _service_user_auth_service__WEBPACK_IMPORTED_MODULE_6__["UserAuthService"]])
    ], HomeComponent);
    return HomeComponent;
}());



/***/ }),

/***/ "./src/app/login/login.component.css":
/*!*******************************************!*\
  !*** ./src/app/login/login.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/*:root {*/\r\n/*    --input-padding-x: 1.5rem;*/\r\n/*    --input-padding-y: .75rem;*/\r\n/*}*/\r\n/*body {*/\r\n/*    background: #007bff;*/\r\n/*    background: linear-gradient(to right, #0062E6, #33AEFF);*/\r\n/*}*/\r\n/*.card-signin {*/\r\n/*    border: 0;*/\r\n/*    border-radius: 1rem;*/\r\n/*    box-shadow: 0 0.5rem 1rem 0 rgba(0, 0, 0, 0.1);*/\r\n/*}*/\r\n/*.card-signin .card-title {*/\r\n/*    margin-bottom: 2rem;*/\r\n/*    font-weight: 300;*/\r\n/*    font-size: 1.5rem;*/\r\n/*}*/\r\n/*.card-signin .card-body {*/\r\n/*    padding: 2rem;*/\r\n/*}*/\r\n/*.form-signin {*/\r\n/*    width: 100%;*/\r\n/*}*/\r\n/*.form-signin .btn {*/\r\n/*    font-size: 80%;*/\r\n/*    border-radius: 5rem;*/\r\n/*    letter-spacing: .1rem;*/\r\n/*    font-weight: bold;*/\r\n/*    padding: 1rem;*/\r\n/*    transition: all 0.2s;*/\r\n/*}*/\r\n/*.form-label-group {*/\r\n/*    position: relative;*/\r\n/*    margin-bottom: 1rem;*/\r\n/*}*/\r\n/*.form-label-group input {*/\r\n/*    height: auto;*/\r\n/*    border-radius: 2rem;*/\r\n/*}*/\r\n/*.form-label-group>input,*/\r\n/*.form-label-group>label {*/\r\n/*    padding: var(--input-padding-y) var(--input-padding-x);*/\r\n/*}*/\r\n/*.form-label-group>label {*/\r\n/*    position: absolute;*/\r\n/*    top: 0;*/\r\n/*    left: 0;*/\r\n/*    display: block;*/\r\n/*    width: 100%;*/\r\n/*    margin-bottom: 0;*/\r\n/*    !* Override default `<label>` margin *!*/\r\n/*    line-height: 1.5;*/\r\n/*    color: #495057;*/\r\n/*    border: 1px solid transparent;*/\r\n/*    border-radius: .25rem;*/\r\n/*    transition: all .1s ease-in-out;*/\r\n/*}*/\r\n/*.form-label-group input::-webkit-input-placeholder {*/\r\n/*    color: transparent;*/\r\n/*}*/\r\n/*.form-label-group input:-ms-input-placeholder {*/\r\n/*    color: transparent;*/\r\n/*}*/\r\n/*.form-label-group input::-ms-input-placeholder {*/\r\n/*    color: transparent;*/\r\n/*}*/\r\n/*.form-label-group input::-moz-placeholder {*/\r\n/*    color: transparent;*/\r\n/*}*/\r\n/*.form-label-group input::placeholder {*/\r\n/*    color: transparent;*/\r\n/*}*/\r\n/*.form-label-group input:not(:placeholder-shown) {*/\r\n/*    padding-top: calc(var(--input-padding-y) + var(--input-padding-y) * (2 / 3));*/\r\n/*    padding-bottom: calc(var(--input-padding-y) / 3);*/\r\n/*}*/\r\n/*.form-label-group input:not(:placeholder-shown)~label {*/\r\n/*    padding-top: calc(var(--input-padding-y) / 3);*/\r\n/*    padding-bottom: calc(var(--input-padding-y) / 3);*/\r\n/*    font-size: 12px;*/\r\n/*    color: #777;*/\r\n/*}*/\r\n/*.btn-google {*/\r\n/*    color: white;*/\r\n/*    background-color: #ea4335;*/\r\n/*}*/\r\n/*.btn-facebook {*/\r\n/*    color: white;*/\r\n/*    background-color: #3b5998;*/\r\n/*}*/\r\n/*.Absolute-Center {*/\r\n/*    margin: auto;*/\r\n/*    position: absolute;*/\r\n/*    top: 0; left: 0; bottom: 0; right: 0;*/\r\n/*}*/\r\n/*.Absolute-Center.is-Responsive {*/\r\n/*    width: 50%;*/\r\n/*    height: 50%;*/\r\n/*    min-width: 200px;*/\r\n/*    max-width: 400px;*/\r\n/*    padding: 40px;*/\r\n/*}*/\r\n/*!* Fallback for Edge*/\r\n/*-------------------------------------------------- *!*/\r\n/*@supports (-ms-ime-align: auto) {*/\r\n/*    .form-label-group>label {*/\r\n/*        display: none;*/\r\n/*    }*/\r\n/*    .form-label-group input::-ms-input-placeholder {*/\r\n/*        color: #777;*/\r\n/*    }*/\r\n/*}*/\r\n/*!* Fallback for IE*/\r\n/*-------------------------------------------------- *!*/\r\n/*@media all and (-ms-high-contrast: none),*/\r\n/*(-ms-high-contrast: active) {*/\r\n/*    .form-label-group>label {*/\r\n/*        display: none;*/\r\n/*    }*/\r\n/*    .form-label-group input:-ms-input-placeholder {*/\r\n/*        color: #777;*/\r\n/*    }*/\r\n/*}*/\r\n.login,\r\n.image {\r\n    min-height: 100vh;\r\n}\r\n.btn-primary {\r\n    background-color: #2a6496;\r\n    border-color: #2a6496;\r\n}\r\n.bg-image {\r\n    background-image: url('login_bg.jpg');\r\n    background-size: cover;\r\n    background-position: center center;\r\n}\r\n\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxVQUFVO0FBQ1YsaUNBQWlDO0FBQ2pDLGlDQUFpQztBQUNqQyxJQUFJO0FBRUosU0FBUztBQUNULDJCQUEyQjtBQUMzQiwrREFBK0Q7QUFDL0QsSUFBSTtBQUVKLGlCQUFpQjtBQUNqQixpQkFBaUI7QUFDakIsMkJBQTJCO0FBQzNCLHNEQUFzRDtBQUN0RCxJQUFJO0FBRUosNkJBQTZCO0FBQzdCLDJCQUEyQjtBQUMzQix3QkFBd0I7QUFDeEIseUJBQXlCO0FBQ3pCLElBQUk7QUFFSiw0QkFBNEI7QUFDNUIscUJBQXFCO0FBQ3JCLElBQUk7QUFFSixpQkFBaUI7QUFDakIsbUJBQW1CO0FBQ25CLElBQUk7QUFFSixzQkFBc0I7QUFDdEIsc0JBQXNCO0FBQ3RCLDJCQUEyQjtBQUMzQiw2QkFBNkI7QUFDN0IseUJBQXlCO0FBQ3pCLHFCQUFxQjtBQUNyQiw0QkFBNEI7QUFDNUIsSUFBSTtBQUVKLHNCQUFzQjtBQUN0QiwwQkFBMEI7QUFDMUIsMkJBQTJCO0FBQzNCLElBQUk7QUFFSiw0QkFBNEI7QUFDNUIsb0JBQW9CO0FBQ3BCLDJCQUEyQjtBQUMzQixJQUFJO0FBRUosMkJBQTJCO0FBQzNCLDRCQUE0QjtBQUM1Qiw4REFBOEQ7QUFDOUQsSUFBSTtBQUVKLDRCQUE0QjtBQUM1QiwwQkFBMEI7QUFDMUIsY0FBYztBQUNkLGVBQWU7QUFDZixzQkFBc0I7QUFDdEIsbUJBQW1CO0FBQ25CLHdCQUF3QjtBQUN4Qiw4Q0FBOEM7QUFDOUMsd0JBQXdCO0FBQ3hCLHNCQUFzQjtBQUN0QixxQ0FBcUM7QUFDckMsNkJBQTZCO0FBQzdCLHVDQUF1QztBQUN2QyxJQUFJO0FBRUosdURBQXVEO0FBQ3ZELDBCQUEwQjtBQUMxQixJQUFJO0FBRUosa0RBQWtEO0FBQ2xELDBCQUEwQjtBQUMxQixJQUFJO0FBRUosbURBQW1EO0FBQ25ELDBCQUEwQjtBQUMxQixJQUFJO0FBRUosOENBQThDO0FBQzlDLDBCQUEwQjtBQUMxQixJQUFJO0FBRUoseUNBQXlDO0FBQ3pDLDBCQUEwQjtBQUMxQixJQUFJO0FBRUosb0RBQW9EO0FBQ3BELG9GQUFvRjtBQUNwRix3REFBd0Q7QUFDeEQsSUFBSTtBQUVKLDBEQUEwRDtBQUMxRCxxREFBcUQ7QUFDckQsd0RBQXdEO0FBQ3hELHVCQUF1QjtBQUN2QixtQkFBbUI7QUFDbkIsSUFBSTtBQUVKLGdCQUFnQjtBQUNoQixvQkFBb0I7QUFDcEIsaUNBQWlDO0FBQ2pDLElBQUk7QUFFSixrQkFBa0I7QUFDbEIsb0JBQW9CO0FBQ3BCLGlDQUFpQztBQUNqQyxJQUFJO0FBRUoscUJBQXFCO0FBQ3JCLG9CQUFvQjtBQUNwQiwwQkFBMEI7QUFDMUIsNENBQTRDO0FBQzVDLElBQUk7QUFFSixtQ0FBbUM7QUFDbkMsa0JBQWtCO0FBQ2xCLG1CQUFtQjtBQUNuQix3QkFBd0I7QUFDeEIsd0JBQXdCO0FBQ3hCLHFCQUFxQjtBQUNyQixJQUFJO0FBR0osdUJBQXVCO0FBQ3ZCLHdEQUF3RDtBQUV4RCxvQ0FBb0M7QUFDcEMsZ0NBQWdDO0FBQ2hDLHlCQUF5QjtBQUN6QixRQUFRO0FBQ1IsdURBQXVEO0FBQ3ZELHVCQUF1QjtBQUN2QixRQUFRO0FBQ1IsSUFBSTtBQUVKLHFCQUFxQjtBQUNyQix3REFBd0Q7QUFFeEQsNENBQTRDO0FBQzVDLGdDQUFnQztBQUNoQyxnQ0FBZ0M7QUFDaEMseUJBQXlCO0FBQ3pCLFFBQVE7QUFDUixzREFBc0Q7QUFDdEQsdUJBQXVCO0FBQ3ZCLFFBQVE7QUFDUixJQUFJO0FBR0o7O0lBRUksaUJBQWlCO0FBQ3JCO0FBQ0E7SUFDSSx5QkFBeUI7SUFDekIscUJBQXFCO0FBQ3pCO0FBQ0E7SUFDSSxxQ0FBeUQ7SUFDekQsc0JBQXNCO0lBQ3RCLGtDQUFrQztBQUN0QyIsImZpbGUiOiJzcmMvYXBwL2xvZ2luL2xvZ2luLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKjpyb290IHsqL1xyXG4vKiAgICAtLWlucHV0LXBhZGRpbmcteDogMS41cmVtOyovXHJcbi8qICAgIC0taW5wdXQtcGFkZGluZy15OiAuNzVyZW07Ki9cclxuLyp9Ki9cclxuXHJcbi8qYm9keSB7Ki9cclxuLyogICAgYmFja2dyb3VuZDogIzAwN2JmZjsqL1xyXG4vKiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsICMwMDYyRTYsICMzM0FFRkYpOyovXHJcbi8qfSovXHJcblxyXG4vKi5jYXJkLXNpZ25pbiB7Ki9cclxuLyogICAgYm9yZGVyOiAwOyovXHJcbi8qICAgIGJvcmRlci1yYWRpdXM6IDFyZW07Ki9cclxuLyogICAgYm94LXNoYWRvdzogMCAwLjVyZW0gMXJlbSAwIHJnYmEoMCwgMCwgMCwgMC4xKTsqL1xyXG4vKn0qL1xyXG5cclxuLyouY2FyZC1zaWduaW4gLmNhcmQtdGl0bGUgeyovXHJcbi8qICAgIG1hcmdpbi1ib3R0b206IDJyZW07Ki9cclxuLyogICAgZm9udC13ZWlnaHQ6IDMwMDsqL1xyXG4vKiAgICBmb250LXNpemU6IDEuNXJlbTsqL1xyXG4vKn0qL1xyXG5cclxuLyouY2FyZC1zaWduaW4gLmNhcmQtYm9keSB7Ki9cclxuLyogICAgcGFkZGluZzogMnJlbTsqL1xyXG4vKn0qL1xyXG5cclxuLyouZm9ybS1zaWduaW4geyovXHJcbi8qICAgIHdpZHRoOiAxMDAlOyovXHJcbi8qfSovXHJcblxyXG4vKi5mb3JtLXNpZ25pbiAuYnRuIHsqL1xyXG4vKiAgICBmb250LXNpemU6IDgwJTsqL1xyXG4vKiAgICBib3JkZXItcmFkaXVzOiA1cmVtOyovXHJcbi8qICAgIGxldHRlci1zcGFjaW5nOiAuMXJlbTsqL1xyXG4vKiAgICBmb250LXdlaWdodDogYm9sZDsqL1xyXG4vKiAgICBwYWRkaW5nOiAxcmVtOyovXHJcbi8qICAgIHRyYW5zaXRpb246IGFsbCAwLjJzOyovXHJcbi8qfSovXHJcblxyXG4vKi5mb3JtLWxhYmVsLWdyb3VwIHsqL1xyXG4vKiAgICBwb3NpdGlvbjogcmVsYXRpdmU7Ki9cclxuLyogICAgbWFyZ2luLWJvdHRvbTogMXJlbTsqL1xyXG4vKn0qL1xyXG5cclxuLyouZm9ybS1sYWJlbC1ncm91cCBpbnB1dCB7Ki9cclxuLyogICAgaGVpZ2h0OiBhdXRvOyovXHJcbi8qICAgIGJvcmRlci1yYWRpdXM6IDJyZW07Ki9cclxuLyp9Ki9cclxuXHJcbi8qLmZvcm0tbGFiZWwtZ3JvdXA+aW5wdXQsKi9cclxuLyouZm9ybS1sYWJlbC1ncm91cD5sYWJlbCB7Ki9cclxuLyogICAgcGFkZGluZzogdmFyKC0taW5wdXQtcGFkZGluZy15KSB2YXIoLS1pbnB1dC1wYWRkaW5nLXgpOyovXHJcbi8qfSovXHJcblxyXG4vKi5mb3JtLWxhYmVsLWdyb3VwPmxhYmVsIHsqL1xyXG4vKiAgICBwb3NpdGlvbjogYWJzb2x1dGU7Ki9cclxuLyogICAgdG9wOiAwOyovXHJcbi8qICAgIGxlZnQ6IDA7Ki9cclxuLyogICAgZGlzcGxheTogYmxvY2s7Ki9cclxuLyogICAgd2lkdGg6IDEwMCU7Ki9cclxuLyogICAgbWFyZ2luLWJvdHRvbTogMDsqL1xyXG4vKiAgICAhKiBPdmVycmlkZSBkZWZhdWx0IGA8bGFiZWw+YCBtYXJnaW4gKiEqL1xyXG4vKiAgICBsaW5lLWhlaWdodDogMS41OyovXHJcbi8qICAgIGNvbG9yOiAjNDk1MDU3OyovXHJcbi8qICAgIGJvcmRlcjogMXB4IHNvbGlkIHRyYW5zcGFyZW50OyovXHJcbi8qICAgIGJvcmRlci1yYWRpdXM6IC4yNXJlbTsqL1xyXG4vKiAgICB0cmFuc2l0aW9uOiBhbGwgLjFzIGVhc2UtaW4tb3V0OyovXHJcbi8qfSovXHJcblxyXG4vKi5mb3JtLWxhYmVsLWdyb3VwIGlucHV0Ojotd2Via2l0LWlucHV0LXBsYWNlaG9sZGVyIHsqL1xyXG4vKiAgICBjb2xvcjogdHJhbnNwYXJlbnQ7Ki9cclxuLyp9Ki9cclxuXHJcbi8qLmZvcm0tbGFiZWwtZ3JvdXAgaW5wdXQ6LW1zLWlucHV0LXBsYWNlaG9sZGVyIHsqL1xyXG4vKiAgICBjb2xvcjogdHJhbnNwYXJlbnQ7Ki9cclxuLyp9Ki9cclxuXHJcbi8qLmZvcm0tbGFiZWwtZ3JvdXAgaW5wdXQ6Oi1tcy1pbnB1dC1wbGFjZWhvbGRlciB7Ki9cclxuLyogICAgY29sb3I6IHRyYW5zcGFyZW50OyovXHJcbi8qfSovXHJcblxyXG4vKi5mb3JtLWxhYmVsLWdyb3VwIGlucHV0OjotbW96LXBsYWNlaG9sZGVyIHsqL1xyXG4vKiAgICBjb2xvcjogdHJhbnNwYXJlbnQ7Ki9cclxuLyp9Ki9cclxuXHJcbi8qLmZvcm0tbGFiZWwtZ3JvdXAgaW5wdXQ6OnBsYWNlaG9sZGVyIHsqL1xyXG4vKiAgICBjb2xvcjogdHJhbnNwYXJlbnQ7Ki9cclxuLyp9Ki9cclxuXHJcbi8qLmZvcm0tbGFiZWwtZ3JvdXAgaW5wdXQ6bm90KDpwbGFjZWhvbGRlci1zaG93bikgeyovXHJcbi8qICAgIHBhZGRpbmctdG9wOiBjYWxjKHZhcigtLWlucHV0LXBhZGRpbmcteSkgKyB2YXIoLS1pbnB1dC1wYWRkaW5nLXkpICogKDIgLyAzKSk7Ki9cclxuLyogICAgcGFkZGluZy1ib3R0b206IGNhbGModmFyKC0taW5wdXQtcGFkZGluZy15KSAvIDMpOyovXHJcbi8qfSovXHJcblxyXG4vKi5mb3JtLWxhYmVsLWdyb3VwIGlucHV0Om5vdCg6cGxhY2Vob2xkZXItc2hvd24pfmxhYmVsIHsqL1xyXG4vKiAgICBwYWRkaW5nLXRvcDogY2FsYyh2YXIoLS1pbnB1dC1wYWRkaW5nLXkpIC8gMyk7Ki9cclxuLyogICAgcGFkZGluZy1ib3R0b206IGNhbGModmFyKC0taW5wdXQtcGFkZGluZy15KSAvIDMpOyovXHJcbi8qICAgIGZvbnQtc2l6ZTogMTJweDsqL1xyXG4vKiAgICBjb2xvcjogIzc3NzsqL1xyXG4vKn0qL1xyXG5cclxuLyouYnRuLWdvb2dsZSB7Ki9cclxuLyogICAgY29sb3I6IHdoaXRlOyovXHJcbi8qICAgIGJhY2tncm91bmQtY29sb3I6ICNlYTQzMzU7Ki9cclxuLyp9Ki9cclxuXHJcbi8qLmJ0bi1mYWNlYm9vayB7Ki9cclxuLyogICAgY29sb3I6IHdoaXRlOyovXHJcbi8qICAgIGJhY2tncm91bmQtY29sb3I6ICMzYjU5OTg7Ki9cclxuLyp9Ki9cclxuXHJcbi8qLkFic29sdXRlLUNlbnRlciB7Ki9cclxuLyogICAgbWFyZ2luOiBhdXRvOyovXHJcbi8qICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTsqL1xyXG4vKiAgICB0b3A6IDA7IGxlZnQ6IDA7IGJvdHRvbTogMDsgcmlnaHQ6IDA7Ki9cclxuLyp9Ki9cclxuXHJcbi8qLkFic29sdXRlLUNlbnRlci5pcy1SZXNwb25zaXZlIHsqL1xyXG4vKiAgICB3aWR0aDogNTAlOyovXHJcbi8qICAgIGhlaWdodDogNTAlOyovXHJcbi8qICAgIG1pbi13aWR0aDogMjAwcHg7Ki9cclxuLyogICAgbWF4LXdpZHRoOiA0MDBweDsqL1xyXG4vKiAgICBwYWRkaW5nOiA0MHB4OyovXHJcbi8qfSovXHJcblxyXG5cclxuLyohKiBGYWxsYmFjayBmb3IgRWRnZSovXHJcbi8qLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKiEqL1xyXG5cclxuLypAc3VwcG9ydHMgKC1tcy1pbWUtYWxpZ246IGF1dG8pIHsqL1xyXG4vKiAgICAuZm9ybS1sYWJlbC1ncm91cD5sYWJlbCB7Ki9cclxuLyogICAgICAgIGRpc3BsYXk6IG5vbmU7Ki9cclxuLyogICAgfSovXHJcbi8qICAgIC5mb3JtLWxhYmVsLWdyb3VwIGlucHV0OjotbXMtaW5wdXQtcGxhY2Vob2xkZXIgeyovXHJcbi8qICAgICAgICBjb2xvcjogIzc3NzsqL1xyXG4vKiAgICB9Ki9cclxuLyp9Ki9cclxuXHJcbi8qISogRmFsbGJhY2sgZm9yIElFKi9cclxuLyotLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqISovXHJcblxyXG4vKkBtZWRpYSBhbGwgYW5kICgtbXMtaGlnaC1jb250cmFzdDogbm9uZSksKi9cclxuLyooLW1zLWhpZ2gtY29udHJhc3Q6IGFjdGl2ZSkgeyovXHJcbi8qICAgIC5mb3JtLWxhYmVsLWdyb3VwPmxhYmVsIHsqL1xyXG4vKiAgICAgICAgZGlzcGxheTogbm9uZTsqL1xyXG4vKiAgICB9Ki9cclxuLyogICAgLmZvcm0tbGFiZWwtZ3JvdXAgaW5wdXQ6LW1zLWlucHV0LXBsYWNlaG9sZGVyIHsqL1xyXG4vKiAgICAgICAgY29sb3I6ICM3Nzc7Ki9cclxuLyogICAgfSovXHJcbi8qfSovXHJcblxyXG5cclxuLmxvZ2luLFxyXG4uaW1hZ2Uge1xyXG4gICAgbWluLWhlaWdodDogMTAwdmg7XHJcbn1cclxuLmJ0bi1wcmltYXJ5IHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMyYTY0OTY7XHJcbiAgICBib3JkZXItY29sb3I6ICMyYTY0OTY7XHJcbn1cclxuLmJnLWltYWdlIHtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCgnLi4vLi4vYXNzZXRzL2ltYWdlcy9sb2dpbl9iZy5qcGcnKTtcclxuICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xyXG59XHJcblxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/login/login.component.html":
/*!********************************************!*\
  !*** ./src/app/login/login.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--<div *ngIf=\"!userAuth\">-->\n    <div class=\"container-fluid\">\n        <div class=\"row no-gutter\">\n            <!-- The image half -->\n            <div class=\"col-md-6 d-none d-md-flex bg-image\"></div>\n\n\n            <!-- The content half -->\n            <div class=\"col-md-6 bg-light\">\n                <div class=\"login d-flex align-items-center py-5\">\n\n                    <!-- Demo content-->\n                    <div class=\"container\">\n                        <div class=\"row\">\n                            <div class=\"col-lg-10 col-xl-7 mx-auto\">\n                                <h3 align=\"center\" style=\"color: #0075BE; padding-right: 20px; alignment: center\">\n                                    <img src=\"../assets/images/tmtg.png\" width=\"250px\" style=\"padding-right: 10px\" align=\"center\">\n                                </h3>\n                                <p class=\"text-muted mb-4\"></p>\n                                <form (ngSubmit)=\"loginUser()\">\n                                    <div class=\"form-group mb-3\">\n                                        <input name=\"email\" type=\"email\" [(ngModel)]=\"email\" placeholder=\"Username\" required=\"\" autofocus=\"\" class=\"form-control rounded-pill border-0 shadow-sm px-4\">\n                                    </div>\n                                    <div class=\"form-group mb-3\">\n                                        <input name=\"password\" type=\"password\" [(ngModel)]=\"password\" placeholder=\"Password\" required=\"\" class=\"form-control rounded-pill border-0 shadow-sm px-4 text-primary\">\n                                    </div>\n                                    <input type=\"submit\" class=\"btn btn-lg btn-primary btn-block text-uppercase mb-2 rounded-pill shadow-sm\" value=\"Sign in\">\n                                    <div *ngIf=\"message!=''\" class=\"alert alert-danger\" role=\"alert\">{{message}}</div>\n\n                                </form>\n                            </div>\n                        </div>\n                    </div><!-- End -->\n\n                </div>\n            </div><!-- End -->\n\n        </div>\n    </div>\n\n<ngx-spinner bdColor=\"rgba(0, 0, 0, 0.8)\" size = \"large\" color=\"#fff\" type = \"ball-spin\" [fullScreen] = \"true\" ><p style=\"color: white\" > Loading... </p></ngx-spinner>\n"

/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _connection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../connection.service */ "./src/app/connection.service.ts");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var _service_user_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../service/user-auth.service */ "./src/app/service/user-auth.service.ts");
/* harmony import */ var _service_utilities_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../service/utilities.service */ "./src/app/service/utilities.service.ts");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/fesm5/ngx-spinner.js");
/* harmony import */ var _service_users_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../service/users.service */ "./src/app/service/users.service.ts");
/* harmony import */ var _core_header_header_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../core/header/header.service */ "./src/app/core/header/header.service.ts");









var LoginComponent = /** @class */ (function () {
    /* When object is being created */
    function LoginComponent(svc, utilityService, utilitiesService, authService, spinner, usersService, headerService) {
        var _this = this;
        this.svc = svc;
        this.utilityService = utilityService;
        this.utilitiesService = utilitiesService;
        this.authService = authService;
        this.spinner = spinner;
        this.usersService = usersService;
        this.headerService = headerService;
        this.email = '';
        this.password = '';
        this.salt = '';
        this.userAuth = true;
        this.message = '';
        this.utilitiesService.utilities$.subscribe(function (utls) {
            _this.utlList = utls;
        });
    }
    LoginComponent.prototype.ngOnInit = function () {
    };
    LoginComponent.prototype.auth = function () {
        this.userAuth = true;
    };
    LoginComponent.prototype.loginUser = function () {
        var _this = this;
        this.svc.doGet('salt/' + this.email).subscribe(function (response) {
            _this.salt = response['salt'];
            _this.connectServer();
        }, function (error) {
            _this.message = 'Invalid username/password!';
        });
    };
    LoginComponent.prototype.connectServer = function () {
        var _this = this;
        this.svc.doRequest(this.email, this.password, this.salt, 'api/user/').subscribe(function (response2) { return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.authService.setLoggedIn(true, JSON.stringify(Object.values(response2)[0]));
                this.spinner.show();
                this.getUsers().then(function (response1) {
                    if (_this.authService.getLevel() === '1') {
                        // Get utility id associated to user
                        _this.getUserUtilities().then(function (res) { return _this.headerService.setInitialUtility(); });
                        setTimeout(function () {
                            // this.headerService.setInitialUtility();
                            _this.spinner.hide();
                        }, 2000);
                    }
                    // else {
                    //     this.utilitiesService.resetUtilities();
                    //     this.getUtilities().then((res) => {
                    //         this.spinner.hide();
                    //     });
                    // }
                });
                return [2 /*return*/];
            });
        }); }, function (error) {
            _this.message = 'Invalid username/password!';
            _this.spinner.hide();
        });
    };
    LoginComponent.prototype.getUsers = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new Promise(function (resolve, reject) {
                            _this.svc.doGet('api/users/').subscribe(function (response) {
                                _this.response = Object.values(response);
                                _this.users = _this.response[0];
                                _this.usersService.setUsers(_this.response[0]);
                                resolve(true);
                            }, function (err) {
                            });
                        })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    LoginComponent.prototype.getUtilities = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new Promise(function (resolve, reject) {
                            _this.svc.doGet('api/utilities/').subscribe(function (response) {
                                var data = Object.values(response)[0];
                                for (var i = 0; i < data.length; i++) {
                                    _this.utilitiesService.addUtilities(data[i].id, data[i].name, data[i].name.toString().split('_upload')[0], data[i].utlXml);
                                }
                                resolve(true);
                            }, function (err) {
                            });
                        })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    LoginComponent.prototype.getUserUtilities = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new Promise(function (resolve, reject) {
                            var user = _this.users.filter(function (usr) { return usr.user === _this.authService.getUser(); });
                            var utlList = _this.utlList;
                            _this.utilitiesService.resetUtilities();
                            var _loop_1 = function (i) {
                                console.log(utlList);
                                var data = utlList.filter(function (utl) { return utl.name === user[0].accesUtilitiesName[i].name; });
                                console.log(data);
                                _this.utilitiesService.addUtilities(user[0].accesUtilitiesName[i].id, user[0].accesUtilitiesName[i].name, user[0].accesUtilitiesName[i].name.split('_upload')[0], data[0].utl_xml);
                            };
                            for (var i in user[0].accesUtilitiesName) {
                                _loop_1(i);
                            }
                            resolve(true);
                        })];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.component.html */ "./src/app/login/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.css */ "./src/app/login/login.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_connection_service__WEBPACK_IMPORTED_MODULE_2__["ConnectionService"],
            _service_utility_service__WEBPACK_IMPORTED_MODULE_3__["UtilityService"],
            _service_utilities_service__WEBPACK_IMPORTED_MODULE_5__["UtilitiesService"],
            _service_user_auth_service__WEBPACK_IMPORTED_MODULE_4__["UserAuthService"],
            ngx_spinner__WEBPACK_IMPORTED_MODULE_6__["NgxSpinnerService"],
            _service_users_service__WEBPACK_IMPORTED_MODULE_7__["UsersService"],
            _core_header_header_service__WEBPACK_IMPORTED_MODULE_8__["HeaderService"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/models/Product.ts":
/*!***********************************!*\
  !*** ./src/app/models/Product.ts ***!
  \***********************************/
/*! exports provided: Product */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Product", function() { return Product; });
var Product = /** @class */ (function () {
    function Product(obj) {
        Object.assign(this, obj);
    }
    return Product;
}());



/***/ }),

/***/ "./src/app/models/Scenario.ts":
/*!************************************!*\
  !*** ./src/app/models/Scenario.ts ***!
  \************************************/
/*! exports provided: Scenario */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Scenario", function() { return Scenario; });
// export class Scenario {
// //
// //     constructor(obj?: any) {
// //         Object.assign(this, obj);
// //     }
// //     // //
// //     // constructor(
// //     //    public name: string,
// //     //    public savingDate: Date,
// //     //    public creationDate: Date,
// //     //    public description: string
// //     //    ) {}
// //
// //     name: string;
// //     savingDate: Date;
// //     creationDate: Date;
// //     description: string;
// //     // parent: Utility;
// //     // products: Product;
// //
// //
// //
// // }
var Scenario = /** @class */ (function () {
    function Scenario(obj) {
        Object.assign(this, obj);
    }
    return Scenario;
}());



/***/ }),

/***/ "./src/app/models/User.ts":
/*!********************************!*\
  !*** ./src/app/models/User.ts ***!
  \********************************/
/*! exports provided: User */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
var User = /** @class */ (function () {
    function User(obj) {
        Object.assign(this, obj);
    }
    return User;
}());



/***/ }),

/***/ "./src/app/models/Utility.ts":
/*!***********************************!*\
  !*** ./src/app/models/Utility.ts ***!
  \***********************************/
/*! exports provided: Utility */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Utility", function() { return Utility; });
var Utility = /** @class */ (function () {
    // export interface Utility {
    function Utility(obj) {
        Object.assign(this, obj);
    }
    return Utility;
}());



/***/ }),

/***/ "./src/app/preference-ideal/preference-ideal.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/preference-ideal/preference-ideal.module.ts ***!
  \*************************************************************/
/*! exports provided: PreferenceIdealModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreferenceIdealModule", function() { return PreferenceIdealModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _preference_ideal_preference_ideal_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./preference-ideal/preference-ideal.component */ "./src/app/preference-ideal/preference-ideal/preference-ideal.component.ts");
/* harmony import */ var _scenario_scenario_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../scenario/scenario.module */ "./src/app/scenario/scenario.module.ts");
/* harmony import */ var _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @syncfusion/ej2-angular-charts */ "./node_modules/@syncfusion/ej2-angular-charts/@syncfusion/ej2-angular-charts.es5.js");
/* harmony import */ var _resizable_resizable_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../resizable/resizable.module */ "./src/app/resizable/resizable.module.ts");
/* harmony import */ var angular_split__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angular-split */ "./node_modules/angular-split/fesm5/angular-split.js");









var PreferenceIdealModule = /** @class */ (function () {
    function PreferenceIdealModule() {
    }
    PreferenceIdealModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_preference_ideal_preference_ideal_component__WEBPACK_IMPORTED_MODULE_3__["PreferenceIdealComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _scenario_scenario_module__WEBPACK_IMPORTED_MODULE_4__["ScenarioModule"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_5__["ChartModule"],
                _resizable_resizable_module__WEBPACK_IMPORTED_MODULE_6__["ResizableModule"],
                angular_split__WEBPACK_IMPORTED_MODULE_7__["AngularSplitModule"]
            ],
            exports: [
                _preference_ideal_preference_ideal_component__WEBPACK_IMPORTED_MODULE_3__["PreferenceIdealComponent"]
            ],
            providers: [
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_5__["DateTimeService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_5__["ScrollBarService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_5__["LineSeriesService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_5__["ColumnSeriesService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_5__["ChartAnnotationService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_5__["RangeColumnSeriesService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_5__["StackingColumnSeriesService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_5__["LegendService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_5__["TooltipService"]
            ]
        })
    ], PreferenceIdealModule);
    return PreferenceIdealModule;
}());



/***/ }),

/***/ "./src/app/preference-ideal/preference-ideal.service.ts":
/*!**************************************************************!*\
  !*** ./src/app/preference-ideal/preference-ideal.service.ts ***!
  \**************************************************************/
/*! exports provided: PreferenceIdealService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreferenceIdealService", function() { return PreferenceIdealService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _models_Product__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/Product */ "./src/app/models/Product.ts");
/* harmony import */ var _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../product/productmanagement.service */ "./src/app/product/productmanagement.service.ts");
/* harmony import */ var _service_product_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../service/product.service */ "./src/app/service/product.service.ts");
/* harmony import */ var _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../scenario/scenariomanagement.service */ "./src/app/scenario/scenariomanagement.service.ts");
/* harmony import */ var _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../service/selected-scenario.service */ "./src/app/service/selected-scenario.service.ts");
/* harmony import */ var _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../utility/utilitymanagement.service */ "./src/app/utility/utilitymanagement.service.ts");








var PreferenceIdealService = /** @class */ (function () {
    function PreferenceIdealService(prodService, productService, sceManagementService, selectedScenarioService, utlManagementService) {
        var _this = this;
        this.prodService = prodService;
        this.productService = productService;
        this.sceManagementService = sceManagementService;
        this.selectedScenarioService = selectedScenarioService;
        this.utlManagementService = utlManagementService;
        this.segments = [];
        this.segmentId = 0;
        this.noneCol = 0;
        this.perfectProduct = 0;
        this.allAttributes = new Map();
        this.segmentLevels = new Map();
        this.colorPalette = ['#007bff', '#AA1636', '#45aeca', '#E94649', '#F6B53F', '#6FAAB0', '#C4C24A'];
        this.product = new _models_Product__WEBPACK_IMPORTED_MODULE_2__["Product"]();
        this.selectedScenarioService.cast.subscribe(function (sce) {
            _this.prodList = sce.products;
        });
    }
    PreferenceIdealService.prototype.getAttributeValues = function () {
        var temp2 = [], cnt = 0;
        var cell = 'cell_0';
        // Define att
        this.product.attributeValues = new Map();
        this.product.attribute = new Map();
        this.segmentLevels = new Map();
        this.segments = [];
        // this.tuneId = 0;
        // this.weightId = 0;
        var row = 0;
        for (var _i = 0, _a = Object.keys(this.prodService.utility.utl_val); _i < _a.length; _i++) {
            var val = _a[_i];
            for (var _b = 0, _c = Object.keys(this.prodService.utility.utl_val[val]); _b < _c.length; _b++) {
                var val2 = _c[_b];
                cnt = 0;
                temp2 = [];
                do {
                    temp2.push((this.prodService.utility.utl_val[val])[val2]['cell_' + cnt++]);
                } while ((this.prodService.utility.utl_val[val])[val2]['cell_' + cnt]);
                this.product.attributeValues.set(row++, temp2);
            }
        }
        this.segments = this.prodService.segments;
    };
    /**
     * Get Product attributes
     * @param attLength
     * @param attributes
     */
    PreferenceIdealService.prototype.getAttributes = function (attLength, attributes) {
        var products = [];
        var count2 = 0;
        var cnt = 0;
        var attLevel = new Map();
        var cellNum = this.segments.length + attLength + 3;
        this.allAttributes = new Map();
        for (var i = 0; i < attributes.length; i++) {
            if ((attributes[i]['cell_0']) == 5) {
                if (count2 === 0) {
                    attLevel.set(cellNum, attributes[i]['cell_2']);
                    products[cnt++] = attributes[i]['cell_2'];
                    count2++;
                }
                else if (attributes[i - 1]['cell_1'] == attributes[i]['cell_1']) {
                    attLevel.set(cellNum, attributes[i]['cell_2']);
                    if (i === attributes.length - 1) {
                        this.allAttributes.set(attributes[i]['cell_1'], attLevel);
                    }
                    count2++;
                }
                else if (attributes[i - 1]['cell_1'] != attributes[i]['cell_1']) {
                    count2 = 0;
                    this.allAttributes.set(attributes[i - 1]['cell_1'], attLevel);
                    if (JSON.stringify(attributes[i]['cell_2']) != JSON.stringify('NONE') || JSON.stringify(attributes[i]['cell_1']) != JSON.stringify('None')) {
                        products[cnt++] = attributes[i]['cell_2'];
                    }
                    count2++;
                    attLevel = new Map();
                    attLevel.set(cellNum, attributes[i]['cell_2']);
                }
            }
            cellNum++;
        }
        // this.productList.set(1, products);
    };
    /**
     * Get the segment values for dropdown and table
     */
    PreferenceIdealService.prototype.getSegmentValues = function () {
        this.getAttributeValues();
        this.getAttributes(this.prodService.productAtt.length, this.prodService.productAtt2);
        this.getIdealProduct(this.product.attributeValues, this.segments);
        this.productPref = new Map();
        var segTable = document.createElement('table');
        var size = 0;
        segTable.setAttribute('id', 'segTable');
        segTable.setAttribute('class', 'table table-sm table-bordered');
        // Clear all storage
        this.segmentLevels = new Map();
        this.segments = this.prodService.segments;
        // tslint:disable-next-line:prefer-for-of
        for (var i = 0; i < this.segments.length; i++) {
            if (JSON.stringify((this.segments[i])['cell_1']) === JSON.stringify(this.segmentSelected)) {
                var cnt = 0;
                this.segmentId = i;
                do {
                    if ((this.segments[i])['cell_2_' + cnt] !== undefined) {
                        this.segmentLevels.set((this.segments[i])['cell_2_' + cnt], (this.segments[i])['cell_3_' + cnt]);
                        size = cnt;
                    }
                    cnt++;
                } while ((this.segments[i])['cell_3_' + cnt] || cnt <= Object.keys(this.segments[i]).length);
            }
        }
        this.segmentLevels.set(((size + 2).toString()), 'Total');
        // this.getUtilities();
        this.calculateRelativeResult();
    };
    /**
     * Get max value for each attribute / ideal product
     */
    PreferenceIdealService.prototype.getIdealProduct = function (productValues, segments) {
        var _this = this;
        var cnt;
        var maxVal = 0;
        var sumPerfectProd = 0;
        var idealProd = new Map();
        // Clear values
        this.perfectProduct = 0;
        // new code
        var val = 0;
        productValues.forEach(function (value, key) {
            cnt = 38;
            // while (cnt > 37) {
            sumPerfectProd = 0;
            _this.allAttributes.forEach(function (attributes, attributeKeys) {
                maxVal = 0;
                do {
                    val = parseFloat(value[cnt]);
                    if (val > maxVal) {
                        maxVal = val;
                    }
                    cnt++;
                } while (attributes.has(cnt));
                sumPerfectProd += maxVal;
            });
            idealProd.set(key, sumPerfectProd.toFixed(2));
            // }
        });
        idealProd.forEach(function (value, key) {
            _this.perfectProduct += parseFloat(value);
        });
        this.perfectProduct = ((this.perfectProduct / idealProd.size) * 100) / 100;
    };
    // /**
    //  * Get sum of utilities
    //  */
    // public getUtilities() {
    //     const cellNumList = [];
    //     const totalList = [];
    //     let cellNumber = new Map();
    //     let iniValues = new Map();
    //     const weight = new Map();
    //     const tune = new Map();
    //     const total = new Map();
    //     let cnt = 0;
    //     let sum = 0;
    //     let segVal = 0;
    //     let noneVal = 0;
    //     let temp = [];
    //     let index = 0;
    //
    //     if (this.prodList !== undefined) {
    //         for (const productVal of this.prodList) {
    //             cellNumber = new Map();
    //             for (const val of productVal.attributeValues) {
    //                 index = 0;
    //                 this.allAttributes.forEach((value: any, key: any) => {
    //                     value.forEach((cellValue: any, cellKey: any) => {
    //
    //                         if (val === cellValue) {
    //
    //                             cellNumber.set(cellValue, cellKey);
    //                         }
    //                     });
    //
    //                 });
    //             }
    //             cellNumList.push(cellNumber);
    //         }
    //
    //
    //         // 2. Get weight and tune
    //         const cellNum = 0;
    //         this.product.attributeValues.forEach((prodVal: any, prodKey: any) => {
    //             cnt = 0;
    //             for (const value of prodVal) {
    //                 if (cnt == this.prodService.weightId) {
    //                     weight.set(prodKey, value);
    //                 } else if (cnt == this.prodService.tuneId) {
    //                     tune.set(prodKey, value);
    //                 }
    //                 cnt++;
    //             }
    //         });
    //
    //         // 3. If tune is not empty, multiply to cell value
    //         if (tune.size !== 0) {
    //             tune.forEach((value: any, key: any) => {   // 0 - n rows
    //                 cnt = 0;
    //                 this.product.attributeValues.forEach((prodVal: any, prodKey: any) => {   // 0
    //                     temp = [];
    //                     if (prodKey === key) {
    //                         for (const cellVal of prodVal) {
    //                             temp.push(value * cellVal);
    //                         }
    //                         iniValues.set(key, temp);
    //                     }
    //                 });
    //                 cnt++;
    //             });
    //         } else {
    //             iniValues = this.product.attributeValues;
    //         }
    //
    //         // 4. Get sum
    //         for (const cell of cellNumList) {
    //             iniValues.forEach((val: any, k: any) => { // rows 0-151
    //                 sum = 0;
    //                 cnt = 0;
    //                 segVal = 0;
    //                 noneVal = 0;
    //
    //                 for (const cellVal of val) { // columns 0 - 88
    //
    //                     if (cnt == this.noneCol + this.segments.length + 3) {  // 3 is for weight, tune,
    //                         noneVal = Number.parseFloat(cellVal);
    //                     } else {
    //                         cell.forEach((value: any, key: any) => {
    //                             if (value == cnt) {
    //                                 sum = sum + Number.parseFloat(cellVal);
    //                             } else if (cnt == this.segmentId) {
    //                                 segVal = Number.parseFloat(cellVal);
    //                             }
    //                         });
    //                     }
    //                     cnt++;
    //                 }
    //                 temp.push(sum);
    //                 total.set(k, [segVal, sum]);
    //                 // none.set(k, noneVal);
    //                 // meanSeg.set(k, [segVal, (sum) ]);   // initial value of mean segment
    //             });
    //             totalList.push(total);
    //             // totalList.push(none);
    //         }
    //
    //         this.calcuIdealProdResult(totalList);
    //     }
    // }
    /**
     * Calculate Relative result
     */
    PreferenceIdealService.prototype.calculateRelativeResult = function () {
        var _this = this;
        var prefList = this.utlManagementService.getIdealRelativeResult(this.prodList);
        var segLevels = this.utlManagementService.getSegmentValues(this.prodService.segmentPositions[this.segmentId]);
        var segPrefList = [];
        for (var i in prefList) {
            var temp = [];
            for (var n in prefList[i]) {
                temp.push([Number(segLevels[n]), prefList[i][n]]);
            }
            segPrefList.push(temp);
        }
        var _loop_1 = function (i) {
            var sumMap = new Map();
            var sumArray = [];
            var total = 0;
            var keyCnt = 0;
            this_1.segmentLevels.forEach(function (value, key) {
                var sum = 0;
                var cnt = 0;
                if (keyCnt < _this.segmentLevels.size - 1) {
                    for (var n in segPrefList[i]) {
                        if (Number(key) === segPrefList[i][n][0]) {
                            sum += Number(segPrefList[i][n][1]);
                            total += Number(segPrefList[i][n][1]);
                            cnt++;
                        }
                    }
                    if (sum !== 0) {
                        sumMap.set(key, ((sum / cnt) * (100 / _this.utlManagementService.perfectValue)).toFixed(1));
                        sumArray.push(((sum / cnt) * (100 / _this.utlManagementService.perfectValue)).toFixed(1));
                    }
                    else {
                        sumMap.set(key, 0);
                        sumArray.push(0);
                    }
                }
                else {
                    sumArray.push(((total / segPrefList[i].length) * (100 / _this.utlManagementService.perfectValue)).toFixed(1));
                    sumMap.set(key, ((total / segPrefList[i].length) * (100 / _this.utlManagementService.perfectValue)).toFixed(1));
                }
                keyCnt++;
            });
            this_1.productPref.set(this_1.sceManagementService.selectedScenario.products[i].name, sumArray);
        };
        var this_1 = this;
        // Get average per segment
        for (var i in segPrefList) {
            _loop_1(i);
        }
    };
    /**
     * Calculate ideal product
     * @param totalList
     */
    PreferenceIdealService.prototype.calcuIdealProdResult = function (totalList) {
        // Get attributes, segments, perfectProduct
        var _this = this;
        var sum = 0;
        var index = 0;
        var _loop_2 = function (prodValues) {
            var pref = new Map();
            var sumBySegmentLevel = new Map();
            var numberBySegmentLevel = new Map();
            var _loop_3 = function (i) {
                // Get sum by segment level
                prodValues.forEach(function (prodValue, key) {
                    if (Number(prodValue[0]) === i) {
                        if (sumBySegmentLevel.get(i) === undefined) {
                            sumBySegmentLevel.set(i, prodValue[1]);
                            numberBySegmentLevel.set(i, 1);
                        }
                        else {
                            sum = parseFloat(sumBySegmentLevel.get(i)) + parseFloat(prodValue[1]);
                            sumBySegmentLevel.set(i, sum);
                            numberBySegmentLevel.set(i, numberBySegmentLevel.get(i) + 1);
                        }
                    }
                });
                sumBySegmentLevel.forEach(function (value, key) {
                    // Get average
                    var average = parseFloat(value) / numberBySegmentLevel.get(key);
                    pref.set(key, (average * (100 / _this.perfectProduct)).toFixed(2));
                });
                sum = 0;
                for (var n = 1; n <= pref.size; n++) {
                    sum = sum + Number.parseFloat(pref.get(n));
                }
                pref.set(pref.size, (sum / pref.size).toFixed(2));
            };
            for (var i = 0; i < this_2.segmentLevels.size; i++) {
                _loop_3(i);
            }
            this_2.productPref.set(this_2.prodList[index++].name, pref);
        };
        var this_2 = this;
        // Get total per segment
        for (var _i = 0, totalList_1 = totalList; _i < totalList_1.length; _i++) {
            var prodValues = totalList_1[_i];
            _loop_2(prodValues);
        }
    };
    PreferenceIdealService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_product_productmanagement_service__WEBPACK_IMPORTED_MODULE_3__["ProductmanagementService"],
            _service_product_service__WEBPACK_IMPORTED_MODULE_4__["ProductService"],
            _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_5__["ScenariomanagementService"],
            _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_6__["SelectedScenarioService"],
            _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_7__["UtilitymanagementService"]])
    ], PreferenceIdealService);
    return PreferenceIdealService;
}());



/***/ }),

/***/ "./src/app/preference-ideal/preference-ideal/preference-ideal.component.css":
/*!**********************************************************************************!*\
  !*** ./src/app/preference-ideal/preference-ideal/preference-ideal.component.css ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".resizable-div {\r\n    resize: vertical;\r\n    overflow: auto;\r\n    border: 1px solid #e1e1e1;\r\n    min-height: 15vh;\r\n}\r\n\r\n/*table {*/\r\n\r\n/*    display: block;*/\r\n\r\n/*    height:100%;*/\r\n\r\n/*    overflow-y: auto;*/\r\n\r\n/*    border: none;*/\r\n\r\n/*    width: 100%!important;*/\r\n\r\n/*    table-layout: auto;*/\r\n\r\n/*}*/\r\n\r\n/*table td, .table th {*/\r\n\r\n/*    padding: 5px!important;*/\r\n\r\n/*    font-size: .9em;*/\r\n\r\n/*    width: 100vw;*/\r\n\r\n/*}*/\r\n\r\ntable { width: 100%; table-layout: fixed }\r\n\r\nth { padding: 5px!important;}\r\n\r\ntd { white-space: nowrap;\r\n    overflow: hidden;\r\n    text-overflow: ellipsis;\r\n    font-size: .9em;\r\n    padding: 5px!important;\r\n    width: 100vw;\r\n}\r\n\r\n.btn-primary {\r\n    background-color: #2a6496;\r\n    border-color: #2a6496;\r\n}\r\n\r\n.collapsible {\r\n    background-color: #f7f7f7;\r\n    cursor: pointer;\r\n    padding-left: 5px;\r\n    width: 100%;\r\n    border: #f7f7f7;\r\n    text-align: left;\r\n    outline: none;\r\n    font-size: 1em;\r\n    margin: 2px;\r\n    padding-top: .5%;\r\n    padding-bottom: .5%;\r\n    -webkit-transition: 0.4s;\r\n    transition: 0.4s;\r\n}\r\n\r\nbutton.collapsible:after {\r\n    /*content: 'Collapse';*/\r\n    color: white;\r\n    background-color: #2a6496;\r\n    margin-right: 10px;\r\n    float: right;\r\n    align: middle;\r\n}\r\n\r\nbutton.collapsible.active:after {\r\n    /*content: 'Expand';*/\r\n}\r\n\r\n.active, .collapsible:hover {\r\n    background-color: #f7f7f7;\r\n}\r\n\r\n.content {\r\n    padding: 0 18px;\r\n    display: block;\r\n    overflow: hidden;\r\n    /*background-color: #fafafa;*/\r\n    border: none;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJlZmVyZW5jZS1pZGVhbC9wcmVmZXJlbmNlLWlkZWFsL3ByZWZlcmVuY2UtaWRlYWwuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QseUJBQXlCO0lBQ3pCLGdCQUFnQjtBQUNwQjs7QUFFQSxVQUFVOztBQUNWLHNCQUFzQjs7QUFDdEIsbUJBQW1COztBQUNuQix3QkFBd0I7O0FBQ3hCLG9CQUFvQjs7QUFDcEIsNkJBQTZCOztBQUM3QiwwQkFBMEI7O0FBQzFCLElBQUk7O0FBRUosd0JBQXdCOztBQUN4Qiw4QkFBOEI7O0FBQzlCLHVCQUF1Qjs7QUFDdkIsb0JBQW9COztBQUNwQixJQUFJOztBQUNKLFFBQVEsV0FBVyxFQUFFLG9CQUFvQjs7QUFDekMsS0FBSyxzQkFBc0IsQ0FBQzs7QUFDNUIsS0FBSyxtQkFBbUI7SUFDcEIsZ0JBQWdCO0lBQ2hCLHVCQUF1QjtJQUN2QixlQUFlO0lBQ2Ysc0JBQXNCO0lBQ3RCLFlBQVk7QUFDaEI7O0FBQ0E7SUFDSSx5QkFBeUI7SUFDekIscUJBQXFCO0FBQ3pCOztBQUdBO0lBQ0kseUJBQXlCO0lBQ3pCLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsV0FBVztJQUNYLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsYUFBYTtJQUNiLGNBQWM7SUFDZCxXQUFXO0lBQ1gsZ0JBQWdCO0lBQ2hCLG1CQUFtQjtJQUNuQix3QkFBZ0I7SUFBaEIsZ0JBQWdCO0FBQ3BCOztBQUVBO0lBQ0ksdUJBQXVCO0lBQ3ZCLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWixhQUFhO0FBQ2pCOztBQUVBO0lBQ0kscUJBQXFCO0FBQ3pCOztBQUVBO0lBQ0kseUJBQXlCO0FBQzdCOztBQUVBO0lBQ0ksZUFBZTtJQUNmLGNBQWM7SUFDZCxnQkFBZ0I7SUFDaEIsNkJBQTZCO0lBQzdCLFlBQVk7QUFDaEIiLCJmaWxlIjoic3JjL2FwcC9wcmVmZXJlbmNlLWlkZWFsL3ByZWZlcmVuY2UtaWRlYWwvcHJlZmVyZW5jZS1pZGVhbC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnJlc2l6YWJsZS1kaXYge1xyXG4gICAgcmVzaXplOiB2ZXJ0aWNhbDtcclxuICAgIG92ZXJmbG93OiBhdXRvO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2UxZTFlMTtcclxuICAgIG1pbi1oZWlnaHQ6IDE1dmg7XHJcbn1cclxuXHJcbi8qdGFibGUgeyovXHJcbi8qICAgIGRpc3BsYXk6IGJsb2NrOyovXHJcbi8qICAgIGhlaWdodDoxMDAlOyovXHJcbi8qICAgIG92ZXJmbG93LXk6IGF1dG87Ki9cclxuLyogICAgYm9yZGVyOiBub25lOyovXHJcbi8qICAgIHdpZHRoOiAxMDAlIWltcG9ydGFudDsqL1xyXG4vKiAgICB0YWJsZS1sYXlvdXQ6IGF1dG87Ki9cclxuLyp9Ki9cclxuXHJcbi8qdGFibGUgdGQsIC50YWJsZSB0aCB7Ki9cclxuLyogICAgcGFkZGluZzogNXB4IWltcG9ydGFudDsqL1xyXG4vKiAgICBmb250LXNpemU6IC45ZW07Ki9cclxuLyogICAgd2lkdGg6IDEwMHZ3OyovXHJcbi8qfSovXHJcbnRhYmxlIHsgd2lkdGg6IDEwMCU7IHRhYmxlLWxheW91dDogZml4ZWQgfVxyXG50aCB7IHBhZGRpbmc6IDVweCFpbXBvcnRhbnQ7fVxyXG50ZCB7IHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbiAgICBmb250LXNpemU6IC45ZW07XHJcbiAgICBwYWRkaW5nOiA1cHghaW1wb3J0YW50O1xyXG4gICAgd2lkdGg6IDEwMHZ3O1xyXG59XHJcbi5idG4tcHJpbWFyeSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMmE2NDk2O1xyXG4gICAgYm9yZGVyLWNvbG9yOiAjMmE2NDk2O1xyXG59XHJcblxyXG5cclxuLmNvbGxhcHNpYmxlIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmN2Y3Zjc7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDVweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYm9yZGVyOiAjZjdmN2Y3O1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxuICAgIG1hcmdpbjogMnB4O1xyXG4gICAgcGFkZGluZy10b3A6IC41JTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAuNSU7XHJcbiAgICB0cmFuc2l0aW9uOiAwLjRzO1xyXG59XHJcblxyXG5idXR0b24uY29sbGFwc2libGU6YWZ0ZXIge1xyXG4gICAgLypjb250ZW50OiAnQ29sbGFwc2UnOyovXHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMmE2NDk2O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgYWxpZ246IG1pZGRsZTtcclxufVxyXG5cclxuYnV0dG9uLmNvbGxhcHNpYmxlLmFjdGl2ZTphZnRlciB7XHJcbiAgICAvKmNvbnRlbnQ6ICdFeHBhbmQnOyovXHJcbn1cclxuXHJcbi5hY3RpdmUsIC5jb2xsYXBzaWJsZTpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjdmN2Y3O1xyXG59XHJcblxyXG4uY29udGVudCB7XHJcbiAgICBwYWRkaW5nOiAwIDE4cHg7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAvKmJhY2tncm91bmQtY29sb3I6ICNmYWZhZmE7Ki9cclxuICAgIGJvcmRlcjogbm9uZTtcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/preference-ideal/preference-ideal/preference-ideal.component.html":
/*!***********************************************************************************!*\
  !*** ./src/app/preference-ideal/preference-ideal/preference-ideal.component.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"main \">\n    <div style=\"width: 100%; height: 82vh; \">\n            <as-split direction=\"horizontal\" (dragEnd)=\"refreshChart()\">\n            <as-split-area [size]=\"15\">\n                <div class=\"row\" style=\"margin: .5%\">\n                    <p>Select Segment</p>\n\n                    <table class=\"table table-bordered\" style=\"text-align: left!important; table-layout: auto;display: block;\">\n                        <tbody>\n                        <tr *ngFor=\"let segment of prodService.segments\"\n                            [ngClass]=\"{'highlight': segment['cell_1'] == prefService.segmentSelected}\">\n                            <td style=\"text-align: left!important; white-space: normal!important\" (click)=\"highlightSegment(segment['cell_1'])\">{{segment['cell_1']}}</td>\n                        </tr>\n                        </tbody>\n                        <tbody>\n\n                    </table>\n                </div>\n            </as-split-area>\n            <as-split-area [size]=\"85\">\n                <as-split direction=\"vertical\" (dragEnd)=\"refreshChart()\">\n                    <as-split-area #chartDiv [size]=\"40\">\n                        <div class=\"row\" style=\"align: center; margin: .5%; height: 94%; max-height: 200%; display: block\" id=\"chart-div\">\n\n                            <ejs-chart [title]=\"prefService.title\" style=\"height: inherit!important; display: block\" #chart id=\"chart-container\" [primaryXAxis]='xAxis' [primaryYAxis]=\"yAxis\" [tooltip]=\"tooltip\"\n                                       [palettes]=\"prefService.colorPalette\" [legendSettings]=\"legend\">\n                            </ejs-chart>\n                        </div>\n                        <div class=\"row\" style=\"margin-top: -50px; margin-right: 1%\">\n                            <div class=\"col\"></div>\n                            <div class=\"col-2\" style=\"padding-right: 0px!important\">\n                                <button class=\"btn btn-sm btn-primary btn-block shadow-lg\" (click)=\"openModal(colorModal)\">Chart Options</button>\n                            </div>\n                            <div class=\"col-2\" style=\"padding-right: 0px!important\">\n                                <button class=\"btn btn-sm btn-primary btn-block shadow-lg\" (click)=\"openModal(exportModal)\">Export in Excel</button>\n                            </div>\n                            <br>\n                        </div>\n                    </as-split-area>\n                    <as-split-area [size]=\"30\">\n<!--                        <button id=\"collapseBtn2\" class=\"collapsible\" (click)=\"collapsePanel('preferenceDiv', 'collapseBtn2')\" style=\"margin: 0px!important; background-color: #2a6496; color: white;\">Preference Relative to Ideal Table</button>-->\n                        <button id=\"collapseBtn2\" class=\"collapsible\" style=\"margin: 0px!important; background-color: #2a6496; color: white;\">Preference Relative to Ideal Table</button>\n\n                        <div id=\"preferenceDiv\" class=\"row content\" style=\"margin: 10px; padding: .2%;\">\n                            <table id=\"prefTable\" class=\"table\" style=\"width: 100%; alignment: left; margin-top: .2%; overflow: hidden\"\n                                   (mouseover)=\"resizableGrid('prefTable')\" >\n                                <thead class=\"thead-light\" *ngIf=\"prefService.productPref !== undefined\">\n                                <tr>\n                                    <th ></th>\n                                    <th *ngFor=\"let value of prefService.segmentLevels | keyvalue:returnZero\">{{ value.value }}</th>\n                                </tr>\n                                </thead>\n                                <tbody *ngIf=\"prefService.productPref === undefined\">\n                                <tr>\n                                    <td></td>\n                                </tr>\n                                <tr>\n                                    <td></td>\n                                </tr>\n                                <tr>\n                                    <td></td>\n                                </tr>\n                                <tr>\n                                    <td></td>\n                                </tr>\n                                </tbody>\n                                <tbody *ngIf=\"prefService.productPref !== undefined\">\n                                <tr *ngFor=\"let value of prefService.productPref | keyvalue\">\n                                    <td>{{value.key}}</td>\n                                    <td *ngFor=\"let val of value.value | keyvalue\"> {{ val.value }}</td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </as-split-area>\n                    <as-split-area [size]=\"30\">\n<!--                        <button id=\"collapseBtn\" class=\"collapsible\" (click)=\"collapsePanel('productDiv', 'collapseBtn')\" style=\"margin: 0px!important; background-color: #2a6496; color: white;\">Products</button>-->\n                        <button id=\"collapseBtn\" class=\"collapsible\" style=\"margin: 0px!important; background-color: #2a6496; color: white;\">Products</button>\n                        <div id=\"productDiv\" class=\"row content\" style=\"margin: .2%; padding: .2%; \">\n<!--                            <div class=\"col-6\">Product Table</div>-->\n                            <table id=\"productTable\" class=\"table\" style=\"width: 100%; alignment: left; margin-top: .2%\"\n                                   (mouseover)=\"resizableGrid('productTable')\">\n                                <thead class=\"thead-light\">\n                                    <tr><th resizable></th><th resizable *ngFor=\"let att of sceManagementService.selectedScenario.products[0].attribute | keyvalue\">{{att.key}}</th></tr>\n                                </thead>\n                                <tbody>\n                                <tr *ngFor=\"let product of sceManagementService.selectedScenario.products\">\n                                    <td>{{product.name}}</td>\n                                    <td *ngFor=\"let att of product.attributeValues\">{{att}}</td>\n                                </tr>\n                                </tbody>\n                                <tbody *ngIf=\"sceManagementService.selectedScenario === undefined\">\n                                <tr>\n                                    <td></td>\n                                </tr>\n                                <tr>\n                                    <td></td>\n                                </tr>\n                                <tr>\n                                    <td></td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                        <div class=\"col-2\"></div>\n                    </as-split-area>\n                </as-split>\n\n\n            </as-split-area>\n        </as-split>\n    </div>\n    <button class=\"open-button shadow p-3 mb-5 rounded\" (mousedown)=\"showHelpDesk()\">Help Desk</button>\n    <div class=\"chat-popup\" id=\"myForm\">\n        <form class=\"form-container\">\n            <h5>Help Desk</h5>\n            <p>Table:</p>\n            <ul>\n                <li>Average preference for products relative to ideal presented in tabular format that can easily be exported or printed.</li>\n                <li>Shows percentage to one decimal</li>\n            </ul>\n            <button type=\"button\" class=\"btn btn-primary\" (mousedown)=\"showHelpDesk()\">Close</button>\n        </form>\n    </div>\n    <!-- Message Modal -->\n    <ng-template #messageModal let-modal>\n        <div class=\"modal-header\">\n            <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\n                <span aria-hidden=\"true\">&times;</span>\n            </button>\n        </div>\n        <div class=\"modal-body\" style=\"padding-left: 10px\">\n            <p>{{exportStatus}}</p>\n        </div>\n    </ng-template>\n\n    <!-- export Modal -->\n    <ng-template #exportModal let-modal style=\"width: 100vw\">\n        <div class=\"modal-header\">\n            <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\n                <span aria-hidden=\"true\">&times;</span>\n            </button>\n        </div>\n        <div class=\"modal-body\" style=\"padding-left: 10px\">\n            <div class=\"row\" style=\"padding: 5%\">\n\n                <button class=\"btn btn-sm btn-primary btn-block shadow-lg\"\n                        (click)=\"saveFile(messageModal); modal.dismiss()\" style=\"font-size: .8em\">Append to an existing file</button>\n            </div>\n            <div class=\"row\" style=\"padding: 5%\">\n                <button class=\"btn btn-sm btn-primary btn-block shadow-lg\"\n                        (click)=\"exportAsExcelFile(messageModal); modal.dismiss()\" style=\"font-size: .8em\">Save as new file</button>\n\n\n            </div>\n        </div>\n        <div class=\"modal-footer\">\n\n        </div>\n    </ng-template>\n    <!-- Product Modal -->\n    <ng-template #productModal let-modal style=\"width: 100vw\">\n        <div class=\"modal-header\">\n            Define Product\n            <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\n                <span aria-hidden=\"true\">&times;</span>\n            </button>\n        </div>\n        <div class=\"modal-body\" style=\"padding-left: 10px\">\n            <div class=\"row\" style=\"padding: 5%\">\n\n                <app-scenario></app-scenario>\n\n            </div>\n        </div>\n        <div class=\"modal-footer\">\n\n        </div>\n    </ng-template>\n\n    <!-- Color Modal -->\n    <ng-template #colorModal let-modal style=\"width: 100vw\">\n        <div class=\"modal-header\">\n            Chart Options\n            <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\n                <span aria-hidden=\"true\">&times;</span>\n            </button>\n        </div>\n        <div class=\"modal-body\" style=\"padding-left: 10px\">\n            <div class=\"form\" style=\"padding: 5%; font-size: .9em\" >\n\n                <table width=\"100vw\" style=\"table-layout: auto;display: block;\">\n                    <tbody>\n                    <tr *ngFor=\"let segment of prefService.segmentLevels | keyvalue:returnZero; let n = index;\">\n                        <td>{{segment.value}}</td>\n                        <td><input (change)=\"setColorPallete(n, $event)\" value=\"{{prefService.colorPalette[n]}}\" ejs-colorpicker type=\"color\"></td>\n                    </tr>\n                    </tbody>\n                </table>\n                <br>\n                <div class=\"form-group\"><label for=\"title\">Chart title</label> <input id=\"title\" style=\"margin-left: .2%\" class=\"input-group-sm\" type=\"text\" value=\"{{prefService.title}}\" (change)=\"setTitle($event)\"></div>\n\n            </div>\n        </div>\n        <div class=\"modal-footer\">\n\n        </div>\n    </ng-template>\n</div>\n"

/***/ }),

/***/ "./src/app/preference-ideal/preference-ideal/preference-ideal.component.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/preference-ideal/preference-ideal/preference-ideal.component.ts ***!
  \*********************************************************************************/
/*! exports provided: PreferenceIdealComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreferenceIdealComponent", function() { return PreferenceIdealComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _preference_ideal_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../preference-ideal.service */ "./src/app/preference-ideal/preference-ideal.service.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../product/productmanagement.service */ "./src/app/product/productmanagement.service.ts");
/* harmony import */ var _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @syncfusion/ej2-angular-charts */ "./node_modules/@syncfusion/ej2-angular-charts/@syncfusion/ej2-angular-charts.es5.js");
/* harmony import */ var _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../scenario/scenariomanagement.service */ "./src/app/scenario/scenariomanagement.service.ts");
/* harmony import */ var _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../service/selected-scenario.service */ "./src/app/service/selected-scenario.service.ts");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! xlsx */ "./node_modules/xlsx/xlsx.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! exceljs/dist/exceljs.min.js */ "./node_modules/exceljs/dist/exceljs.min.js");
/* harmony import */ var exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var browser_nativefs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! browser-nativefs */ "./node_modules/browser-nativefs/dist/index.js");
/* harmony import */ var _core_header_header_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../core/header/header.service */ "./src/app/core/header/header.service.ts");














var PreferenceIdealComponent = /** @class */ (function () {
    function PreferenceIdealComponent(prefService, modalService, prodService, sceManagementService, selectedScenarioService, utilityService, headerService) {
        var _this = this;
        this.prefService = prefService;
        this.modalService = modalService;
        this.prodService = prodService;
        this.sceManagementService = sceManagementService;
        this.selectedScenarioService = selectedScenarioService;
        this.utilityService = utilityService;
        this.headerService = headerService;
        this.chartData = [];
        this.utilityService.cast.subscribe(function (utility) {
            _this.utility = utility;
            if (_this.headerService.increment === 0) {
                _this.prefService.segmentSelected = _this.prodService.segments[0]['cell_1'];
            }
            _this.calculatePrefIdeal();
        });
        this.selectedScenarioService.cast.subscribe(function (sce) {
            _this.prefService.prodList = sce.products;
            _this.calculatePrefIdeal();
        });
        var helpdesk = document.getElementById('myForm');
        if (helpdesk.style.display === 'block') {
            helpdesk.style.display = 'none';
        }
    }
    PreferenceIdealComponent.prototype.ngOnInit = function () {
        this.xAxis = {
            valueType: 'Category'
        };
        this.yAxis = {
            minimum: 0,
            maximum: 100,
            interval: 20,
        };
        this.tooltip = { enable: true, header: 'Preference to ideal', format: '<b>${point.tooltip} : ${point.y}</b>' };
        this.marker = { visible: true, dataLabel: { visible: true, name: 'text' } };
        this.legend = {
            visible: true,
            position: 'Bottom'
        };
    };
    PreferenceIdealComponent.prototype.ngAfterContentInit = function () {
        this.calculatePrefIdeal();
    };
    PreferenceIdealComponent.prototype.ngOnChanges = function (changes) {
        this.calculatePrefIdeal();
    };
    PreferenceIdealComponent.prototype.chartResize = function (event) {
        this.chartObj.chartResize(event);
    };
    PreferenceIdealComponent.prototype.setColorPallete = function (id, event) {
        this.prefService.colorPalette[id] = event.target.value;
        this.chartObj.refresh();
    };
    PreferenceIdealComponent.prototype.refreshChart = function () {
        this.chartObj.refresh();
    };
    PreferenceIdealComponent.prototype.showHelpDesk = function () {
        var helpdesk = document.getElementById('myForm');
        if (helpdesk.style.display === 'none') {
            helpdesk.style.display = 'block';
        }
        else {
            helpdesk.style.display = 'none';
        }
    };
    PreferenceIdealComponent.prototype.returnZero = function () {
        return 0;
    };
    PreferenceIdealComponent.prototype.highlightSegment = function (segment) {
        this.prefService.segmentSelected = segment;
        this.calculatePrefIdeal();
    };
    PreferenceIdealComponent.prototype.openModal = function (targetModal) {
        this.modalService.open(targetModal, {
            centered: true,
            backdrop: 'static',
            size: 'sm'
        });
    };
    PreferenceIdealComponent.prototype.setTitle = function (event) {
        this.prefService.title = event.target.value;
    };
    PreferenceIdealComponent.prototype.calculatePrefIdeal = function () {
        var _this = this;
        this.prefService.getSegmentValues();
        this.chartData = [];
        this.chartSeriesName = [];
        var preference = [];
        if (!Object(util__WEBPACK_IMPORTED_MODULE_10__["isUndefined"])(this.chartObj)) {
            this.chartObj.series = [];
        }
        this.prefService.productPref.forEach(function (value, key) {
            var temp = [];
            value.forEach(function (value2, key2) {
                temp.push(value2);
            });
            preference.push(temp);
        });
        var maxLen = preference.reduce(function (max, _a) {
            var length = _a.length;
            return Math.max(max, length);
        }, 0);
        preference = Array.from({ length: maxLen }, function (_, i) { return preference.map(function (row) { return row[i]; }); });
        var segIter = 0;
        this.prefService.segmentLevels.forEach(function (preferenceLabel) {
            var preferenceMetric = preference[segIter++];
            _this.addSeries(preferenceMetric, preferenceLabel);
        });
    };
    PreferenceIdealComponent.prototype.addSeries = function (data, tooltip) {
        var chartData = [];
        var i = 0;
        this.prefService.productPref.forEach(function (value, key) {
            chartData.push({ seg: key, preference: Number(data[i++]), text: tooltip });
        });
        if (!Object(util__WEBPACK_IMPORTED_MODULE_10__["isUndefined"])(this.chartObj)) {
            this.chartObj.addSeries([{
                    type: 'Column',
                    dataSource: chartData,
                    xName: 'seg', width: 2,
                    yName: 'preference',
                    name: tooltip,
                    legendShape: 'SeriesType',
                    tooltipMappingName: 'text'
                }]);
        }
    };
    PreferenceIdealComponent.prototype.exportAsExcelFile = function (targetModal) {
        var _this = this;
        var sce = this.sceManagementService.selectedScenario;
        var workbook = new exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_9__["Workbook"]();
        var title = 'SimPRO Price Preference Relative to Ideal';
        var worksheet = workbook.addWorksheet('Preference to ideal');
        // // Add Row and formatting
        // const titleRow = worksheet.addRow([title]);
        // titleRow.font = {name: 'Arial', family: 4, size: 12, underline: 'double', bold: true};
        worksheet.addRow([]);
        worksheet.addRow([this.utility.name]);
        var sceRow = worksheet.addRow([sce.name, sce.savingDate]);
        sceRow.font = { name: 'Arial' };
        sceRow.alignment = { vertical: 'middle', horizontal: 'left' };
        worksheet.addRow([]);
        // Product table
        var tableRow = worksheet.addRow(['Table of Products']);
        tableRow.font = { bold: true, italic: true };
        tableRow.alignment = { vertical: 'middle', horizontal: 'left' };
        var header = new Array();
        header.push('Product');
        sce.products[0].attribute.forEach(function (value, key) {
            header.push(key);
        });
        var headRow = worksheet.addRow(header);
        headRow.font = { bold: true };
        headRow.alignment = { vertical: 'middle', horizontal: 'left' };
        var _loop_1 = function (prod) {
            var product = new Array();
            product.push(prod.name);
            prod.attributeValues.forEach(function (value, key) {
                product.push(value);
            });
            var prodRow = worksheet.addRow(product);
            prodRow.alignment = { vertical: 'middle', horizontal: 'left' };
        };
        for (var _i = 0, _a = sce.products; _i < _a.length; _i++) {
            var prod = _a[_i];
            _loop_1(prod);
        }
        worksheet.addRow([]);
        // Preference table
        var simulation = worksheet.addRow(['Simulation']);
        simulation.font = { name: 'Arial', italic: true };
        simulation.alignment = { vertical: 'middle', horizontal: 'left', };
        var prefHeadRow = new Array();
        prefHeadRow.push('Product');
        this.prefService.segmentLevels.forEach(function (value, key) {
            prefHeadRow.push(value);
        });
        var prefHead = worksheet.addRow(prefHeadRow);
        prefHead.font = { bold: true };
        prefHead.alignment = { vertical: 'middle', horizontal: 'left' };
        this.prefService.productPref.forEach(function (value, key) {
            var prefRow = new Array();
            prefRow.push(key);
            value.forEach(function (i, n) {
                prefRow.push(i);
            });
            var prefTableRow = worksheet.addRow(prefRow);
            prefTableRow.alignment = { vertical: 'middle', horizontal: 'left' };
        });
        setTimeout(function () {
            workbook.xlsx.writeBuffer().then(function (data2) {
                var blob = new Blob([data2], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                // fs.saveAs(blob, 'TMTG_simpro_export.xlsx');
                var options = {
                    // Suggested file name to use, defaults to `''`.
                    fileName: 'TMTG_simpro_export.xlsx',
                    // Suggested file extensions (with leading '.'), defaults to `''`.
                    extensions: ['.xlsx'],
                };
                // Optional file handle to save back to an existing file.
                // This will only work with the File System Access API.
                // Get a `FileHandle` from the `handle` property of the `Blob`
                // you receive from `fileOpen()` (this is non-standard).
                // const handle = previouslyOpenedBlob.handle;
                var opts = {
                    types: [{
                            description: 'Excel file',
                            accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] },
                        }],
                };
                _this.saveAsNewFile(targetModal, blob, options).then(function (z) {
                    _this.exportStatus = 'File successfully exported.';
                    _this.modalService.open(targetModal, {
                        centered: true,
                        backdrop: 'static',
                        size: 'sm'
                    });
                }).catch(function (e) {
                    _this.exportStatus = 'Error! Please make sure file is closed.';
                    _this.modalService.open(targetModal, {
                        centered: true,
                        backdrop: 'static',
                        size: 'sm'
                    });
                });
            });
        }, 1500);
    };
    PreferenceIdealComponent.prototype.saveFile = function (targetModal) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var workbook, fileReader, options2, opts, blob;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        workbook = new exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_9__["Workbook"]();
                        fileReader = new FileReader();
                        options2 = {
                            // List of allowed MIME types, defaults to `*/*`.
                            mimeTypes: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
                            // List of allowed file extensions (with leading '.'), defaults to `''`.
                            extensions: ['.xlsx'],
                            // Set to `true` for allowing multiple files, defaults to `false`.
                            multiple: false,
                        };
                        opts = {
                            types: [{
                                    description: 'Excel file',
                                    accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] },
                                }],
                        };
                        return [4 /*yield*/, Object(browser_nativefs__WEBPACK_IMPORTED_MODULE_12__["fileOpen"])(options2)];
                    case 1:
                        blob = _a.sent();
                        // @ts-ignore
                        fileReader.readAsBinaryString(new Blob([blob], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
                        fileReader.onload = function (z) {
                            var wb = xlsx__WEBPACK_IMPORTED_MODULE_8__["read"](fileReader.result, { type: 'binary' });
                            var sheetNames = wb.SheetNames;
                            // Copy sheets
                            if (sheetNames.indexOf('Preference relative to ideal') < 0) {
                                workbook.addWorksheet('Preference relative to ideal');
                            }
                            for (var j in sheetNames) {
                                var workSheet = workbook.addWorksheet(sheetNames[j]);
                                workSheet.addRow([]);
                                // Add utility name
                                var rows = xlsx__WEBPACK_IMPORTED_MODULE_8__["utils"].sheet_to_json(wb.Sheets[sheetNames[j]], { raw: false });
                                workSheet.addRow([Object.keys(rows[0])[0]]);
                                for (var _i = 0, _a = xlsx__WEBPACK_IMPORTED_MODULE_8__["utils"].sheet_to_json(wb.Sheets[sheetNames[j]], { raw: false }); _i < _a.length; _i++) {
                                    var i = _a[_i];
                                    var tempArr = [];
                                    for (var n in i) {
                                        tempArr.push(i[n]);
                                    }
                                    if (tempArr[0] === 'Table of Products' || tempArr[0] === 'Simulation') {
                                        workSheet.addRow([]);
                                        var row = workSheet.addRow(tempArr);
                                        row.font = { name: 'Arial', bold: true, italic: true };
                                        row.alignment = { vertical: 'middle', horizontal: 'left' };
                                    }
                                    else if (tempArr[0] === 'Product') {
                                        var row = workSheet.addRow(tempArr);
                                        row.font = { bold: true };
                                        row.alignment = { vertical: 'middle', horizontal: 'left' };
                                    }
                                    else {
                                        var row = workSheet.addRow(tempArr);
                                        row.alignment = { vertical: 'middle', horizontal: 'left' };
                                    }
                                }
                            }
                            // @ts-ignore
                            _this.addSheet(workbook.getWorksheet('Preference relative to ideal'), workbook, blob.handle, targetModal);
                        };
                        return [2 /*return*/];
                }
            });
        });
    };
    PreferenceIdealComponent.prototype.addSheet = function (worksheet, workbook, fileHandle, targetModal) {
        var _this = this;
        var sce = this.sceManagementService.selectedScenario;
        worksheet.addRow([]);
        // Add Row and formatting
        // const title = 'SimPRO Price Preference Relative to Ideal';
        // const titleRow = worksheet.addRow([title]);
        // titleRow.font = {name: 'Arial', family: 4, size: 13, underline: 'double', bold: true};
        worksheet.addRow([]);
        worksheet.addRow([this.utility.name]);
        var sceRow = worksheet.addRow([sce.name, sce.savingDate]);
        sceRow.alignment = { vertical: 'middle', horizontal: 'left' };
        worksheet.addRow([]);
        // Product table
        var tableRow = worksheet.addRow(['Table of Products']);
        tableRow.font = { bold: true, italic: true };
        tableRow.alignment = { vertical: 'middle', horizontal: 'left' };
        var header = new Array();
        header.push('Product');
        sce.products[0].attribute.forEach(function (value, key) {
            header.push(key);
        });
        var headRow = worksheet.addRow(header);
        headRow.font = { bold: true };
        headRow.alignment = { vertical: 'middle', horizontal: 'left' };
        var _loop_2 = function (prod) {
            var product = new Array();
            product.push(prod.name);
            prod.attributeValues.forEach(function (value, key) {
                product.push(value);
            });
            var prodRow = worksheet.addRow(product);
            prodRow.alignment = { vertical: 'middle', horizontal: 'left' };
        };
        for (var _i = 0, _a = sce.products; _i < _a.length; _i++) {
            var prod = _a[_i];
            _loop_2(prod);
        }
        worksheet.addRow([]);
        // Preference table
        var simulation = worksheet.addRow(['Simulation']);
        simulation.font = { name: 'Arial', italic: true };
        simulation.alignment = { vertical: 'middle', horizontal: 'left' };
        var prefHeadRow = new Array();
        prefHeadRow.push('Product');
        this.prefService.segmentLevels.forEach(function (value, key) {
            prefHeadRow.push(value);
        });
        var prefHead = worksheet.addRow(prefHeadRow);
        prefHead.font = { bold: true };
        prefHead.alignment = { vertical: 'middle', horizontal: 'left' };
        this.prefService.productPref.forEach(function (value, key) {
            var prefRow = new Array();
            prefRow.push(key);
            value.forEach(function (i, n) {
                prefRow.push(i);
            });
            var prefTableRow = worksheet.addRow(prefRow);
            prefTableRow.alignment = { vertical: 'middle', horizontal: 'left' };
        });
        // Add Image
        // html2canvas(document.querySelector('#chart-div')).then(canvas => {
        //     let image = canvas.toDataURL('image/png', 1.0);
        //     image = image.replace(/^data:image\/(png|jpg);base64,/, '');
        //     const imageId1 = workbook.addImage({
        //         base64: image,
        //         extension: 'png',
        //     });
        //
        //     // worksheet.addImage(imageId1, 'M2:U8');
        // });
        setTimeout(function () {
            var options = {
                // Suggested file name to use, defaults to `''`.
                fileName: 'TMTG_simpro_export.xlsx',
                // Suggested file extensions (with leading '.'), defaults to `''`.
                extensions: ['.xlsx'],
            };
            workbook.xlsx.writeBuffer().then(function (data2) {
                var blob = new Blob([data2], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                // fileSave(blob);
                // this.saveAsNewFile(targetModal, blob, options).then((res) => {
                _this.writeFile(fileHandle, data2).then(function (z) {
                    _this.exportStatus = 'File successfully exported.';
                    _this.modalService.open(targetModal, {
                        centered: true,
                        backdrop: 'static',
                        size: 'sm'
                    });
                }).catch(function (e) {
                    console.log(e);
                    _this.exportStatus = 'Error! Please make sure file is closed.';
                    _this.modalService.open(targetModal, {
                        centered: true,
                        backdrop: 'static',
                        size: 'sm'
                    });
                });
            });
        }, 1500);
    };
    PreferenceIdealComponent.prototype.saveAsNewFile = function (targetModal, blob, options) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Object(browser_nativefs__WEBPACK_IMPORTED_MODULE_12__["fileSave"])(blob, options)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PreferenceIdealComponent.prototype.writeFile = function (fileHandle, contents) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var writable;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, fileHandle.createWritable()];
                    case 1:
                        writable = _a.sent();
                        // Write the contents of the file to the stream.
                        return [4 /*yield*/, writable.write(contents)];
                    case 2:
                        // Write the contents of the file to the stream.
                        _a.sent();
                        // Close the file and write the contents to disk.
                        return [4 /*yield*/, writable.close()];
                    case 3:
                        // Close the file and write the contents to disk.
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PreferenceIdealComponent.prototype.resizableGrid = function (tableId) {
        // console.log(table);
        var row = document.getElementById(tableId).getElementsByTagName('tr')[0];
        var cols = row ? row.children : undefined;
        if (!cols) {
            return;
        }
        document.getElementById(tableId).style.overflow = 'hidden';
        var tableHeight = document.getElementById(tableId).offsetHeight;
        for (var i = 0; i < cols.length; i++) {
            var div = this.createDiv(tableHeight);
            cols[i].appendChild(div);
            cols[i].style.position = 'relative';
            this.setListeners(div);
        }
    };
    PreferenceIdealComponent.prototype.setListeners = function (div) {
        var _this = this;
        var pageX, curCol, nxtCol, curColWidth, nxtColWidth;
        div.addEventListener('mousedown', function (e) {
            curCol = e.target.parentElement;
            nxtCol = curCol.nextElementSibling;
            pageX = e.pageX;
            var padding = _this.paddingDiff(curCol);
            curColWidth = curCol.offsetWidth - padding;
            if (nxtCol) {
                nxtColWidth = nxtCol.offsetWidth - padding;
            }
        });
        div.addEventListener('mouseover', function (e) {
            e.target.style.borderRight = '2px solid #0000ff';
        });
        div.addEventListener('mouseout', function (e) {
            e.target.style.borderRight = '';
        });
        document.addEventListener('mousemove', function (e) {
            if (curCol) {
                var diffX = e.pageX - pageX;
                if (nxtCol) {
                    nxtCol.style.width = (nxtColWidth - (diffX)) + 'px';
                }
                curCol.style.width = (curColWidth + diffX) + 'px';
            }
        });
        document.addEventListener('mouseup', function (e) {
            curCol = undefined;
            nxtCol = undefined;
            pageX = undefined;
            nxtColWidth = undefined;
            curColWidth = undefined;
        });
    };
    PreferenceIdealComponent.prototype.createDiv = function (height) {
        var div = document.createElement('div');
        div.style.top = '0';
        div.style.right = '0';
        div.style.width = '5px';
        div.style.position = 'absolute';
        div.style.cursor = 'col-resize';
        div.style.userSelect = 'none';
        div.style.height = height + 'px';
        return div;
    };
    PreferenceIdealComponent.prototype.paddingDiff = function (col) {
        if (this.getStyleVal(col, 'box-sizing') === 'border-box') {
            return 0;
        }
        var padLeft = this.getStyleVal(col, 'padding-left');
        var padRight = this.getStyleVal(col, 'padding-right');
        // tslint:disable-next-line:radix
        return (parseInt(padLeft) + parseInt(padRight));
    };
    PreferenceIdealComponent.prototype.getStyleVal = function (elm, css) {
        return (window.getComputedStyle(elm, null).getPropertyValue(css));
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('chartDiv'),
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('chart'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_5__["ChartComponent"])
    ], PreferenceIdealComponent.prototype, "chartObj", void 0);
    PreferenceIdealComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-preference-ideal',
            template: __webpack_require__(/*! ./preference-ideal.component.html */ "./src/app/preference-ideal/preference-ideal/preference-ideal.component.html"),
            styles: [__webpack_require__(/*! ./preference-ideal.component.css */ "./src/app/preference-ideal/preference-ideal/preference-ideal.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_preference_ideal_service__WEBPACK_IMPORTED_MODULE_2__["PreferenceIdealService"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_3__["NgbModal"],
            _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_4__["ProductmanagementService"],
            _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_6__["ScenariomanagementService"],
            _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_7__["SelectedScenarioService"],
            _service_utility_service__WEBPACK_IMPORTED_MODULE_11__["UtilityService"],
            _core_header_header_service__WEBPACK_IMPORTED_MODULE_13__["HeaderService"]])
    ], PreferenceIdealComponent);
    return PreferenceIdealComponent;
}());



/***/ }),

/***/ "./src/app/preference/preference.module.ts":
/*!*************************************************!*\
  !*** ./src/app/preference/preference.module.ts ***!
  \*************************************************/
/*! exports provided: PreferenceModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreferenceModule", function() { return PreferenceModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _preference_preference_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./preference/preference.component */ "./src/app/preference/preference/preference.component.ts");
/* harmony import */ var _scenario_scenario_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../scenario/scenario.module */ "./src/app/scenario/scenario.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @syncfusion/ej2-angular-charts */ "./node_modules/@syncfusion/ej2-angular-charts/@syncfusion/ej2-angular-charts.es5.js");
/* harmony import */ var _resizable_resizable_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../resizable/resizable.module */ "./src/app/resizable/resizable.module.ts");
/* harmony import */ var angular_split__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! angular-split */ "./node_modules/angular-split/fesm5/angular-split.js");











var PreferenceModule = /** @class */ (function () {
    function PreferenceModule() {
    }
    PreferenceModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_preference_preference_component__WEBPACK_IMPORTED_MODULE_3__["PreferenceComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _scenario_scenario_module__WEBPACK_IMPORTED_MODULE_4__["ScenarioModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbModule"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["ChartModule"],
                _resizable_resizable_module__WEBPACK_IMPORTED_MODULE_8__["ResizableModule"],
                angular_split__WEBPACK_IMPORTED_MODULE_9__["AngularSplitModule"]
            ],
            exports: [
                _preference_preference_component__WEBPACK_IMPORTED_MODULE_3__["PreferenceComponent"]
            ],
            providers: [
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["ColumnSeriesService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["CategoryService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["StackingColumnSeriesService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["DateTimeService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["ScrollBarService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["LineSeriesService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["ExportService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["ChartAnnotationService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["RangeColumnSeriesService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["StackingColumnSeriesService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["LegendService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["TooltipService"]
            ]
        })
    ], PreferenceModule);
    return PreferenceModule;
}());



/***/ }),

/***/ "./src/app/preference/preference.service.ts":
/*!**************************************************!*\
  !*** ./src/app/preference/preference.service.ts ***!
  \**************************************************/
/*! exports provided: PreferenceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreferenceService", function() { return PreferenceService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var _service_product_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/product.service */ "./src/app/service/product.service.ts");
/* harmony import */ var _connection_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../connection.service */ "./src/app/connection.service.ts");
/* harmony import */ var _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../product/productmanagement.service */ "./src/app/product/productmanagement.service.ts");
/* harmony import */ var ng2_charts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng2-charts */ "./node_modules/ng2-charts/fesm5/ng2-charts.js");
/* harmony import */ var _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../scenario/scenariomanagement.service */ "./src/app/scenario/scenariomanagement.service.ts");
/* harmony import */ var _service_scenario_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../service/scenario.service */ "./src/app/service/scenario.service.ts");
/* harmony import */ var _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../service/selected-scenario.service */ "./src/app/service/selected-scenario.service.ts");
/* harmony import */ var _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utility/utilitymanagement.service */ "./src/app/utility/utilitymanagement.service.ts");











var PreferenceService = /** @class */ (function () {
    function PreferenceService(utilityService, productService, connectionService, prodService, selectedScenarioService, sceManagementService, scenarioService, utlManagementService) {
        var _this = this;
        this.utilityService = utilityService;
        this.productService = productService;
        this.connectionService = connectionService;
        this.prodService = prodService;
        this.selectedScenarioService = selectedScenarioService;
        this.sceManagementService = sceManagementService;
        this.scenarioService = scenarioService;
        this.utlManagementService = utlManagementService;
        this.seg = new Map();
        this.tune = new Map();
        this.weight = new Map();
        this.productHeaderAtt = new Map();
        this.productAtt = [];
        this.productAttVal = [];
        this.segments = []; // dropdown
        this.dataCnt = new Map();
        // Initial values and values * tune
        this.iniValues = new Map();
        this.values = new Map();
        this.products = []; // For defined products
        this.expList = [];
        this.cellNumber = new Map();
        this.cellNumList = [];
        this.totalList = [];
        this.barChartOptions = {
            scaleShowVerticalLines: false,
            responsive: true
        };
        this.barChartType = 'bar';
        this.barChartLegend = true;
        this.barChartData = [{ data: [], label: 'Series A' },
            { data: [], label: 'Series B' }];
        this.utilityService.cast.subscribe(function (utility) { return _this.utility = utility; });
        // this.productService.products$.subscribe(productList => this.prodList = productList);
        // this.scenarioService.scenarios$.subscribe(scenario => this.prodList = scenario.products);
        // this.productService.products$.subscribe(productList => this.prodList = productList);
        // this.prodList = this.sceManagementService.selectedScenario.products;
    }
    PreferenceService.prototype.ngOnChanges = function () {
        var _this = this;
        this.utilityService.cast.subscribe(function (utility) { return _this.utility = utility; });
        // this.productService.products$.subscribe(productList => this.prodList = productList);
        this.segments = this.prodService.segments;
    };
    PreferenceService.prototype.ngOnInit = function () {
        if ((this.utility.utl_xml) !== undefined) {
            this.segments = this.prodService.segments;
            this.convertToJson();
            // this.getAttributes();
        }
        this.createSegTable();
    };
    /**
     * Parse utility data and save segment, product attribute, tune and weight values
     */
    PreferenceService.prototype.convertToJson = function () {
        // tslint:disable-next-line:one-variable-per-declaration
        var temp2, temp, val, val2, cnt = 0;
        var cell0 = 'cell_0';
        this.segments = []; // unset segments
        for (var _i = 0, _a = Object.keys(this.utility.utl_xml); _i < _a.length; _i++) {
            var field = _a[_i];
            temp = (this.utility.utl_xml[field]);
            cnt = 0;
            for (var _b = 0, _c = Object.keys(temp); _b < _c.length; _b++) {
                val = _c[_b];
                temp2 = temp[val];
                for (var _d = 0, _e = Object.keys(temp[val]); _d < _e.length; _d++) {
                    val2 = _e[_d];
                    if (temp2[val2][cell0] === '1') {
                        this.segments.push(temp2[val2]);
                    }
                    else if (temp2[val2][cell0] === '4') {
                        this.productAtt.push(temp2[val2]);
                    }
                    else if (temp2[val2][cell0] === '2' && this.tuneId !== 0) {
                        this.tuneId = cnt;
                    }
                    else if (temp2[val2][cell0] === '3' && this.weightId !== 0) {
                        this.weightId = cnt;
                    }
                    cnt++;
                }
            }
        }
        this.productAttVal = this.utility.utl_val;
    };
    /**
     * Get attributes from utility file
     */
    PreferenceService.prototype.getAttributes = function () {
        var count2 = 0;
        var cnt = 0;
        var temp = [];
        var cell2 = 'cell_2';
        var cell1 = 'cell_1';
        for (var i = 0; i < this.productAtt.length; i++) {
            if (count2 === 0) {
                temp[count2++] = this.productAtt[i][cell2];
                this.products[cnt++] = this.productAtt[i][cell2];
            }
            else if (this.productAtt[i - 1][cell1] === this.productAtt[i][cell1]) {
                temp[count2++] = this.productAtt[i][cell2];
            }
            else if (this.productAtt[i - 1][cell1] !== this.productAtt[i][cell1]) {
                count2 = 0;
                this.productHeaderAtt.set(this.productAtt[i - 1][cell1], temp);
                if (JSON.stringify(this.productAtt[i][cell1]) === JSON.stringify('NONE') ||
                    JSON.stringify(this.productAtt[i][cell1]) === JSON.stringify('None')) {
                    this.noneCol = i;
                }
                else if (JSON.stringify(this.productAtt[i][cell1]) !== JSON.stringify('NONE') ||
                    JSON.stringify(this.productAtt[i][cell1]) !== JSON.stringify('None')) {
                    this.products[cnt++] = this.productAtt[i][cell2];
                }
                temp = []; // Clean temp storage
                temp[count2++] = this.productAtt[i][cell2];
            }
        }
    };
    PreferenceService.prototype.createSegTable = function () {
        var segTable = document.createElement('table');
        var tr = segTable.insertRow(-1);
        var size = 0;
        segTable.setAttribute('id', 'segTable');
        segTable.setAttribute('class', 'table table-sm table-bordered');
        // Clear all storage
        this.totalList = [];
        this.seg = new Map();
        this.productPreference = new Map();
        this.barChartLabels = [];
        this.segments = this.prodService.segments;
        this.productHeaderAtt = this.prodService.productHeaderAtt;
        // tslint:disable-next-line:prefer-for-of
        for (var i = 0; i < this.segments.length; i++) {
            if (JSON.stringify((this.segments[i])["cell_1"]) === JSON.stringify(this.segment)) {
                var cnt = 0;
                this.segmentId = i;
                do {
                    if ((this.segments[i])['cell_2_' + cnt]) {
                        this.seg.set((this.segments[i])['cell_2_' + cnt], (this.segments[i])['cell_3_' + cnt]);
                        this.barChartLabels.push((this.segments[i])['cell_3_' + cnt]);
                        size = cnt;
                    }
                    cnt++;
                } while ((this.segments[i])['cell_3_' + cnt] || cnt <= Object.keys(this.segments[i]).length);
            }
        }
        this.seg.set(((size + 2).toString()), 'Total');
        this.calculateRelativeResult();
    };
    PreferenceService.prototype.calculateRelativeResult = function () {
        var _this = this;
        // Get segment position
        var segLevels = this.utlManagementService.getSegmentValues(this.prodService.segmentPositions[this.segmentId]);
        var prefList = this.utlManagementService.getRelativeResult(this.prodList);
        var segPrefList = [];
        for (var i in prefList) {
            var temp = [];
            //console.log("temp and pref:",temp, prefList); //eanDebug
            for (var n in prefList[i]) {
                temp.push([Number(segLevels[n]), prefList[i][n]]);
            }
            segPrefList.push(temp);
        }
        var _loop_1 = function (i) {
            var sumMap = new Map();
            var sumArray = [];
            var total = 0;
            var keyCnt = 0;
            this_1.seg.forEach(function (value, key) {
                var sum = 0;
                var cnt = 0;
                if (keyCnt < _this.seg.size - 1) {
                    for (var n in segPrefList[i]) {
                        if (Number(key) === segPrefList[i][n][0]) {
                            sum += Number(segPrefList[i][n][1]);
                            total += Number(segPrefList[i][n][1]);
                            cnt++;
                        }
                    }
                    if (sum !== 0) {
                        sumMap.set(key, (sum / cnt).toFixed(1));
                        sumArray.push((sum / cnt).toFixed(1));
                    }
                    else {
                        sumMap.set(key, 0);
                        sumArray.push(0);
                    }
                    _this.dataCnt.set(Number(key), cnt);
                }
                else {
                    _this.dataCnt.set(_this.seg.size, segPrefList[i].length);
                    sumArray.push((total / segPrefList[i].length).toFixed(1));
                    sumMap.set(key, (total / segPrefList[i].length).toFixed(1));
                }
                keyCnt++;
            });
            if (Number(i) < segPrefList.length - 1) {
                this_1.productPreference.set(this_1.sceManagementService.selectedScenario.products[i].name, sumArray);
            }
            else {
                this_1.productPreference.set('None', sumArray);
            }
        };
        var this_1 = this;
        for (var i in segPrefList) {
            _loop_1(i);
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(ng2_charts__WEBPACK_IMPORTED_MODULE_6__["BaseChartDirective"]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", ng2_charts__WEBPACK_IMPORTED_MODULE_6__["BaseChartDirective"])
    ], PreferenceService.prototype, "chart", void 0);
    PreferenceService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_service_utility_service__WEBPACK_IMPORTED_MODULE_2__["UtilityService"],
            _service_product_service__WEBPACK_IMPORTED_MODULE_3__["ProductService"],
            _connection_service__WEBPACK_IMPORTED_MODULE_4__["ConnectionService"],
            _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_5__["ProductmanagementService"],
            _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_9__["SelectedScenarioService"],
            _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_7__["ScenariomanagementService"],
            _service_scenario_service__WEBPACK_IMPORTED_MODULE_8__["ScenarioService"],
            _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_10__["UtilitymanagementService"]])
    ], PreferenceService);
    return PreferenceService;
}());



/***/ }),

/***/ "./src/app/preference/preference/preference.component.css":
/*!****************************************************************!*\
  !*** ./src/app/preference/preference/preference.component.css ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/*table {*/\r\n/*    display: inline-block;*/\r\n/*    height:100%;*/\r\n/*    overflow-y: auto;*/\r\n/*    border: none;*/\r\n/*    width: 100%!important;*/\r\n/*    table-layout: auto;*/\r\n/*}*/\r\n/*table td, .table th {*/\r\n/*     padding: 5px!important;*/\r\n/*     font-size: .9em;*/\r\n/*     width: 100vw;*/\r\n/* }*/\r\ntable { width: 100%; table-layout: fixed }\r\nth { padding: 5px!important;}\r\ntd { white-space: nowrap;\r\n    overflow: hidden;\r\n    text-overflow: ellipsis;\r\n    font-size: .9em;\r\n    padding: 5px!important;\r\n    width: 100vw;\r\n}\r\n.btn-primary {\r\n    background-color: #2a6496;\r\n    border-color: #2a6496;\r\n}\r\n.collapsible {\r\n    background-color: #f7f7f7;\r\n    cursor: pointer;\r\n    padding-left: 5px;\r\n    width: 100%;\r\n    border: #f7f7f7;\r\n    text-align: left;\r\n    outline: none;\r\n    font-size: 1em;\r\n    margin: 2px;\r\n    padding-top: .2%;\r\n    padding-bottom: .2%;\r\n    -webkit-transition: 0.4s;\r\n    transition: 0.4s;\r\n}\r\nbutton.collapsible:after {\r\n    /*content: 'Collapse';*/\r\n    color: white;\r\n    background-color: #2a6496;\r\n    margin-right: 10px;\r\n    float: right;\r\n    align: middle;\r\n}\r\nbutton.collapsible.active:after {\r\n    /*content: 'Expand';*/\r\n}\r\n.active, .collapsible:hover {\r\n    background-color: #f7f7f7;\r\n}\r\n.content {\r\n    padding: 0 18px;\r\n    display: block;\r\n    overflow: hidden;\r\n    /*background-color: #fafafa;*/\r\n    border: none;\r\n}\r\n.resizable-div {\r\n    resize: vertical;\r\n    overflow: hidden;\r\n    border: 1px solid #e1e1e1;\r\n    min-height: 15vh;\r\n}\r\n.resize {\r\n    resize: horizontal;\r\n    border: 1px\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJlZmVyZW5jZS9wcmVmZXJlbmNlL3ByZWZlcmVuY2UuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxVQUFVO0FBQ1YsNkJBQTZCO0FBQzdCLG1CQUFtQjtBQUNuQix3QkFBd0I7QUFDeEIsb0JBQW9CO0FBQ3BCLDZCQUE2QjtBQUM3QiwwQkFBMEI7QUFDMUIsSUFBSTtBQUVKLHdCQUF3QjtBQUN4QiwrQkFBK0I7QUFDL0Isd0JBQXdCO0FBQ3hCLHFCQUFxQjtBQUNyQixLQUFLO0FBRUwsUUFBUSxXQUFXLEVBQUUsb0JBQW9CO0FBQ3pDLEtBQUssc0JBQXNCLENBQUM7QUFDNUIsS0FBSyxtQkFBbUI7SUFDcEIsZ0JBQWdCO0lBQ2hCLHVCQUF1QjtJQUN2QixlQUFlO0lBQ2Ysc0JBQXNCO0lBQ3RCLFlBQVk7QUFDaEI7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixxQkFBcUI7QUFDekI7QUFHQTtJQUNJLHlCQUF5QjtJQUN6QixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLFdBQVc7SUFDWCxlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLGFBQWE7SUFDYixjQUFjO0lBQ2QsV0FBVztJQUNYLGdCQUFnQjtJQUNoQixtQkFBbUI7SUFDbkIsd0JBQWdCO0lBQWhCLGdCQUFnQjtBQUNwQjtBQUVBO0lBQ0ksdUJBQXVCO0lBQ3ZCLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWixhQUFhO0FBQ2pCO0FBRUE7SUFDSSxxQkFBcUI7QUFDekI7QUFFQTtJQUNJLHlCQUF5QjtBQUM3QjtBQUVBO0lBQ0ksZUFBZTtJQUNmLGNBQWM7SUFDZCxnQkFBZ0I7SUFDaEIsNkJBQTZCO0lBQzdCLFlBQVk7QUFDaEI7QUFFQTtJQUNJLGdCQUFnQjtJQUNoQixnQkFBZ0I7SUFDaEIseUJBQXlCO0lBQ3pCLGdCQUFnQjtBQUNwQjtBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCO0FBQ0oiLCJmaWxlIjoic3JjL2FwcC9wcmVmZXJlbmNlL3ByZWZlcmVuY2UvcHJlZmVyZW5jZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLyp0YWJsZSB7Ki9cclxuLyogICAgZGlzcGxheTogaW5saW5lLWJsb2NrOyovXHJcbi8qICAgIGhlaWdodDoxMDAlOyovXHJcbi8qICAgIG92ZXJmbG93LXk6IGF1dG87Ki9cclxuLyogICAgYm9yZGVyOiBub25lOyovXHJcbi8qICAgIHdpZHRoOiAxMDAlIWltcG9ydGFudDsqL1xyXG4vKiAgICB0YWJsZS1sYXlvdXQ6IGF1dG87Ki9cclxuLyp9Ki9cclxuXHJcbi8qdGFibGUgdGQsIC50YWJsZSB0aCB7Ki9cclxuLyogICAgIHBhZGRpbmc6IDVweCFpbXBvcnRhbnQ7Ki9cclxuLyogICAgIGZvbnQtc2l6ZTogLjllbTsqL1xyXG4vKiAgICAgd2lkdGg6IDEwMHZ3OyovXHJcbi8qIH0qL1xyXG5cclxudGFibGUgeyB3aWR0aDogMTAwJTsgdGFibGUtbGF5b3V0OiBmaXhlZCB9XHJcbnRoIHsgcGFkZGluZzogNXB4IWltcG9ydGFudDt9XHJcbnRkIHsgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxuICAgIGZvbnQtc2l6ZTogLjllbTtcclxuICAgIHBhZGRpbmc6IDVweCFpbXBvcnRhbnQ7XHJcbiAgICB3aWR0aDogMTAwdnc7XHJcbn1cclxuXHJcbi5idG4tcHJpbWFyeSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMmE2NDk2O1xyXG4gICAgYm9yZGVyLWNvbG9yOiAjMmE2NDk2O1xyXG59XHJcblxyXG5cclxuLmNvbGxhcHNpYmxlIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmN2Y3Zjc7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDVweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYm9yZGVyOiAjZjdmN2Y3O1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxuICAgIG1hcmdpbjogMnB4O1xyXG4gICAgcGFkZGluZy10b3A6IC4yJTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAuMiU7XHJcbiAgICB0cmFuc2l0aW9uOiAwLjRzO1xyXG59XHJcblxyXG5idXR0b24uY29sbGFwc2libGU6YWZ0ZXIge1xyXG4gICAgLypjb250ZW50OiAnQ29sbGFwc2UnOyovXHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMmE2NDk2O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgYWxpZ246IG1pZGRsZTtcclxufVxyXG5cclxuYnV0dG9uLmNvbGxhcHNpYmxlLmFjdGl2ZTphZnRlciB7XHJcbiAgICAvKmNvbnRlbnQ6ICdFeHBhbmQnOyovXHJcbn1cclxuXHJcbi5hY3RpdmUsIC5jb2xsYXBzaWJsZTpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjdmN2Y3O1xyXG59XHJcblxyXG4uY29udGVudCB7XHJcbiAgICBwYWRkaW5nOiAwIDE4cHg7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAvKmJhY2tncm91bmQtY29sb3I6ICNmYWZhZmE7Ki9cclxuICAgIGJvcmRlcjogbm9uZTtcclxufVxyXG5cclxuLnJlc2l6YWJsZS1kaXYge1xyXG4gICAgcmVzaXplOiB2ZXJ0aWNhbDtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZTFlMWUxO1xyXG4gICAgbWluLWhlaWdodDogMTV2aDtcclxufVxyXG5cclxuLnJlc2l6ZSB7XHJcbiAgICByZXNpemU6IGhvcml6b250YWw7XHJcbiAgICBib3JkZXI6IDFweFxyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/preference/preference/preference.component.html":
/*!*****************************************************************!*\
  !*** ./src/app/preference/preference/preference.component.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"main \">\n    <div style=\"width: 100%; height: 82vh; \">\n        <as-split direction=\"horizontal\" (dragEnd)=\"refreshChart()\">\n            <as-split-area [size]=\"15\">\n                <div class=\"row\" style=\"margin: .5%\">\n                    <p>Select Segment</p>\n                    <table class=\"table table-bordered ed\" style=\"text-align: left!important; width: 100%!important; table-layout: auto;display: block;\">\n                        <tbody>\n                        <tr *ngFor=\"let segment of prodService.segments\"\n                            [ngClass]=\"{'highlight': segment['cell_1'] == prefService.segment}\">\n                            <td style=\"text-align: left!important; white-space: normal!important\"\n                                (click)=\"highlightSegment(segment['cell_1'])\">{{segment['cell_1']}}</td>\n                        </tr>\n                        </tbody>\n                        <tbody>\n\n                    </table>\n\n                </div>\n                <div id=\"segTable\" class=\"row\" style=\"height: auto; margin: .5%; display: none\">\n\n                </div>\n\n            </as-split-area>\n            <as-split-area [size]=\"85\">\n                <as-split direction=\"vertical\" (dragEnd)=\"refreshChart()\">\n                    <as-split-area [size]=\"40\">\n                        <div class=\"row\"\n                             style=\"align: center; margin: .5%; height: 95%!important; max-height: 200%; display: block\"\n                             id=\"chart-div\">\n                            <ejs-chart (change)=\"refreshChart()\" [title]=\"prefService.title\"\n                                       style=\"height:90%; display: block\" #chart id=\"chart-container\"\n                                       [legendSettings]=\"legend\" [tooltip]=\"tooltip\"\n                                       [primaryXAxis]='xAxis' [primaryYAxis]=\"yAxis\"\n                                       [palettes]=\"colorService.color$ | async\">\n                            </ejs-chart>\n                        </div>\n\n                        <div class=\"row\" style=\"margin-right: .5%; margin-top: -50px\">\n                            <div class=\"col\"></div>\n                            <div class=\"col-2\" style=\"padding-right: 0px!important\">\n                                <button class=\"btn btn-sm btn-primary btn-block shadow-lg\"\n                                        (click)=\"openModal(colorModal)\">Chart Options\n                                </button>\n                            </div>\n                            <div class=\"col-2\" style=\"padding-right: 0px!important\">\n                                <button class=\"btn btn-sm btn-primary btn-block shadow-lg\"\n                                        (click)=\"openModal(exportModal)\">Export in Excel\n                                </button>\n                            </div>\n                        </div>\n                    </as-split-area>\n                    <as-split-area [size]=\"30\">\n\n                        <!--                        <button id=\"collapseBtn2\" class=\"collapsible\" (click)=\"collapsePanel('preferenceDiv', 'collapseBtn2')\" style=\"display: inline-block; margin: 0px!important; background-color: #2a6496; color: white;\">Preference Table</button>-->\n                        <button id=\"collapseBtn2\" class=\"collapsible\"\n                                style=\"display: inline-block; margin: 0px!important; background-color: #2a6496; color: white;\">\n                            Preference Table\n                        </button>\n                        <div id=\"preferenceDiv\" class=\"row content\" style=\"padding: .2%; margin: .2%;\">\n                            <table id=\"prefTable\" class=\"table\" (mouseover)=\"resizableGrid('prefTable')\"\n                                   style=\"overflow: hidden; alignment: left; margin-top: .2%; width: 100%;\">\n                                <thead class=\"thead-light\" *ngIf=\"prefService.productPreference !== undefined\">\n                                <tr>\n                                    <th resizable></th>\n                                    <th *ngFor=\"let value of prefService.seg | keyvalue\">{{ value.value }}</th>\n                                </tr>\n                                </thead>\n                                <tbody *ngIf=\"prefService.productPreference === undefined\">\n                                <tr>\n                                    <td></td>\n                                </tr>\n                                <tr>\n                                    <td></td>\n                                </tr>\n                                <tr>\n                                    <td></td>\n                                </tr>\n                                <tr>\n                                    <td></td>\n                                </tr>\n                                </tbody>\n                                <tbody *ngIf=\"prefService.productPreference !== undefined\">\n                                <tr *ngFor=\"let value of prefService.productPreference | keyvalue\">\n                                    <td>{{value.key}}</td>\n                                    <td *ngFor=\"let val of value.value\"> {{ val }}</td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n\n                    </as-split-area>\n                    <as-split-area [size]=\"30\">\n                        <!--                            <button id=\"collapseBtn\" class=\"collapsible\" (click)=\"collapsePanel('productDiv', 'collapseBtn')\" style=\"display: inline-block; margin: 0px!important; background-color: #2a6496; color: white;\">Products</button>-->\n                        <button id=\"collapseBtn\" class=\"collapsible\"\n                                style=\"display: inline-block; margin: 0px!important; background-color: #2a6496; color: white;\">\n                            Products\n                        </button>\n                        <div id=\"productDiv\" class=\"row content\" style=\"padding: .2%; margin: .2%;\">\n                            <table id=\"prodTable\" class=\"table\" (mouseover)=\"resizableGrid('prodTable')\"\n                                   style=\"overflow: hidden; alignment: left; margin-top: .2%; width: 100%;\">\n                                <thead class=\"thead-light\">\n                                <tr>\n                                    <th></th>\n                                    <th *ngFor=\"let att of sceManagementService.selectedScenario.products[0].attribute | keyvalue:returnZero\">{{att.key}}</th>\n                                </tr>\n                                </thead>\n                                <tbody>\n                                <tr *ngFor=\"let product of sceManagementService.selectedScenario.products\">\n                                    <td>{{product.name}}</td>\n                                    <td *ngFor=\"let att of product.attributeValues\">{{att}}</td>\n                                </tr>\n                                </tbody>\n                                <tbody *ngIf=\"sceManagementService.selectedScenario === undefined\">\n                                <tr>\n                                    <td></td>\n                                </tr>\n                                <tr>\n                                    <td></td>\n                                </tr>\n                                <tr>\n                                    <td></td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                        <div class=\"col-2\"></div>\n\n\n                    </as-split-area>\n                </as-split>\n            </as-split-area>\n        </as-split>\n\n\n    </div>\n    <!--    <button class=\"open-button shadow\" (mousedown)=\"showHelpDesk()\">Help Desk</button>-->\n\n    <!--    <div class=\"chat-popup\" id=\"myForm\">-->\n    <!--        <form class=\"form-container\">-->\n    <!--            <h5>Help Desk</h5>-->\n    <!--            <p>Table:</p>-->\n    <!--            <ul>-->\n    <!--                <li>Average preference for products relative to ideal presented in tabular format that can easily be exported or printed.</li>-->\n    <!--                <li>Shows percentage to one decimal.</li>-->\n    <!--            </ul>-->\n    <!--            <button type=\"button\" class=\"btn btn-primary\" (mousedown)=\"showHelpDesk()\">Close</button>-->\n    <!--        </form>-->\n    <!--    </div>-->\n    <!-- Message Modal -->\n    <ng-template #messageModal let-modal>\n        <div class=\"modal-header\">\n            <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\n                <span aria-hidden=\"true\">&times;</span>\n            </button>\n        </div>\n        <div class=\"modal-body\" style=\"padding-left: 10px\">\n            <p>{{exportStatus}}</p>\n        </div>\n    </ng-template>\n    <!-- export Modal -->\n    <ng-template #exportModal let-modal style=\"width: 100vw\">\n        <div class=\"modal-header\">\n            <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\n                <span aria-hidden=\"true\">&times;</span>\n            </button>\n        </div>\n        <div class=\"modal-body\" style=\"padding-left: 10px\">\n            <div class=\"row\" style=\"padding: 5%\">\n\n                    <button class=\"btn btn-sm btn-primary btn-block shadow-lg\"\n                            (click)=\"saveFile(messageModal); modal.dismiss()\" style=\"font-size: .8em\">Append to an existing file</button>\n                    </div>\n            <div class=\"row\" style=\"padding: 5%\">\n                    <button class=\"btn btn-sm btn-primary btn-block shadow-lg\"\n                            (click)=\"exportAsExcelFile(messageModal); modal.dismiss()\" style=\"font-size: .8em\">Save as new file</button>\n\n\n            </div>\n        </div>\n        <div class=\"modal-footer\">\n\n        </div>\n    </ng-template>\n\n    <!-- Product Modal -->\n    <ng-template #productModal let-modal style=\"width: 100vw\">\n        <div class=\"modal-header\">\n            Define Product\n            <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\n                <span aria-hidden=\"true\">&times;</span>\n            </button>\n        </div>\n        <div class=\"modal-body\" style=\"padding-left: 10px\">\n            <div class=\"row\" style=\"padding: 5%\">\n\n                <app-scenario></app-scenario>\n\n            </div>\n        </div>\n        <div class=\"modal-footer\">\n\n        </div>\n    </ng-template>\n\n    <!-- Color Modal -->\n    <ng-template #colorModal let-modal style=\"width: 100vw\">\n        <div class=\"modal-header\">\n            Chart Options\n            <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\n                <span aria-hidden=\"true\">&times;</span>\n            </button>\n        </div>\n        <div class=\"modal-body\" style=\"padding-left: 10px\">\n            <div class=\"form\" style=\"padding: 5%; font-size: .9em\">\n\n                <table width=\"100vw\" style=\"table-layout: auto;display: block;\">\n                    <tbody>\n                    <tr *ngFor=\"let pref of prefService.productPreference | keyvalue:returnZero; let n = index;\">\n                        <td>{{pref.key}}</td>\n                        <td><input (change)=\"setColorPallete(n, $event)\" value=\"{{colorService.color[n]}}\"\n                                   ejs-colorpicker type=\"color\"></td>\n                    </tr>\n                    </tbody>\n                </table>\n                <br>\n                <div class=\"form-group\"><label for=\"title\">Chart title</label><input id=\"title\" style=\"margin-left: .2%\"\n                                                                                     class=\"input-group-sm\" type=\"text\"\n                                                                                     value=\"{{prefService.title}}\"\n                                                                                     (change)=\"setTitle($event)\"></div>\n            </div>\n\n        </div>\n        <div class=\"modal-footer\">\n\n        </div>\n    </ng-template>\n</div>\n"

/***/ }),

/***/ "./src/app/preference/preference/preference.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/preference/preference/preference.component.ts ***!
  \***************************************************************/
/*! exports provided: PreferenceComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreferenceComponent", function() { return PreferenceComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _connection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../connection.service */ "./src/app/connection.service.ts");
/* harmony import */ var ngx_xml2json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-xml2json */ "./node_modules/ngx-xml2json/fesm5/ngx-xml2json.js");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _service_scenario_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../service/scenario.service */ "./src/app/service/scenario.service.ts");
/* harmony import */ var _preference_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../preference.service */ "./src/app/preference/preference.service.ts");
/* harmony import */ var _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../product/productmanagement.service */ "./src/app/product/productmanagement.service.ts");
/* harmony import */ var _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @syncfusion/ej2-angular-charts */ "./node_modules/@syncfusion/ej2-angular-charts/@syncfusion/ej2-angular-charts.es5.js");
/* harmony import */ var _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../scenario/scenariomanagement.service */ "./src/app/scenario/scenariomanagement.service.ts");
/* harmony import */ var _service_chart_color_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../service/chart-color.service */ "./src/app/service/chart-color.service.ts");
/* harmony import */ var _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../service/selected-scenario.service */ "./src/app/service/selected-scenario.service.ts");
/* harmony import */ var exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! exceljs/dist/exceljs.min.js */ "./node_modules/exceljs/dist/exceljs.min.js");
/* harmony import */ var exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! xlsx */ "./node_modules/xlsx/xlsx.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var browser_fs_access__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! browser-fs-access */ "./node_modules/browser-fs-access/dist/index.js");
/* harmony import */ var _core_header_header_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../core/header/header.service */ "./src/app/core/header/header.service.ts");

















var PreferenceComponent = /** @class */ (function () {
    function PreferenceComponent(svc, ngxXml2jsonService, utilityService, colorService, modalService, scenarioService, prefService, prodService, sceManagementService, selectedScenarioService, headerService) {
        var _this = this;
        this.svc = svc;
        this.ngxXml2jsonService = ngxXml2jsonService;
        this.utilityService = utilityService;
        this.colorService = colorService;
        this.modalService = modalService;
        this.scenarioService = scenarioService;
        this.prefService = prefService;
        this.prodService = prodService;
        this.sceManagementService = sceManagementService;
        this.selectedScenarioService = selectedScenarioService;
        this.headerService = headerService;
        this.utilityService.cast.subscribe(function (utility) {
            _this.utility = utility;
            _this.prefService.segment = _this.prodService.segments[0]['cell_1'];
            _this.calculatePreference();
        });
        this.selectedScenarioService.cast.subscribe(function (selectedSce) {
            _this.prefService.prodList = selectedSce.products;
            _this.prodList = selectedSce.products;
            _this.calculatePreference();
        });
        var helpdesk = document.getElementById('myForm');
        if (helpdesk.style.display === 'block') {
            helpdesk.style.display = 'none';
        }
    }
    PreferenceComponent.prototype.ngOnInit = function () {
        this.calculatePreference();
        this.tooltip = { enable: true, header: 'Preference', format: '<b>${point.tooltip}: ${point.y}</b>', position: 'bottom' };
        this.xAxis = {
            valueType: 'Category'
        };
        this.yAxis = {
            minimum: 0,
            maximum: 100,
            interval: 20,
        };
        this.legend = {
            visible: true,
            position: 'Bottom'
        };
    };
    PreferenceComponent.prototype.ngOnChanges = function (changes) {
        this.chart.refresh();
    };
    PreferenceComponent.prototype.ngAfterContentInit = function () {
        //     }
    };
    PreferenceComponent.prototype.returnZero = function () {
        return 0;
    };
    PreferenceComponent.prototype.collapsePanel = function (id, id2) {
        if (document.getElementById(id).style.display === 'none') {
            document.getElementById(id).style.display = 'block';
            document.getElementById(id2).classList.remove('active');
        }
        else {
            document.getElementById(id).style.display = 'none';
            document.getElementById(id2).classList.toggle('active');
        }
    };
    PreferenceComponent.prototype.showHelpDesk = function () {
        var helpdesk = document.getElementById('myForm');
        if (helpdesk.style.display === 'none') {
            helpdesk.style.display = 'block';
        }
        else {
            helpdesk.style.display = 'none';
        }
    };
    PreferenceComponent.prototype.highlightSegment = function (segment) {
        this.prefService.segment = segment;
        this.calculatePreference();
    };
    PreferenceComponent.prototype.calculatePreference = function () {
        var _this = this;
        this.prefService.createSegTable();
        var preference = new Array();
        this.chartData = [];
        this.resetSeries();
        this.prefService.productPreference.forEach(function (value, key) {
            _this.addSeries(value, key);
        });
    };
    PreferenceComponent.prototype.refreshChart = function () {
        this.chart.refresh();
    };
    PreferenceComponent.prototype.addSeries = function (data, sname) {
        var _this = this;
        var chartData = [];
        var i = 0;
        this.prefService.seg.forEach(function (value2, key2) {
            chartData.push({ seg: (value2 + ' (' + _this.prefService.dataCnt.get(i + 1) + ')'), preference: Number(data[i]), text: sname });
            i++;
        });
        if ((this.chart) !== undefined) {
            this.chart.addSeries([{
                    type: 'StackingColumn',
                    dataSource: chartData,
                    xName: 'seg',
                    yName: 'preference',
                    name: sname,
                    tooltipMappingName: 'text'
                }]);
        }
    };
    PreferenceComponent.prototype.resetSeries = function () {
        if ((this.chart) !== undefined) {
            this.chart.series = [];
        }
    };
    PreferenceComponent.prototype.setColorPallete = function (id, event) {
        this.colorService.editColor(id, event.target.value);
    };
    PreferenceComponent.prototype.setTitle = function (event) {
        this.prefService.title = event.target.value;
    };
    PreferenceComponent.prototype.openModal = function (targetModal) {
        this.modalService.open(targetModal, {
            centered: true,
            backdrop: 'static',
            size: 'sm'
        });
    };
    PreferenceComponent.prototype.exportAsExcelFile = function (targetModal) {
        var _this = this;
        var sce = this.sceManagementService.selectedScenario;
        var workbook = new exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_13__["Workbook"]();
        var title = 'SimPRO Price Preference';
        var worksheet = workbook.addWorksheet('Preference relative to others');
        // Add Row and formatting
        // const titleRow = worksheet.addRow([title]);
        // titleRow.font = {name: 'Arial', family: 4, size: 13, underline: 'double', bold: true};
        worksheet.addRow([]);
        worksheet.addRow([this.utility.name]);
        var sceRow = worksheet.addRow([sce.name, sce.savingDate]);
        worksheet.addRow([]);
        sceRow.font = { name: 'Arial' };
        sceRow.alignment = { vertical: 'middle', horizontal: 'left' };
        worksheet.addRow([]);
        // Product table
        var tableRow = worksheet.addRow(['Table of Products']);
        tableRow.font = { bold: true, italic: true };
        tableRow.alignment = { vertical: 'middle', horizontal: 'left' };
        sceRow.font = { name: 'Arial' };
        var header = new Array();
        header.push('Product');
        sce.products[0].attribute.forEach(function (value, key) {
            header.push(key);
        });
        var headRow = worksheet.addRow(header);
        headRow.font = { bold: true };
        headRow.alignment = { vertical: 'middle', horizontal: 'left' };
        var _loop_1 = function (prod) {
            var product = new Array();
            product.push(prod.name);
            prod.attributeValues.forEach(function (value, key) {
                product.push(value);
            });
            var prodRow = worksheet.addRow(product);
            prodRow.alignment = { vertical: 'middle', horizontal: 'left' };
        };
        for (var _i = 0, _a = sce.products; _i < _a.length; _i++) {
            var prod = _a[_i];
            _loop_1(prod);
        }
        worksheet.addRow([]);
        // Preference table
        var simulation = worksheet.addRow(['Simulation']);
        simulation.font = { bold: true, italic: true };
        var prefHeadRow = new Array();
        prefHeadRow.push('Product');
        this.prefService.seg.forEach(function (value, key) {
            prefHeadRow.push(value);
        });
        var prefHead = worksheet.addRow(prefHeadRow);
        prefHead.font = { bold: true };
        prefHead.alignment = { vertical: 'middle', horizontal: 'left' };
        this.prefService.productPreference.forEach(function (value, key) {
            var prefRow = new Array();
            prefRow.push(key);
            for (var _i = 0, value_1 = value; _i < value_1.length; _i++) {
                var i = value_1[_i];
                prefRow.push(i);
            }
            var prefTableRow = worksheet.addRow(prefRow);
            prefTableRow.alignment = { vertical: 'middle', horizontal: 'left' };
        });
        setTimeout(function () {
            // Options are optional.
            var options = {
                // Suggested file name to use, defaults to `''`.
                fileName: 'TMTG_simpro_export.xlsx',
                // Suggested file extensions (with leading '.'), defaults to `''`.
                extensions: ['.xlsx'],
            };
            // console.log(showOpenFilePicker());
            workbook.xlsx.writeBuffer().then(function (data2) {
                var blob = new Blob([data2], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                var opts = {
                    types: [{
                            description: 'Excel File',
                            accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] },
                        }],
                };
                _this.saveAsNewFile(targetModal, blob, options).then(function (z) {
                    console.log(z);
                    _this.exportStatus = 'File successfully exported.';
                    _this.modalService.open(targetModal, {
                        centered: true,
                        backdrop: 'static',
                        size: 'sm'
                    });
                }).catch(function (e) {
                    console.log(e);
                    _this.exportStatus = 'Error! Please make sure file is closed.';
                    _this.modalService.open(targetModal, {
                        centered: true,
                        backdrop: 'static',
                        size: 'sm'
                    });
                });
            });
        }, 1500);
    };
    PreferenceComponent.prototype.saveAsNewFile = function (targetModal, blob, options) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Object(browser_fs_access__WEBPACK_IMPORTED_MODULE_15__["fileSave"])(blob, options)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PreferenceComponent.prototype.saveFile = function (targetModal) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var opts, workbook, fileReader, options2, blob;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        opts = {
                            types: [{
                                    description: 'Excel File',
                                    accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] },
                                }],
                        };
                        workbook = new exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_13__["Workbook"]();
                        fileReader = new FileReader();
                        options2 = {
                            // List of allowed MIME types, defaults to `*/*`.
                            mimeTypes: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
                            // List of allowed file extensions (with leading '.'), defaults to `''`.
                            extensions: ['.xlsx'],
                            // Set to `true` for allowing multiple files, defaults to `false`.
                            multiple: false,
                        };
                        return [4 /*yield*/, Object(browser_fs_access__WEBPACK_IMPORTED_MODULE_15__["fileOpen"])(options2)];
                    case 1:
                        blob = _a.sent();
                        // @ts-ignore
                        fileReader.readAsBinaryString(new Blob([blob], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
                        fileReader.onload = function (z) {
                            var wb = xlsx__WEBPACK_IMPORTED_MODULE_14__["read"](fileReader.result, { type: 'binary' });
                            var sheetNames = wb.SheetNames;
                            // Copy sheets
                            if (sheetNames.indexOf('Preference relative to others') < 0) {
                                workbook.addWorksheet('Preference relative to others');
                            }
                            for (var j in sheetNames) {
                                var workSheet = workbook.addWorksheet(sheetNames[j]);
                                workSheet.addRow([]);
                                // Add utility name
                                var rows = xlsx__WEBPACK_IMPORTED_MODULE_14__["utils"].sheet_to_json(wb.Sheets[sheetNames[j]], { raw: false });
                                workSheet.addRow([Object.keys(rows[0])[0]]);
                                for (var _i = 0, _a = xlsx__WEBPACK_IMPORTED_MODULE_14__["utils"].sheet_to_json(wb.Sheets[sheetNames[j]], { raw: false }); _i < _a.length; _i++) {
                                    var i = _a[_i];
                                    var tempArr = [];
                                    for (var n in i) {
                                        tempArr.push(i[n]);
                                    }
                                    if (tempArr[0] === 'Table of Products' || tempArr[0] === 'Simulation') {
                                        workSheet.addRow([]);
                                        var row = workSheet.addRow(tempArr);
                                        row.font = { bold: true, italic: true };
                                        row.alignment = { vertical: 'middle', horizontal: 'left' };
                                    }
                                    else if (tempArr[0] === 'Product') {
                                        var row = workSheet.addRow(tempArr);
                                        row.font = { bold: true };
                                        row.alignment = { vertical: 'middle', horizontal: 'left' };
                                    }
                                    else {
                                        var row = workSheet.addRow(tempArr);
                                        row.alignment = { vertical: 'middle', horizontal: 'left' };
                                    }
                                }
                            }
                            // @ts-ignore
                            _this.addSheet(workbook.getWorksheet('Preference relative to others'), workbook, blob.handle, targetModal);
                        };
                        return [2 /*return*/];
                }
            });
        });
    };
    PreferenceComponent.prototype.addSheet = function (worksheet, workbook, fileHandle, targetModal) {
        var _this = this;
        var sce = this.sceManagementService.selectedScenario;
        worksheet.addRow([]);
        worksheet.addRow([this.utility.name]);
        var sceRow = worksheet.addRow([sce.name, sce.savingDate]);
        sceRow.font = { name: 'Arial' };
        sceRow.alignment = { vertical: 'middle', horizontal: 'left' };
        worksheet.addRow([]);
        // Product table
        var tableRow = worksheet.addRow(['Table of Products']);
        tableRow.font = { bold: true, italic: true };
        tableRow.alignment = { vertical: 'middle', horizontal: 'left' };
        sceRow.font = { name: 'Arial' };
        var header = new Array();
        header.push('Product');
        sce.products[0].attribute.forEach(function (value, key) {
            header.push(key);
        });
        var headRow = worksheet.addRow(header);
        headRow.font = { bold: true };
        headRow.alignment = { vertical: 'middle', horizontal: 'left' };
        var _loop_2 = function (prod) {
            var product = new Array();
            product.push(prod.name);
            prod.attributeValues.forEach(function (value, key) {
                product.push(value);
            });
            var prodRow = worksheet.addRow(product);
            prodRow.alignment = { vertical: 'middle', horizontal: 'left' };
        };
        for (var _i = 0, _a = sce.products; _i < _a.length; _i++) {
            var prod = _a[_i];
            _loop_2(prod);
        }
        worksheet.addRow([]);
        // Preference table
        var simulation = worksheet.addRow(['Simulation']);
        simulation.font = { bold: true, italic: true };
        var prefHeadRow = new Array();
        prefHeadRow.push('Product');
        this.prefService.seg.forEach(function (value, key) {
            prefHeadRow.push(value);
        });
        var prefHead = worksheet.addRow(prefHeadRow);
        prefHead.font = { bold: true };
        prefHead.alignment = { vertical: 'middle', horizontal: 'left' };
        this.prefService.productPreference.forEach(function (value, key) {
            var prefRow = new Array();
            prefRow.push(key);
            for (var _i = 0, value_2 = value; _i < value_2.length; _i++) {
                var i = value_2[_i];
                prefRow.push(i);
            }
            var prefTableRow = worksheet.addRow(prefRow);
            prefTableRow.alignment = { vertical: 'middle', horizontal: 'left' };
        });
        // Add Image
        // html2canvas(document.querySelector('#chart-div')).then(canvas => {
        //     let image = canvas.toDataURL('image/png', 1.0);
        //     image = image.replace(/^data:image\/(png|jpg);base64,/, '');
        //     const imageId1 = workbook.addImage({
        //         base64: image,
        //         extension: 'png',
        //     });
        //
        //     // worksheet.addImage(imageId1, 'M2:U8');
        // });
        setTimeout(function () {
            workbook.xlsx.writeBuffer().then(function (data2) {
                var blob = new Blob([data2], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                var options = {
                    // Suggested file name to use, defaults to `''`.
                    fileName: 'TMTG_simpro_export.xlsx',
                    // Suggested file extensions (with leading '.'), defaults to `''`.
                    extensions: ['.xlsx'],
                };
                // console.log(targetModal, blob, options)
                // this.saveAsNewFile(targetModal, blob, options)
                _this.writeFile(fileHandle, data2).then(function (z) {
                    console.log(z);
                    _this.exportStatus = 'File successfully exported.';
                    _this.modalService.open(targetModal, {
                        centered: true,
                        backdrop: 'static',
                        size: 'sm'
                    });
                }).catch(function (e) {
                    console.log(e);
                    _this.exportStatus = 'Error! Please make sure file is closed.';
                    _this.modalService.open(targetModal, {
                        centered: true,
                        backdrop: 'static',
                        size: 'sm'
                    });
                });
            });
        }, 1500);
    };
    PreferenceComponent.prototype.writeFile = function (fileHandle, contents) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var writable;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, fileHandle.createWritable()];
                    case 1:
                        writable = _a.sent();
                        // Write the contents of the file to the stream.
                        return [4 /*yield*/, writable.write(contents)];
                    case 2:
                        // Write the contents of the file to the stream.
                        _a.sent();
                        // Close the file and write the contents to disk.
                        return [4 /*yield*/, writable.close()];
                    case 3:
                        // Close the file and write the contents to disk.
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PreferenceComponent.prototype.resizableGrid = function (tableId) {
        var row = document.getElementById(tableId).getElementsByTagName('tr')[0];
        var cols = row ? row.children : undefined;
        if (!cols) {
            return;
        }
        document.getElementById(tableId).style.overflow = 'hidden';
        var tableHeight = document.getElementById(tableId).offsetHeight;
        for (var i = 0; i < cols.length; i++) {
            var div = this.createDiv(tableHeight);
            cols[i].appendChild(div);
            cols[i].style.position = 'relative';
            this.setListeners(div);
        }
    };
    PreferenceComponent.prototype.setListeners = function (div) {
        var _this = this;
        var pageX, curCol, nxtCol, curColWidth, nxtColWidth;
        div.addEventListener('mousedown', function (e) {
            curCol = e.target.parentElement;
            nxtCol = curCol.nextElementSibling;
            pageX = e.pageX;
            var padding = _this.paddingDiff(curCol);
            curColWidth = curCol.offsetWidth - padding;
            if (nxtCol) {
                nxtColWidth = nxtCol.offsetWidth - padding;
            }
        });
        div.addEventListener('mouseover', function (e) {
            e.target.style.borderRight = '2px solid #0000ff';
        });
        div.addEventListener('mouseout', function (e) {
            e.target.style.borderRight = '';
        });
        document.addEventListener('mousemove', function (e) {
            if (curCol) {
                var diffX = e.pageX - pageX;
                if (nxtCol) {
                    nxtCol.style.width = (nxtColWidth - (diffX)) + 'px';
                }
                curCol.style.width = (curColWidth + diffX) + 'px';
            }
        });
        document.addEventListener('mouseup', function (e) {
            curCol = undefined;
            nxtCol = undefined;
            pageX = undefined;
            nxtColWidth = undefined;
            curColWidth = undefined;
        });
    };
    PreferenceComponent.prototype.createDiv = function (height) {
        var div = document.createElement('div');
        div.style.top = '0';
        div.style.right = '0';
        div.style.width = '5px';
        div.style.position = 'absolute';
        div.style.cursor = 'col-resize';
        div.style.userSelect = 'none';
        div.style.height = height + 'px';
        return div;
    };
    PreferenceComponent.prototype.paddingDiff = function (col) {
        if (this.getStyleVal(col, 'box-sizing') === 'border-box') {
            return 0;
        }
        var padLeft = this.getStyleVal(col, 'padding-left');
        var padRight = this.getStyleVal(col, 'padding-right');
        // tslint:disable-next-line:radix
        return (parseInt(padLeft) + parseInt(padRight));
    };
    PreferenceComponent.prototype.getStyleVal = function (elm, css) {
        return (window.getComputedStyle(elm, null).getPropertyValue(css));
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('chart'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_9__["ChartComponent"])
    ], PreferenceComponent.prototype, "chart", void 0);
    PreferenceComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-preference',
            template: __webpack_require__(/*! ./preference.component.html */ "./src/app/preference/preference/preference.component.html"),
            styles: [__webpack_require__(/*! ./preference.component.css */ "./src/app/preference/preference/preference.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_connection_service__WEBPACK_IMPORTED_MODULE_2__["ConnectionService"],
            ngx_xml2json__WEBPACK_IMPORTED_MODULE_3__["NgxXml2jsonService"],
            _service_utility_service__WEBPACK_IMPORTED_MODULE_4__["UtilityService"],
            _service_chart_color_service__WEBPACK_IMPORTED_MODULE_11__["ChartColorService"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModal"],
            _service_scenario_service__WEBPACK_IMPORTED_MODULE_6__["ScenarioService"],
            _preference_service__WEBPACK_IMPORTED_MODULE_7__["PreferenceService"],
            _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_8__["ProductmanagementService"],
            _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_10__["ScenariomanagementService"],
            _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_12__["SelectedScenarioService"],
            _core_header_header_service__WEBPACK_IMPORTED_MODULE_16__["HeaderService"]])
    ], PreferenceComponent);
    return PreferenceComponent;
}());



/***/ }),

/***/ "./src/app/product/productmanagement.service.ts":
/*!******************************************************!*\
  !*** ./src/app/product/productmanagement.service.ts ***!
  \******************************************************/
/*! exports provided: ProductmanagementService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductmanagementService", function() { return ProductmanagementService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var _service_product_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/product.service */ "./src/app/service/product.service.ts");
/* harmony import */ var _service_scenario_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../service/scenario.service */ "./src/app/service/scenario.service.ts");
/* harmony import */ var _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../scenario/scenariomanagement.service */ "./src/app/scenario/scenariomanagement.service.ts");
/* harmony import */ var _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../service/selected-scenario.service */ "./src/app/service/selected-scenario.service.ts");
/* harmony import */ var _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../utility/utilitymanagement.service */ "./src/app/utility/utilitymanagement.service.ts");








var ProductmanagementService = /** @class */ (function () {
    function ProductmanagementService(utilityService, productService, scenarioService, selectedScenarioService, sceManagementService, utlManagementSvc) {
        var _this = this;
        this.utilityService = utilityService;
        this.productService = productService;
        this.scenarioService = scenarioService;
        this.selectedScenarioService = selectedScenarioService;
        this.sceManagementService = sceManagementService;
        this.utlManagementSvc = utlManagementSvc;
        this.weight = new Map();
        this.productHeaderAtt = new Map();
        this.productAtt = [];
        this.productAtt2 = [];
        this.productAttVal = [];
        this.segments = []; // dropdown
        this.segmentLevels = [];
        this.segmentPositions = [];
        this.values = new Map();
        this.products = []; // For defined products
        this.utilityService.cast.subscribe(function (utility) { return _this.utility = utility; });
        this.scenarioService.scenarios$.subscribe(function (scenarios) { return _this.scenarioList = scenarios; });
    }
    ProductmanagementService.prototype.ngOnChanges = function () {
        var _this = this;
        this.utilityService.cast.subscribe(function (utility) { return _this.utility = utility; });
    };
    ProductmanagementService.prototype.convertToJson = function () {
        // tslint:disable-next-line:one-variable-per-declaration
        var temp2, temp, val, val2, cnt = 0;
        var cell0 = 'cell_0';
        this.productAtt = [];
        this.productAtt2 = [];
        this.segments = [];
        this.segmentPositions = [];
        for (var _i = 0, _a = Object.keys(this.utility.utl_xml); _i < _a.length; _i++) {
            var field = _a[_i];
            temp = (this.utility.utl_xml[field]);
            cnt = 0;
            for (var _b = 0, _c = Object.keys(temp); _b < _c.length; _b++) {
                val = _c[_b];
                temp2 = temp[val];
                for (var _d = 0, _e = Object.keys(temp[val]); _d < _e.length; _d++) {
                    val2 = _e[_d];
                    if (temp2[val2][cell0] === '1') {
                        this.segments.push(temp2[val2]);
                        this.segmentPositions.push(cnt + 1);
                    }
                    else if (temp2[val2][cell0] === '4') {
                        this.productAtt.push(temp2[val2]);
                    }
                    else if (temp2[val2][cell0] === '5') {
                        this.productAtt2.push(temp2[val2]);
                    }
                    else if (temp2[val2][cell0] === '2' && this.tuneId != 0) {
                        // this is weight
                        this.tuneId = cnt;
                    }
                    else if (temp2[val2][cell0] === '3' && this.weightId != 0) {
                        // this is tune
                        this.weightId = cnt;
                    }
                    cnt++;
                }
            }
        }
        this.productAttVal = this.utility.utl_val;
        this.segmentLevels = [];
        for (var i in this.segments) {
            cnt = 0;
            temp = [];
            // while (this.segments[i]['cell_3_' + cnt] || index < Object.entries(this.segments[i]).length - 2 / 2) {
            for (var n in this.segments[i]) {
                if (this.segments[i]['cell_3_' + cnt]) {
                    temp.push(this.segments[i]['cell_3_' + (cnt)]);
                }
                cnt++;
            }
            this.segmentLevels.push(temp);
        }
    };
    /**
     * Get attributes from utility file
     */
    ProductmanagementService.prototype.getAttributes = function () {
        var count2 = 0;
        var cnt = 0;
        var temp = [];
        var cell2 = 'cell_2';
        var cell1 = 'cell_1';
        var products = [];
        this.products = [];
        this.productHeaderAtt = new Map();
        for (var i = 0; i < this.productAtt.length; i++) {
            if (count2 === 0) {
                temp[count2++] = this.productAtt[i][cell2];
                products[cnt++] = this.productAtt[i][cell2];
            }
            else if (this.productAtt[i - 1][cell1] === this.productAtt[i][cell1]) {
                temp[count2++] = this.productAtt[i][cell2];
            }
            else if (this.productAtt[i - 1][cell1] !== this.productAtt[i][cell1]) {
                count2 = 0;
                this.productHeaderAtt.set(this.productAtt[i - 1][cell1], temp);
                if (JSON.stringify(this.productAtt[i][cell1]) === JSON.stringify('NONE') || JSON.stringify(this.productAtt[i][cell1]) === JSON.stringify('None')) {
                    this.noneCol = i;
                }
                else if (JSON.stringify(this.productAtt[i][cell1]) !== JSON.stringify('NONE') || JSON.stringify(this.productAtt[i][cell1]) !== JSON.stringify('None')) {
                    products[cnt++] = this.productAtt[i][cell2];
                }
                temp = []; // Clean temp storage
                temp[count2++] = this.productAtt[i][cell2];
            }
        }
        // Check product header att and product values
        // update product service
        this.productService.addNewProduct('Product 1', this.productHeaderAtt, products);
        this.setScenario();
    };
    /**
     * Set initial scenario
    * */
    ProductmanagementService.prototype.setScenario = function () {
        var _this = this;
        var prodList = [];
        this.productService.products$.subscribe(function (productList) { return prodList = productList; });
        this.baseProduct = Object.assign({}, prodList[0]);
        this.scenarioService.resetScenario();
        this.scenarioService.addScenarios('Scenario', prodList);
        setTimeout(function () { _this.selectedScenarioService.editScenario(_this.scenarioList[0]); }, 1000);
        this.sceManagementService.setSelectedScenario(this.scenarioList[0]);
    };
    ProductmanagementService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_service_utility_service__WEBPACK_IMPORTED_MODULE_2__["UtilityService"], _service_product_service__WEBPACK_IMPORTED_MODULE_3__["ProductService"],
            _service_scenario_service__WEBPACK_IMPORTED_MODULE_4__["ScenarioService"],
            _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_6__["SelectedScenarioService"],
            _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_5__["ScenariomanagementService"],
            _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_7__["UtilitymanagementService"]])
    ], ProductmanagementService);
    return ProductmanagementService;
}());



/***/ }),

/***/ "./src/app/resizable/resizable.component.css":
/*!***************************************************!*\
  !*** ./src/app/resizable/resizable.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host:last-child .bar {\r\n    display: none;\r\n}\r\n.wrapper {\r\n    display: -webkit-box;\r\n    display: flex;\r\n    -webkit-box-pack: end;\r\n            justify-content: flex-end;\r\n}\r\n.content {\r\n    -webkit-box-flex: 1;\r\n            flex: 1;\r\n}\r\n.bar {\r\n    position: absolute;\r\n    top: 0;\r\n    bottom: 0;\r\n    width: 2px;\r\n    margin: 0 -16px 0 16px;\r\n    justify-self: flex-end;\r\n    border-left: 2px solid transparent;\r\n    border-right: 2px solid transparent;\r\n    background: blueviolet;\r\n    background-clip: content-box;\r\n    cursor: ew-resize;\r\n    opacity: 0;\r\n    -webkit-transition: opacity .3s;\r\n    transition: opacity .3s;\r\n}\r\n.bar:hover, .bar:active {\r\n    opacity: 1;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVzaXphYmxlL3Jlc2l6YWJsZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksYUFBYTtBQUNqQjtBQUNBO0lBQ0ksb0JBQWE7SUFBYixhQUFhO0lBQ2IscUJBQXlCO1lBQXpCLHlCQUF5QjtBQUM3QjtBQUNBO0lBQ0ksbUJBQU87WUFBUCxPQUFPO0FBQ1g7QUFDQTtJQUNJLGtCQUFrQjtJQUNsQixNQUFNO0lBQ04sU0FBUztJQUNULFVBQVU7SUFDVixzQkFBc0I7SUFDdEIsc0JBQXNCO0lBQ3RCLGtDQUFrQztJQUNsQyxtQ0FBbUM7SUFDbkMsc0JBQXNCO0lBQ3RCLDRCQUE0QjtJQUM1QixpQkFBaUI7SUFDakIsVUFBVTtJQUNWLCtCQUF1QjtJQUF2Qix1QkFBdUI7QUFDM0I7QUFDQTtJQUNJLFVBQVU7QUFDZCIsImZpbGUiOiJzcmMvYXBwL3Jlc2l6YWJsZS9yZXNpemFibGUuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0Omxhc3QtY2hpbGQgLmJhciB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG59XHJcbi53cmFwcGVyIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xyXG59XHJcbi5jb250ZW50IHtcclxuICAgIGZsZXg6IDE7XHJcbn1cclxuLmJhciB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICB3aWR0aDogMnB4O1xyXG4gICAgbWFyZ2luOiAwIC0xNnB4IDAgMTZweDtcclxuICAgIGp1c3RpZnktc2VsZjogZmxleC1lbmQ7XHJcbiAgICBib3JkZXItbGVmdDogMnB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gICAgYm9yZGVyLXJpZ2h0OiAycHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgICBiYWNrZ3JvdW5kOiBibHVldmlvbGV0O1xyXG4gICAgYmFja2dyb3VuZC1jbGlwOiBjb250ZW50LWJveDtcclxuICAgIGN1cnNvcjogZXctcmVzaXplO1xyXG4gICAgb3BhY2l0eTogMDtcclxuICAgIHRyYW5zaXRpb246IG9wYWNpdHkgLjNzO1xyXG59XHJcbi5iYXI6aG92ZXIsIC5iYXI6YWN0aXZlIHtcclxuICAgIG9wYWNpdHk6IDE7XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/resizable/resizable.component.html":
/*!****************************************************!*\
  !*** ./src/app/resizable/resizable.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"wrapper\">\n  <div class=\"content\">\n    <ng-content></ng-content>\n  </div>\n  <div class=\"bar\" (resizable)=\"onResize($event)\"></div>\n</div>\n"

/***/ }),

/***/ "./src/app/resizable/resizable.component.ts":
/*!**************************************************!*\
  !*** ./src/app/resizable/resizable.component.ts ***!
  \**************************************************/
/*! exports provided: ResizableComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResizableComponent", function() { return ResizableComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ResizableComponent = /** @class */ (function () {
    function ResizableComponent() {
        this.width = null;
    }
    ResizableComponent.prototype.onResize = function (width) {
        this.width = width;
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostBinding"])('style.width.px'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], ResizableComponent.prototype, "width", void 0);
    ResizableComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'th[resizable]',
            template: __webpack_require__(/*! ./resizable.component.html */ "./src/app/resizable/resizable.component.html"),
            styles: [__webpack_require__(/*! ./resizable.component.css */ "./src/app/resizable/resizable.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ResizableComponent);
    return ResizableComponent;
}());



/***/ }),

/***/ "./src/app/resizable/resizable.directive.ts":
/*!**************************************************!*\
  !*** ./src/app/resizable/resizable.directive.ts ***!
  \**************************************************/
/*! exports provided: ResizableDirective */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResizableDirective", function() { return ResizableDirective; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");





var ResizableDirective = /** @class */ (function () {
    function ResizableDirective(documentRef, elementRef) {
        var _this = this;
        this.documentRef = documentRef;
        this.elementRef = elementRef;
        this.resizable = Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["fromEvent"])(this.elementRef.nativeElement, 'mousedown').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function (e) { return e.preventDefault(); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["switchMap"])(function () {
            var _a = _this.elementRef.nativeElement
                .closest('th')
                .getBoundingClientRect(), width = _a.width, right = _a.right;
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["fromEvent"])(_this.documentRef, 'mousemove').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(function (_a) {
                var clientX = _a.clientX;
                return width + clientX - right;
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["distinctUntilChanged"])(), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(Object(rxjs__WEBPACK_IMPORTED_MODULE_4__["fromEvent"])(_this.documentRef, 'mouseup')));
        }));
    }
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ResizableDirective.prototype, "resizable", void 0);
    ResizableDirective = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Directive"])({
            selector: '[resizable]',
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_1__["DOCUMENT"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ElementRef"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Document,
            _angular_core__WEBPACK_IMPORTED_MODULE_2__["ElementRef"]])
    ], ResizableDirective);
    return ResizableDirective;
}());



/***/ }),

/***/ "./src/app/resizable/resizable.module.ts":
/*!***********************************************!*\
  !*** ./src/app/resizable/resizable.module.ts ***!
  \***********************************************/
/*! exports provided: ResizableModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResizableModule", function() { return ResizableModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _resizable_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./resizable.component */ "./src/app/resizable/resizable.component.ts");
/* harmony import */ var _resizable_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./resizable.directive */ "./src/app/resizable/resizable.directive.ts");





var ResizableModule = /** @class */ (function () {
    function ResizableModule() {
    }
    ResizableModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_resizable_component__WEBPACK_IMPORTED_MODULE_3__["ResizableComponent"], _resizable_directive__WEBPACK_IMPORTED_MODULE_4__["ResizableDirective"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]
            ],
            exports: [_resizable_component__WEBPACK_IMPORTED_MODULE_3__["ResizableComponent"]]
        })
    ], ResizableModule);
    return ResizableModule;
}());



/***/ }),

/***/ "./src/app/scenario/scenario.module.ts":
/*!*********************************************!*\
  !*** ./src/app/scenario/scenario.module.ts ***!
  \*********************************************/
/*! exports provided: ScenarioModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScenarioModule", function() { return ScenarioModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _scenario_scenario_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./scenario/scenario.component */ "./src/app/scenario/scenario/scenario.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _syncfusion_ej2_base__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @syncfusion/ej2-base */ "./node_modules/@syncfusion/ej2-base/index.js");







Object(_syncfusion_ej2_base__WEBPACK_IMPORTED_MODULE_6__["enableRipple"])(true);
var ScenarioModule = /** @class */ (function () {
    function ScenarioModule() {
    }
    ScenarioModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_scenario_scenario_component__WEBPACK_IMPORTED_MODULE_3__["ScenarioComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"]
            ],
            exports: [
                _scenario_scenario_component__WEBPACK_IMPORTED_MODULE_3__["ScenarioComponent"]
            ]
        })
    ], ScenarioModule);
    return ScenarioModule;
}());



/***/ }),

/***/ "./src/app/scenario/scenario/scenario.component.css":
/*!**********************************************************!*\
  !*** ./src/app/scenario/scenario/scenario.component.css ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/* You can add global styles to this file, and also import other style files */\r\n\r\n\r\n.btn-blk {\r\n    background-color: #4b4b4b;\r\n    border-color: #4b4b4b;\r\n    color: #F0F0F0;\r\n}\r\n\r\n\r\n/*.wrapper {*/\r\n\r\n\r\n/*    display: flex;*/\r\n\r\n\r\n/*    width: 100%;*/\r\n\r\n\r\n/*}*/\r\n\r\n\r\n.main-header {\r\n    width: 100%;\r\n    display: -webkit-box;\r\n    display: flex;\r\n    /*position: fixed;*/\r\n    z-index: 2;\r\n}\r\n\r\n\r\n.header {\r\n    width: 100vw;\r\n    position: fixed;\r\n}\r\n\r\n\r\n.navbar {\r\n    z-index: 2;\r\n}\r\n\r\n\r\n.main{\r\n    margin-left: 2%;\r\n    padding: 0px 0px;\r\n    z-index: -1;\r\n    /*padding-top: 20vh;*/\r\n}\r\n\r\n\r\n#sidebar {\r\n    height: 100%;\r\n    width: 18%;\r\n    position: fixed;\r\n    z-index: 1;\r\n    margin-top: 10vh;\r\n    /*background: #0075BE;*/\r\n    background: #FFFFFF;\r\n    color: #0075BE;\r\n    -webkit-transition: all 0.3s;\r\n    transition: all 0.3s;\r\n}\r\n\r\n\r\n@media (max-width: 768px) {\r\n    #sidebar {\r\n        margin-left: -250px;\r\n    }\r\n    #sidebar.active {\r\n        margin-left: 0;\r\n    }\r\n\r\n    html {\r\n        font-size: 14px;\r\n    }\r\n}\r\n\r\n\r\nbody {\r\n    font-family: 'Poppins', sans-serif;\r\n    background: #fafafa;\r\n}\r\n\r\n\r\np {\r\n    font-family: 'Poppins', sans-serif;\r\n    font-size: 1.1em;\r\n    font-weight: 300;\r\n    line-height: 1.7em;\r\n    color: #000;\r\n}\r\n\r\n\r\na, a:hover, a:focus {\r\n    color: inherit;\r\n    text-decoration: none;\r\n    -webkit-transition: all 0.3s;\r\n    transition: all 0.3s;\r\n}\r\n\r\n\r\n#sidebar .sidebar-header {\r\n    padding-left: 20px;\r\n    padding-top: 20px;\r\n    background:  #F0F0F0;\r\n\r\n}\r\n\r\n\r\n#sidebar ul.components {\r\n    /*padding: 20px 20px;*/\r\n    border-bottom: 1px solid #47748b;\r\n    text-align: -webkit-left;\r\n\r\n    /*padding: 5%;*/\r\n}\r\n\r\n\r\n#sidebar ul p {\r\n    color: #fff;\r\n    padding: 10px;\r\n}\r\n\r\n\r\n#sidebar ul li a {\r\n    padding: 10px;\r\n    font-size: 1.1em;\r\n    display: block;\r\n}\r\n\r\n\r\n#sidebar ul li a:hover {\r\n    color: #7386D5;\r\n    background: #fff;\r\n}\r\n\r\n\r\n#sidebar ul li.active > a, a[aria-expanded=\"true\"] {\r\n    color: #fff;\r\n    background: #0075BE;\r\n}\r\n\r\n\r\nul ul a {\r\n    font-size: 0.9em !important;\r\n    padding-left: 30px !important;\r\n    background: #6d7fcc;\r\n}\r\n\r\n\r\nh1,h2,h3,h5,h6,p {\r\n    font-family: Lato, sans-serif;\r\n}\r\n\r\n\r\nnav {\r\n    display: -webkit-box;\r\n    display: flex;\r\n    justify-content: space-around;\r\n    font-size: 1em;\r\n    z-index: 2;\r\n}\r\n\r\n\r\n.btn-blk {\r\n    background-color: #4b4b4b;\r\n    border-color: #4b4b4b;\r\n    color: #F0F0F0;\r\n}\r\n\r\n\r\n.btn-primary {\r\n    background-color: #2a6496;\r\n    border-color: #2a6496;\r\n}\r\n\r\n\r\n/*.col-form-label-sm {*/\r\n\r\n\r\n/*    color: #000000;*/\r\n\r\n\r\n/*}\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000*/\r\n\r\n\r\n:host:last-child .bar {\r\n    display: none;\r\n}\r\n\r\n\r\n.wrapper {\r\n    display: -webkit-box;\r\n    display: flex;\r\n    -webkit-box-pack: end;\r\n            justify-content: flex-end;\r\n}\r\n\r\n\r\n.content {\r\n    -webkit-box-flex: 1;\r\n            flex: 1;\r\n}\r\n\r\n\r\n.bar {\r\n    position: absolute;\r\n    top: 0;\r\n    bottom: 0;\r\n    width: 2px;\r\n    margin: 0 -16px 0 16px;\r\n    justify-self: flex-end;\r\n    border-left: 2px solid transparent;\r\n    border-right: 2px solid transparent;\r\n    background: blueviolet;\r\n    background-clip: content-box;\r\n    cursor: ew-resize;\r\n    opacity: 0;\r\n    -webkit-transition: opacity .3s;\r\n    transition: opacity .3s;\r\n}\r\n\r\n\r\n.bar:hover, .bar:active {\r\n    opacity: 1;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2NlbmFyaW8vc2NlbmFyaW8vc2NlbmFyaW8uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSw4RUFBOEU7OztBQUc5RTtJQUNJLHlCQUF5QjtJQUN6QixxQkFBcUI7SUFDckIsY0FBYztBQUNsQjs7O0FBTUEsYUFBYTs7O0FBQ2IscUJBQXFCOzs7QUFDckIsbUJBQW1COzs7QUFDbkIsSUFBSTs7O0FBQ0o7SUFDSSxXQUFXO0lBQ1gsb0JBQWE7SUFBYixhQUFhO0lBQ2IsbUJBQW1CO0lBQ25CLFVBQVU7QUFDZDs7O0FBQ0E7SUFDSSxZQUFZO0lBQ1osZUFBZTtBQUNuQjs7O0FBQ0E7SUFDSSxVQUFVO0FBQ2Q7OztBQUNBO0lBQ0ksZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixXQUFXO0lBQ1gscUJBQXFCO0FBQ3pCOzs7QUFDQTtJQUNJLFlBQVk7SUFDWixVQUFVO0lBQ1YsZUFBZTtJQUNmLFVBQVU7SUFDVixnQkFBZ0I7SUFDaEIsdUJBQXVCO0lBQ3ZCLG1CQUFtQjtJQUNuQixjQUFjO0lBQ2QsNEJBQW9CO0lBQXBCLG9CQUFvQjtBQUN4Qjs7O0FBRUE7SUFDSTtRQUNJLG1CQUFtQjtJQUN2QjtJQUNBO1FBQ0ksY0FBYztJQUNsQjs7SUFFQTtRQUNJLGVBQWU7SUFDbkI7QUFDSjs7O0FBS0E7SUFDSSxrQ0FBa0M7SUFDbEMsbUJBQW1CO0FBQ3ZCOzs7QUFFQTtJQUNJLGtDQUFrQztJQUNsQyxnQkFBZ0I7SUFDaEIsZ0JBQWdCO0lBQ2hCLGtCQUFrQjtJQUNsQixXQUFXO0FBQ2Y7OztBQUVBO0lBQ0ksY0FBYztJQUNkLHFCQUFxQjtJQUNyQiw0QkFBb0I7SUFBcEIsb0JBQW9CO0FBQ3hCOzs7QUFHQTtJQUNJLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsb0JBQW9COztBQUV4Qjs7O0FBRUE7SUFDSSxzQkFBc0I7SUFDdEIsZ0NBQWdDO0lBQ2hDLHdCQUF3Qjs7SUFFeEIsZUFBZTtBQUNuQjs7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsYUFBYTtBQUNqQjs7O0FBRUE7SUFDSSxhQUFhO0lBQ2IsZ0JBQWdCO0lBQ2hCLGNBQWM7QUFDbEI7OztBQUNBO0lBQ0ksY0FBYztJQUNkLGdCQUFnQjtBQUNwQjs7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsbUJBQW1CO0FBQ3ZCOzs7QUFDQTtJQUNJLDJCQUEyQjtJQUMzQiw2QkFBNkI7SUFDN0IsbUJBQW1CO0FBQ3ZCOzs7QUFFQTtJQUNJLDZCQUE2QjtBQUNqQzs7O0FBR0E7SUFDSSxvQkFBYTtJQUFiLGFBQWE7SUFDYiw2QkFBNkI7SUFDN0IsY0FBYztJQUNkLFVBQVU7QUFDZDs7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIscUJBQXFCO0lBQ3JCLGNBQWM7QUFDbEI7OztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLHFCQUFxQjtBQUN6Qjs7O0FBR0EsdUJBQXVCOzs7QUFDdkIsc0JBQXNCOzs7QUFDdEIsd0ZBQXdGOzs7QUFHeEY7SUFDSSxhQUFhO0FBQ2pCOzs7QUFDQTtJQUNJLG9CQUFhO0lBQWIsYUFBYTtJQUNiLHFCQUF5QjtZQUF6Qix5QkFBeUI7QUFDN0I7OztBQUNBO0lBQ0ksbUJBQU87WUFBUCxPQUFPO0FBQ1g7OztBQUNBO0lBQ0ksa0JBQWtCO0lBQ2xCLE1BQU07SUFDTixTQUFTO0lBQ1QsVUFBVTtJQUNWLHNCQUFzQjtJQUN0QixzQkFBc0I7SUFDdEIsa0NBQWtDO0lBQ2xDLG1DQUFtQztJQUNuQyxzQkFBc0I7SUFDdEIsNEJBQTRCO0lBQzVCLGlCQUFpQjtJQUNqQixVQUFVO0lBQ1YsK0JBQXVCO0lBQXZCLHVCQUF1QjtBQUMzQjs7O0FBQ0E7SUFDSSxVQUFVO0FBQ2QiLCJmaWxlIjoic3JjL2FwcC9zY2VuYXJpby9zY2VuYXJpby9zY2VuYXJpby5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLyogWW91IGNhbiBhZGQgZ2xvYmFsIHN0eWxlcyB0byB0aGlzIGZpbGUsIGFuZCBhbHNvIGltcG9ydCBvdGhlciBzdHlsZSBmaWxlcyAqL1xyXG5cclxuXHJcbi5idG4tYmxrIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM0YjRiNGI7XHJcbiAgICBib3JkZXItY29sb3I6ICM0YjRiNGI7XHJcbiAgICBjb2xvcjogI0YwRjBGMDtcclxufVxyXG5cclxuXHJcblxyXG5cclxuXHJcbi8qLndyYXBwZXIgeyovXHJcbi8qICAgIGRpc3BsYXk6IGZsZXg7Ki9cclxuLyogICAgd2lkdGg6IDEwMCU7Ki9cclxuLyp9Ki9cclxuLm1haW4taGVhZGVyIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIC8qcG9zaXRpb246IGZpeGVkOyovXHJcbiAgICB6LWluZGV4OiAyO1xyXG59XHJcbi5oZWFkZXIge1xyXG4gICAgd2lkdGg6IDEwMHZ3O1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG59XHJcbi5uYXZiYXIge1xyXG4gICAgei1pbmRleDogMjtcclxufVxyXG4ubWFpbntcclxuICAgIG1hcmdpbi1sZWZ0OiAyJTtcclxuICAgIHBhZGRpbmc6IDBweCAwcHg7XHJcbiAgICB6LWluZGV4OiAtMTtcclxuICAgIC8qcGFkZGluZy10b3A6IDIwdmg7Ki9cclxufVxyXG4jc2lkZWJhciB7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICB3aWR0aDogMTglO1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgei1pbmRleDogMTtcclxuICAgIG1hcmdpbi10b3A6IDEwdmg7XHJcbiAgICAvKmJhY2tncm91bmQ6ICMwMDc1QkU7Ki9cclxuICAgIGJhY2tncm91bmQ6ICNGRkZGRkY7XHJcbiAgICBjb2xvcjogIzAwNzVCRTtcclxuICAgIHRyYW5zaXRpb246IGFsbCAwLjNzO1xyXG59XHJcblxyXG5AbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgICNzaWRlYmFyIHtcclxuICAgICAgICBtYXJnaW4tbGVmdDogLTI1MHB4O1xyXG4gICAgfVxyXG4gICAgI3NpZGViYXIuYWN0aXZlIHtcclxuICAgICAgICBtYXJnaW4tbGVmdDogMDtcclxuICAgIH1cclxuXHJcbiAgICBodG1sIHtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG5cclxuXHJcbmJvZHkge1xyXG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgIGJhY2tncm91bmQ6ICNmYWZhZmE7XHJcbn1cclxuXHJcbnAge1xyXG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtc2l6ZTogMS4xZW07XHJcbiAgICBmb250LXdlaWdodDogMzAwO1xyXG4gICAgbGluZS1oZWlnaHQ6IDEuN2VtO1xyXG4gICAgY29sb3I6ICMwMDA7XHJcbn1cclxuXHJcbmEsIGE6aG92ZXIsIGE6Zm9jdXMge1xyXG4gICAgY29sb3I6IGluaGVyaXQ7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4zcztcclxufVxyXG5cclxuXHJcbiNzaWRlYmFyIC5zaWRlYmFyLWhlYWRlciB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDIwcHg7XHJcbiAgICBwYWRkaW5nLXRvcDogMjBweDtcclxuICAgIGJhY2tncm91bmQ6ICAjRjBGMEYwO1xyXG5cclxufVxyXG5cclxuI3NpZGViYXIgdWwuY29tcG9uZW50cyB7XHJcbiAgICAvKnBhZGRpbmc6IDIwcHggMjBweDsqL1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICM0Nzc0OGI7XHJcbiAgICB0ZXh0LWFsaWduOiAtd2Via2l0LWxlZnQ7XHJcblxyXG4gICAgLypwYWRkaW5nOiA1JTsqL1xyXG59XHJcblxyXG4jc2lkZWJhciB1bCBwIHtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgcGFkZGluZzogMTBweDtcclxufVxyXG5cclxuI3NpZGViYXIgdWwgbGkgYSB7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgZm9udC1zaXplOiAxLjFlbTtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcbiNzaWRlYmFyIHVsIGxpIGE6aG92ZXIge1xyXG4gICAgY29sb3I6ICM3Mzg2RDU7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG59XHJcblxyXG4jc2lkZWJhciB1bCBsaS5hY3RpdmUgPiBhLCBhW2FyaWEtZXhwYW5kZWQ9XCJ0cnVlXCJdIHtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgYmFja2dyb3VuZDogIzAwNzVCRTtcclxufVxyXG51bCB1bCBhIHtcclxuICAgIGZvbnQtc2l6ZTogMC45ZW0gIWltcG9ydGFudDtcclxuICAgIHBhZGRpbmctbGVmdDogMzBweCAhaW1wb3J0YW50O1xyXG4gICAgYmFja2dyb3VuZDogIzZkN2ZjYztcclxufVxyXG5cclxuaDEsaDIsaDMsaDUsaDYscCB7XHJcbiAgICBmb250LWZhbWlseTogTGF0bywgc2Fucy1zZXJpZjtcclxufVxyXG5cclxuXHJcbm5hdiB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxuICAgIHotaW5kZXg6IDI7XHJcbn1cclxuXHJcbi5idG4tYmxrIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM0YjRiNGI7XHJcbiAgICBib3JkZXItY29sb3I6ICM0YjRiNGI7XHJcbiAgICBjb2xvcjogI0YwRjBGMDtcclxufVxyXG5cclxuLmJ0bi1wcmltYXJ5IHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMyYTY0OTY7XHJcbiAgICBib3JkZXItY29sb3I6ICMyYTY0OTY7XHJcbn1cclxuXHJcblxyXG4vKi5jb2wtZm9ybS1sYWJlbC1zbSB7Ki9cclxuLyogICAgY29sb3I6ICMwMDAwMDA7Ki9cclxuLyp9XHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwXHUwMDAwKi9cclxuXHJcblxyXG46aG9zdDpsYXN0LWNoaWxkIC5iYXIge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxufVxyXG4ud3JhcHBlciB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcclxufVxyXG4uY29udGVudCB7XHJcbiAgICBmbGV4OiAxO1xyXG59XHJcbi5iYXIge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgYm90dG9tOiAwO1xyXG4gICAgd2lkdGg6IDJweDtcclxuICAgIG1hcmdpbjogMCAtMTZweCAwIDE2cHg7XHJcbiAgICBqdXN0aWZ5LXNlbGY6IGZsZXgtZW5kO1xyXG4gICAgYm9yZGVyLWxlZnQ6IDJweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICAgIGJvcmRlci1yaWdodDogMnB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gICAgYmFja2dyb3VuZDogYmx1ZXZpb2xldDtcclxuICAgIGJhY2tncm91bmQtY2xpcDogY29udGVudC1ib3g7XHJcbiAgICBjdXJzb3I6IGV3LXJlc2l6ZTtcclxuICAgIG9wYWNpdHk6IDA7XHJcbiAgICB0cmFuc2l0aW9uOiBvcGFjaXR5IC4zcztcclxufVxyXG4uYmFyOmhvdmVyLCAuYmFyOmFjdGl2ZSB7XHJcbiAgICBvcGFjaXR5OiAxO1xyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/scenario/scenario/scenario.component.html":
/*!***********************************************************!*\
  !*** ./src/app/scenario/scenario/scenario.component.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!doctype html>\n<html lang=\"en\">\n<head>\n    <title> SimPRO Define Product </title>\n    <script src=\"scenario.component.ts\"></script>\n    <!--    <meta charset=\"utf-8\">-->\n    <!--    <title>Simpro</title>-->\n    <!--    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">-->\n    <!--    <base href=\"/\">-->\n    <!--    <link rel=\"icon\" type=\"image/x-icon\" href=\"favicon.ico\">-->\n    <!--    <link rel=\"stylesheet\" href=\"./scenario.component.css\">-->\n    <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css\"\n          integrity=\"sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm\" crossorigin=\"anonymous\">\n    <!-- Add icon library -->\n    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">\n    <!--    <link href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\" rel=\"stylesheet\">-->\n    <!--    <link href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js\" integrity=\"sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM\" crossorigin=\"anonymous\"></link>-->\n    <!--    &lt;!&ndash;   <script src=\"https://code.jquery.com/jquery-3.4.1.min.js\"     integrity=\"sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=\"      crossorigin=\"anonymous\"></script>&ndash;&gt;-->\n\n\n    <!--    &lt;!&ndash; Essential Studio for JavaScript  theme reference &ndash;&gt;-->\n    <!--    <link href=\"http://cdn.syncfusion.com/18.2.0.44/js/web/flat-azure/ej.web.all.min.css\" rel=\"stylesheet\" />-->\n\n    <!--    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">-->\n    <style>\n        /*table {*/\n        /*    width: 100%;*/\n        /*    font: 14px Verdana;*/\n        /*}*/\n\n        /*table, th, td {*/\n        /*    border: solid 1px #999999;*/\n        /*    border-collapse: collapse;*/\n        /*    padding: 2px 3px;*/\n        /*    text-align: center;*/\n        /*    font-family: Lato, sans-serif;*/\n        /*}*/\n\n        table { width: 100%; table-layout: fixed; oveflow: auto!important }\n        th { padding: 5px!important;}\n        td { white-space: nowrap;\n            overflow: auto;\n            text-overflow: ellipsis;\n            font-size: .9em;\n            padding: 5px!important;\n            width: 100vw;\n        }\n        th {\n            font-weight: bold;\n        }\n\n        table tr.highlight {\n            background-color: #4b4b4b !important;\n            color: #ffffff;\n        }\n\n\n    </style>\n\n\n</head>\n<body>\n<div class=\"main \">\n\n    <div class=\"container-fluid\">\n        <br/>\n        <h5>{{utility.fileName}}</h5>\n        <hr>\n        <div class=\"row\">\n            <div class=\"col-2\">\n                <button class=\"btn btn-sm btn-blk\"\n                        style=\"background-color: #4b4b4b; border-color: #4b4b4b; color: #F0F0F0;margin: 5px;  color: #FFFFFF; width: 90%; font-size: 11px\"\n                        (click)=\"saveScenario()\">Save Scenario\n                </button>\n            </div>\n            <div class=\"col-2\">\n                <label class=\"btn btn-sm btn-blk\" style=\"background-color: #4b4b4b; border-color: #4b4b4b; color: #F0F0F0;margin: 5px;  color: #FFFFFF; width: 90%; font-size: 11px\"> Upload Scenario\n                <input #fileUpload id=\"scenarioLoad\" class=\"btn btn-sm btn-blk\" type=\"file\" hidden multiple (change)=\"parseScenarioFile($event)\" value=\"Upload Scenario\" content=\"Upload Scenario\"/>\n                </label>\n            </div>\n\n            <div class=\"col-2\">\n                <button class=\"btn btn-sm btn-blk\"\n                        style=\"background-color: #4b4b4b; border-color: #4b4b4b; color: #F0F0F0;margin: 5px;  color: #FFFFFF; width: 90%; font-size: 11px\"\n                        (click)=\"addScenario()\">Add Scenario\n                </button>\n\n            </div>\n\n            <div class=\"col-2\">\n                <button class=\"btn btn-sm btn-blk\"\n                        style=\"background-color: #4b4b4b; border-color: #4b4b4b; color: #F0F0F0;margin: 5px;  color: #FFFFFF; width: 90%; font-size: 11px\"\n                        (click)=\"duplicateScenario()\">Duplicate Scenario\n                </button>\n            </div>\n\n        </div>\n        <div class=\"row\" style=\"padding-left: 20px\"><span style=\"color: darkred; font-size: .9em\">{{scenarioMessage}}</span></div>\n\n        <div class=\"row\" style=\"padding-left: 20px; padding-right: 20px; \">\n\n            <h6>Scenario list</h6>\n            <table id=\"scenarioTable\" class=\"table table-bordered ed\" style=\" font-size: 12px; align: center; table-layout: fixed; \">\n                <thead>\n                <tr>\n                    <th resizable style=\"padding: 5px!important;\">Scenario Name</th>\n                    <th resizable style=\"padding: 5px!important;\">Modified Date</th>\n                    <th resizable style=\"padding: 5px!important;\">Delete</th>\n                </tr>\n                </thead>\n                <tbody>\n                <tr *ngFor=\"let scenario of scenarioService.scenarios$ | async\"\n                    (click)=\"highlightScenario(scenario.id)\"\n                    [ngStyle]=\"{'background-color': scenario.id == selectedScenario.id ? '#ddd': '#ffffff', 'color': '#4b4b4b'}\">\n                    <td style=\"padding: 5px!important;\"><input style=\"border: none !important; background-color: transparent; width: 100%!important\" (change)=\"updateScenarioComment(scenario.id, $event)\" value=\"{{scenario.name}}\"/></td>\n                    <td style=\"padding: 5px!important;\">{{scenario.creationDate | date:'longDate'}}</td>\n                    <td style=\"padding: 5px!important;\"><i class=\"fa fa-trash\" (click)=\"deleteScenario()\"></i></td>\n                </tr>\n                </tbody>\n            </table>\n\n        </div>\n\n        <div class=\"row\" style=\"padding-left: 20px\"><span style=\"color: darkred; font-size: .9em\">{{productMessage}}</span></div>\n        <div class=\"row\" style=\"padding-left: 20px; padding-right: 20px; overflow: auto!important\" *ngIf=\"productList != null\">\n            <h6>{{selectedScenario.name}} Product List</h6><br>\n            <table id=\"prodTable\" class=\"table table-bordered ed\" style=\"font-size: .8em; margin-bottom: 0px!important; alignment: left; overflow: auto!important\">\n                <thead>\n                <tr>\n                    <th >Product</th>\n                    <th  *ngFor=\"let att of productList[0].attribute | keyvalue:returnZero\">{{att.key}}</th>\n                    <th >Chart color</th>\n                    <th >Delete</th>\n                </tr>\n                </thead>\n                <tbody id=\"prodTableBody\">\n                <tr *ngFor=\"let product of productList; let n = index\">\n                    <td style=\"padding: 5px!important;white-space: nowrap!important; overflow: hidden!important;\"><input type=\"text\" style=\"border: none!important; width: 100%\" (keydown.enter)=\"updateProductName(n, $event); $event.target.blur()\" (change)=\"updateProductName(n, $event)\" value=\"{{product.name}}\"/></td>\n                    <td *ngFor=\"let options of product.attribute | keyvalue:returnZero; let i = index;\" style=\"padding: 2px!important;white-space: nowrap!important;overflow: hidden!important;\">\n                        <select *ngIf=\"!isInterpolable(i)\" (keydown.enter)=\"updateProductValue(n, i, $event); $event.target.blur()\" (change)=\"updateProductValue(n, i, $event)\" style=\"border: none!important; width: 100%; padding: 0px!important\">\n                            <option *ngFor=\"let x of options.value | keyvalue\"\n                                    [selected]=\"x.value == product.attributeValues[i]\">{{x.value}}</option>\n                        </select>\n                        <div *ngIf=\"isInterpolable(i)\">\n                            <input type=\"text\" (keydown.enter)=\"updateProductValue(n, i, $event); $event.target.blur()\" (change)=\"updateProductValue(n, i, $event)\" list=\"att\" value=\"{{product.attributeValues[i]}}\" style=\"border: none!important; position:relative; width: 80%; padding: 0px!important\"/>\n                                <select id=\"att\"  (keydown.enter)=\"updateProductValue(n, i, $event); $event.target.blur()\" (change)=\"updateProductValue(n, i, $event)\" style=\"border: none!important; max-width:20px; padding: 0px!important\">\n                                    <option></option>\n                                    <option *ngFor=\"let x of options.value | keyvalue\">{{x.value}}</option>\n                                </select>\n\n                        </div>\n\n                    </td>\n                    <td style=\"padding: 5px!important;\">\n                        <input ejs-colorpicker  type=\"color\"\n                               (change)=\"sceManagementService.setColorPallete(n, $event)\" value=\"{{colorList[n]}}\"/></td>\n                    <td style=\"padding: 5px!important;\"><i class=\"fa fa-trash\" (click)=\"deleteProduct(n)\"></i></td>\n                </tr>\n                </tbody>\n            </table>\n\n        </div>\n        <div class=\"row\">\n            <div class=\"col-2\">\n                <button class=\"btn btn-sm btn-blk\"\n                    style=\"margin: 5px; color: #FFFFFF; width: 100%; align: left; background-color: #4b4b4b; border-color: #4b4b4b; \"\n                    (click)=\"addProduct()\">Add product\n                </button>\n            </div>\n            <div class=\"col-2\">\n<!--                <button class=\"btn btn-sm btn-blk\"-->\n<!--                        style=\"margin: 5px; color: #FFFFFF; width: 100%; align: left; background-color: #4b4b4b; border-color: #4b4b4b; \"-->\n<!--                        (click)=\"updateValues()\">Update values-->\n<!--                </button>-->\n            </div>\n        </div>\n    </div>\n</div>\n</body>\n</html>\n"

/***/ }),

/***/ "./src/app/scenario/scenario/scenario.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/scenario/scenario/scenario.component.ts ***!
  \*********************************************************/
/*! exports provided: ScenarioComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScenarioComponent", function() { return ScenarioComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _models_Scenario__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../models/Scenario */ "./src/app/models/Scenario.ts");
/* harmony import */ var _models_Product__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../models/Product */ "./src/app/models/Product.ts");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var _service_scenario_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../service/scenario.service */ "./src/app/service/scenario.service.ts");
/* harmony import */ var _service_product_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../service/product.service */ "./src/app/service/product.service.ts");
/* harmony import */ var _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../product/productmanagement.service */ "./src/app/product/productmanagement.service.ts");
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! file-saver */ "./node_modules/file-saver/dist/FileSaver.min.js");
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var xml2js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! xml2js */ "./node_modules/xml2js/lib/xml2js.js");
/* harmony import */ var xml2js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(xml2js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _scenariomanagement_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../scenariomanagement.service */ "./src/app/scenario/scenariomanagement.service.ts");
/* harmony import */ var _service_chart_color_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../service/chart-color.service */ "./src/app/service/chart-color.service.ts");
/* harmony import */ var _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../service/selected-scenario.service */ "./src/app/service/selected-scenario.service.ts");
/* harmony import */ var _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../utility/utilitymanagement.service */ "./src/app/utility/utilitymanagement.service.ts");
/* harmony import */ var browser_fs_access__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! browser-fs-access */ "./node_modules/browser-fs-access/dist/index.js");

















var ScenarioComponent = /** @class */ (function () {
    function ScenarioComponent(fb, modalService, utilityService, scenarioService, productService, prodService, sceManagementService, colorService, selectedScenarioService, utilManagementService, componentFactoryResolver, compiler, m) {
        var _this = this;
        this.fb = fb;
        this.modalService = modalService;
        this.utilityService = utilityService;
        this.scenarioService = scenarioService;
        this.productService = productService;
        this.prodService = prodService;
        this.sceManagementService = sceManagementService;
        this.colorService = colorService;
        this.selectedScenarioService = selectedScenarioService;
        this.utilManagementService = utilManagementService;
        this.componentFactoryResolver = componentFactoryResolver;
        this.compiler = compiler;
        this.m = m;
        this.utilityService.cast.subscribe(function (utility) { return _this.utility = utility; });
        this.subscription = this.scenarioService.scenarios$.subscribe(function (scenarios) { return _this.scenarioList = scenarios; });
        this.productService.products$.subscribe(function (productList) { return _this.productList = productList; });
        this.colorService.color$.subscribe(function (clr) { return _this.colorList = clr; });
        this.editScenarioForm = this.fb.group({
            scenario_name: [''],
            scenario_comment: ['']
        });
        this.scenarioService.scenarios$.subscribe(function (scenarios) { return _this.scenarioList = scenarios; });
        this.selectedScenarioService.cast.subscribe(function (sce) {
            _this.selectedScenario = sce;
            _this.productList = sce.products;
        });
    }
    ScenarioComponent.prototype.ngOnInit = function () {
        // this.selectedScenario = this.sceManagementService.selectedScenario;
    };
    ScenarioComponent.prototype.ngAfterViewInit = function () {
    };
    ScenarioComponent.prototype.ngAfterContentInit = function () {
    };
    ScenarioComponent.prototype.highlightScenario = function (scenario) {
        this.scenarioMessage = '';
        var currentSce = this.scenarioList.find(function (sce) { return sce.id === scenario; });
        this.selectedScenarioService.editScenario(currentSce);
        this.selectedScenario = currentSce;
        this.productList = [];
        this.productList = currentSce.products;
    };
    ScenarioComponent.prototype.isInterpolable = function (index) {
        return this.utilManagementService.productSensitivityIds.has(index);
    };
    ScenarioComponent.prototype.returnZero = function () {
        return 0;
    };
    ScenarioComponent.prototype.addScenario = function () {
        this.scenarioMessage = '';
        try {
            this.scenarioService.addScenarios('Scenario_' + (this.scenarioList.length + 1), [this.productList[0]]);
            this.scenarioMessage = 'Successfully added scenario!';
        }
        catch (e) {
            this.scenarioMessage = 'Error adding scenario!';
        }
    };
    ScenarioComponent.prototype.duplicateScenario = function () {
        this.scenarioMessage = '';
        if (this.selectedScenario !== undefined) {
            this.scenarioService.duplicateScenario(this.selectedScenario.id, this.selectedScenario.name);
            this.message = 'Scenario duplicated successfully!';
        }
        else {
            this.message = 'No scenario selected!';
        }
    };
    ScenarioComponent.prototype.deleteScenario = function () {
        this.scenarioMessage = '';
        if (this.selectedScenario !== undefined && this.scenarioList.length > 1) {
            this.scenarioService.removeScenario(this.selectedScenario.id);
            this.highlightScenario(this.scenarioList[0].id);
            this.scenarioMessage = 'Successfully deleted scenario!';
        }
        else if (this.scenarioList.length === 1) {
            this.scenarioMessage = 'Cannot delete scenario!';
        }
        else {
            this.scenarioMessage = 'No scenario selected!';
        }
    };
    ScenarioComponent.prototype.updateValues = function () {
        this.selectedScenarioService.editScenario(this.selectedScenario);
    };
    ScenarioComponent.prototype.saveScenario = function () {
        var xmlDoc = document.implementation.createDocument('', '', null);
        var scenariosElem = xmlDoc.createElement('scenarios');
        scenariosElem.setAttribute('utility-name', this.utility.name);
        scenariosElem.setAttribute('Software', 'simPRO - The Marketech Group');
        var scenarioElem = xmlDoc.createElement('scenario');
        scenarioElem.setAttribute('name', this.selectedScenario.name);
        scenariosElem.appendChild(scenarioElem);
        var datesElem = xmlDoc.createElement('dates');
        scenarioElem.appendChild(datesElem);
        var productsElem = xmlDoc.createElement('products');
        var _loop_1 = function (n) {
            var productElem = xmlDoc.createElement('product');
            productElem.setAttribute('name', this_1.selectedScenario.products[n].name);
            scenarioElem.appendChild(productsElem);
            productsElem.appendChild(productElem);
            var attributesElem = xmlDoc.createElement('attributes');
            productElem.appendChild(attributesElem);
            var att = new Array();
            this_1.selectedScenario.products[n].attribute.forEach(function (value, key) {
                att.push(key);
            });
            for (var m = 0; m < this_1.selectedScenario.products[n].attribute.size; m++) {
                var attributeElem = xmlDoc.createElement('attribute');
                attributeElem.setAttribute('name', att[m]);
                attributeElem.setAttribute('value', this_1.selectedScenario.products[n].attributeValues[m]);
                attributesElem.appendChild(attributeElem);
            }
        };
        var this_1 = this;
        for (var n = 0; n < this.selectedScenario.products.length; n++) {
            _loop_1(n);
        }
        xmlDoc.appendChild(scenariosElem);
        var serializer = new XMLSerializer();
        var xmlStr = serializer.serializeToString(xmlDoc);
        var options = {
            // Suggested file name to use, defaults to `''`.
            fileName: 'Scenario.txt',
            // Suggested file extensions (with leading '.'), defaults to `''`.
            extensions: ['.txt'],
        };
        this.saveAsNewFile(new Blob([xmlStr]), options).then(function (e) {
            console.log(e);
        }).catch(function (x) {
            Object(file_saver__WEBPACK_IMPORTED_MODULE_10__["saveAs"])(new Blob([xmlStr]), 'scenarios.scn');
        });
    };
    ScenarioComponent.prototype.saveAsNewFile = function (blob, options) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Object(browser_fs_access__WEBPACK_IMPORTED_MODULE_16__["fileSave"])(blob, options)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    ScenarioComponent.prototype.parseScenarioFile = function (event) {
        var _this = this;
        this.file = event.target.files[0];
        var fileReader = new FileReader();
        var newScenario = new _models_Scenario__WEBPACK_IMPORTED_MODULE_4__["Scenario"]();
        try {
            fileReader.onload = function (e) {
                xml2js__WEBPACK_IMPORTED_MODULE_11___default.a.parseString(fileReader.result, { explicitArray: false }, function (error, result) {
                    // if same utility name
                    newScenario.name = result.scenarios.scenario.$.name;
                    // Check if scenario name has no duplicate
                    if ((_this.scenarioList.filter(function (scenario) { return scenario.name === newScenario.name; })).length === 0) {
                        newScenario.savingDate = new Date();
                        newScenario.creationDate = new Date();
                        var data = result.scenarios.scenario.products;
                        var newProdList = new Array();
                        var _loop_2 = function (i) {
                            if (data[i].length !== undefined) {
                                var _loop_3 = function (n) {
                                    var newProd = new _models_Product__WEBPACK_IMPORTED_MODULE_5__["Product"]();
                                    newProd.name = data[i][n].$.name;
                                    var tempAttribute = new Array();
                                    data[i][n].attributes.attribute.forEach(function (value, key) {
                                        tempAttribute.push(value.$.value);
                                    });
                                    newProd.attributeValues = tempAttribute;
                                    newProd.attribute = _this.productList[0].attribute;
                                    newProdList = newProdList.concat([newProd]);
                                };
                                for (var n in data[i]) {
                                    _loop_3(n);
                                }
                            }
                            else {
                                var newProd = new _models_Product__WEBPACK_IMPORTED_MODULE_5__["Product"]();
                                newProd.name = data[i].$.name;
                                var tempAttribute_1 = new Array();
                                data[i].attributes.attribute.forEach(function (value, key) {
                                    tempAttribute_1.push(value.$.value);
                                });
                                newProd.attributeValues = tempAttribute_1;
                                newProd.attribute = _this.productList[0].attribute;
                                newProdList = newProdList.concat([newProd]);
                            }
                        };
                        for (var i in data) {
                            _loop_2(i);
                        }
                        newScenario.products = newProdList;
                        _this.scenarioService.addScenarios(result.scenarios.scenario.$.name, newProdList);
                        _this.scenarioMessage = 'Scenario successfully added!';
                    }
                    else {
                        _this.scenarioMessage = 'Error! Please check scenario name!';
                    }
                });
            };
        }
        catch (e) {
            this.scenarioMessage = 'Error! Please check file.';
        }
        this.fileUploadVariable.nativeElement.value = '';
        fileReader.readAsText(this.file);
    };
    ScenarioComponent.prototype.updateScenarioComment = function (scenarioId, event) {
        this.scenarioMessage = '';
        try {
            this.selectedScenario.name = event.target.value;
            this.selectedScenarioService.editScenario(this.selectedScenario);
            this.scenarioService.editScenario(scenarioId, event.target.value, '');
        }
        catch (e) {
            this.message = 'Error updating scenario.';
        }
    };
    ScenarioComponent.prototype.ngOnChanges = function () {
        var _this = this;
        this.utilityService.cast.subscribe(function (utility) { return _this.utility = utility; });
        this.productList = this.sceManagementService.selectedScenario.products;
    };
    ScenarioComponent.prototype.addProduct = function () {
        var _this = this;
        this.scenarioMessage = '';
        this.productMessage = '';
        try {
            var prodList = Object.assign([{}], this.productList);
            var product = Object.assign({}, this.prodService.baseProduct);
            product.id = this.productList.length + 1;
            product.name = 'Product ' + product.id;
            prodList = prodList.concat([product]);
            this.scenarioService.updateProduct(this.selectedScenario.name, prodList);
            this.productList = Object.assign([{}], prodList);
            this.sceManagementService.selectedScenario = this.scenarioService.scenarios.find(function (sce) { return sce.name === _this.selectedScenario.name; });
            this.selectedScenarioService.editScenario(this.scenarioService.scenarios.find(function (sce) { return sce.name === _this.selectedScenario.name; }));
            this.productMessage = 'Added product successfully!';
        }
        catch (e) {
            this.productMessage = 'Error adding product!';
        }
    };
    ScenarioComponent.prototype.deleteProduct = function (i) {
        var _this = this;
        this.scenarioMessage = '';
        this.productMessage = '';
        try {
            this.productList.splice(i, 1);
            this.scenarioService.updateProduct(this.selectedScenario.name, this.productList);
            this.selectedScenarioService.editScenario(this.scenarioService.scenarios.find(function (sce) { return sce.name === _this.selectedScenario.name; }));
            this.productMessage = 'Deleted product successfully!';
        }
        catch (e) {
            this.productMessage = 'Error deleting product !';
        }
    };
    ScenarioComponent.prototype.update = function () {
        parent.postMessage('Yes', location.origin);
        window.close();
    };
    ScenarioComponent.prototype.updateProductValue = function (n, i, event) {
        var _this = this;
        this.productMessage = '';
        var attributeValues = Object.assign([{}], this.productList[n].attributeValues);
        var index = 0;
        this.productList[n].attribute.forEach(function (value, key) {
            if (value.indexOf(event.target.value) !== -1) {
                attributeValues[index] = event.target.value;
            }
            else if (!isNaN(Number(value[0])) && !isNaN(Number(event.target.value))) {
                // Checker if interpolable value is within range
                if (Number(event.target.value) >= Number(value[0]) && Number(event.target.value) <= Number(value[Object.entries(value).length - 1])) {
                    _this.productMessage = '';
                    attributeValues[index] = event.target.value;
                }
                else {
                    _this.productMessage = 'Error! Please enter a value within range.';
                }
            }
            index++;
        });
        this.productList[n].attributeValues = attributeValues;
        this.selectedScenario.products = this.productList;
        this.scenarioService.updateProduct(this.selectedScenario.name, this.productList);
        this.selectedScenarioService.editScenario(this.selectedScenario);
    };
    ScenarioComponent.prototype.updateProductName = function (n, event) {
        this.productMessage = '';
        this.productList[n].name = event.target.value;
        this.scenarioService.updateProduct(this.selectedScenario.name, this.productList);
        this.selectedScenarioService.editScenario(this.selectedScenario);
    };
    /**
     * Load one scenario
     */
    ScenarioComponent.prototype.loadScenario = function () {
        var _this = this;
        var input = document.createElement('input');
        input.type = 'file';
        input.onchange = (function (e) {
            var file = e.target.files[0];
            // setting up the reader
            var reader = new FileReader();
            reader.readAsText(file, 'UTF-8');
            // display after reading file
            reader.onload = (function (readerEvent) {
                // const content = (readerEvent.target).result;
                var content = reader.result;
                xml2js__WEBPACK_IMPORTED_MODULE_11___default.a.parseString(content, { explicitArray: false }, function (error, result) {
                    if (error) {
                        throw new Error(error);
                    }
                    else {
                        var res = result;
                        _this.scenario = new _models_Scenario__WEBPACK_IMPORTED_MODULE_4__["Scenario"]();
                        _this.scenario.name = Object.values(Object.values(res.scenarios.scenario)[0]).toString();
                        _this.scenario.creationDate = new Date();
                        _this.scenario.description = 'Sample comment';
                        _this.scenarioService.addScenarios(Object.values(Object.values(res.scenarios.scenario)[0]).toString(), _this.productList);
                    }
                });
            });
        });
        input.click();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('myPar'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], ScenarioComponent.prototype, "myPar", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('first'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], ScenarioComponent.prototype, "first", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('second'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], ScenarioComponent.prototype, "second", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('fileUpload'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], ScenarioComponent.prototype, "fileUploadVariable", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('vc', { read: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"] }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], ScenarioComponent.prototype, "_container", void 0);
    ScenarioComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-scenario',
            template: __webpack_require__(/*! ./scenario.component.html */ "./src/app/scenario/scenario/scenario.component.html"),
            styles: [__webpack_require__(/*! ./scenario.component.css */ "./src/app/scenario/scenario/scenario.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_3__["NgbModal"],
            _service_utility_service__WEBPACK_IMPORTED_MODULE_6__["UtilityService"],
            _service_scenario_service__WEBPACK_IMPORTED_MODULE_7__["ScenarioService"],
            _service_product_service__WEBPACK_IMPORTED_MODULE_8__["ProductService"],
            _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_9__["ProductmanagementService"],
            _scenariomanagement_service__WEBPACK_IMPORTED_MODULE_12__["ScenariomanagementService"],
            _service_chart_color_service__WEBPACK_IMPORTED_MODULE_13__["ChartColorService"],
            _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_14__["SelectedScenarioService"],
            _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_15__["UtilitymanagementService"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["ComponentFactoryResolver"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["Compiler"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModuleRef"]])
    ], ScenarioComponent);
    return ScenarioComponent;
}());



/***/ }),

/***/ "./src/app/scenario/scenariomanagement.service.ts":
/*!********************************************************!*\
  !*** ./src/app/scenario/scenariomanagement.service.ts ***!
  \********************************************************/
/*! exports provided: ScenariomanagementService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScenariomanagementService", function() { return ScenariomanagementService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var _service_scenario_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/scenario.service */ "./src/app/service/scenario.service.ts");
/* harmony import */ var _service_product_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../service/product.service */ "./src/app/service/product.service.ts");
/* harmony import */ var _service_chart_color_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../service/chart-color.service */ "./src/app/service/chart-color.service.ts");
/* harmony import */ var _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../service/selected-scenario.service */ "./src/app/service/selected-scenario.service.ts");







var ScenariomanagementService = /** @class */ (function () {
    function ScenariomanagementService(utilityService, scenarioService, colorService, selectedScenarioService, productService) {
        var _this = this;
        this.utilityService = utilityService;
        this.scenarioService = scenarioService;
        this.colorService = colorService;
        this.selectedScenarioService = selectedScenarioService;
        this.productService = productService;
        this.defineProduct = false;
        this.cValue = 'red';
        // this.utilityService.cast.subscribe(utility => this.utility = utility);
        this.subscription = this.scenarioService.scenarios$.subscribe(function (scenarios) { return _this.scenarioList = scenarios; });
        this.defineProduct = false;
        this.colorService.setColors(['#007bff', '#AA1636', '#45aeca', '#E94649', '#F6B53F', '#6FAAB0', '#C4C24A']);
        this.selectedScenarioService.cast.subscribe(function (sce) { return _this.selectedScenario = sce; });
        // this.palette = ['#007bff', '#AA1636', '#45aeca', '#E94649', '#F6B53F', '#6FAAB0', '#C4C24A'];
        // for (const color of this.palette) {
        //   this.colorService.addColor(color);
        // }
        // // this.productService.products$.subscribe(productList => this.productList = productList);
    }
    ScenariomanagementService.prototype.setSelectedScenario = function (sce) {
        this.selectedScenario = sce;
    };
    ScenariomanagementService.prototype.setColorPallete = function (id, event) {
        // this.palette[id] = event.target.value;
        this.colorService.editColor(id, event.target.value);
    };
    ScenariomanagementService.prototype.resizableGrid = function (cnt) {
        // console.log(table);
        var row = document.getElementsByTagName('table')[cnt].getElementsByTagName('tr')[0];
        var cols = row ? row.children : undefined;
        if (!cols)
            return;
        document.getElementsByTagName('table')[cnt].style.overflow = 'hidden';
        var tableHeight = document.getElementsByTagName('table')[cnt].offsetHeight;
        for (var i = 0; i < cols.length; i++) {
            var div = this.createDiv(tableHeight);
            cols[i].appendChild(div);
            cols[i].style.position = 'relative';
            this.setListeners(div);
        }
    };
    ScenariomanagementService.prototype.setListeners = function (div) {
        var _this = this;
        var pageX, curCol, nxtCol, curColWidth, nxtColWidth;
        div.addEventListener('mousedown', function (e) {
            curCol = e.target.parentElement;
            nxtCol = curCol.nextElementSibling;
            pageX = e.pageX;
            var padding = _this.paddingDiff(curCol);
            curColWidth = curCol.offsetWidth - padding;
            if (nxtCol) {
                nxtColWidth = nxtCol.offsetWidth - padding;
            }
        });
        div.addEventListener('mouseover', function (e) {
            e.target.style.borderRight = '2px solid #0000ff';
        });
        div.addEventListener('mouseout', function (e) {
            e.target.style.borderRight = '';
        });
        document.addEventListener('mousemove', function (e) {
            if (curCol) {
                var diffX = e.pageX - pageX;
                if (nxtCol) {
                    nxtCol.style.width = (nxtColWidth - (diffX)) + 'px';
                }
                curCol.style.width = (curColWidth + diffX) + 'px';
            }
        });
        document.addEventListener('mouseup', function (e) {
            curCol = undefined;
            nxtCol = undefined;
            pageX = undefined;
            nxtColWidth = undefined;
            curColWidth = undefined;
        });
    };
    ScenariomanagementService.prototype.createDiv = function (height) {
        var div = document.createElement('div');
        div.style.top = '0';
        div.style.right = '0';
        div.style.width = '5px';
        div.style.position = 'absolute';
        div.style.cursor = 'col-resize';
        div.style.userSelect = 'none';
        div.style.height = height + 'px';
        return div;
    };
    ScenariomanagementService.prototype.paddingDiff = function (col) {
        if (this.getStyleVal(col, 'box-sizing') === 'border-box') {
            return 0;
        }
        var padLeft = this.getStyleVal(col, 'padding-left');
        var padRight = this.getStyleVal(col, 'padding-right');
        // tslint:disable-next-line:radix
        return (parseInt(padLeft) + parseInt(padRight));
    };
    ScenariomanagementService.prototype.getStyleVal = function (elm, css) {
        return (window.getComputedStyle(elm, null).getPropertyValue(css));
    };
    ScenariomanagementService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_service_utility_service__WEBPACK_IMPORTED_MODULE_2__["UtilityService"],
            _service_scenario_service__WEBPACK_IMPORTED_MODULE_3__["ScenarioService"],
            _service_chart_color_service__WEBPACK_IMPORTED_MODULE_5__["ChartColorService"],
            _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_6__["SelectedScenarioService"],
            _service_product_service__WEBPACK_IMPORTED_MODULE_4__["ProductService"]])
    ], ScenariomanagementService);
    return ScenariomanagementService;
}());



/***/ }),

/***/ "./src/app/sensitivity/sensitivity.module.ts":
/*!***************************************************!*\
  !*** ./src/app/sensitivity/sensitivity.module.ts ***!
  \***************************************************/
/*! exports provided: SensitivityModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SensitivityModule", function() { return SensitivityModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _sensitivity_sensitivity_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sensitivity/sensitivity.component */ "./src/app/sensitivity/sensitivity/sensitivity.component.ts");
/* harmony import */ var _scenario_scenario_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../scenario/scenario.module */ "./src/app/scenario/scenario.module.ts");
/* harmony import */ var _utility_utility_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utility/utility.module */ "./src/app/utility/utility.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @syncfusion/ej2-angular-charts */ "./node_modules/@syncfusion/ej2-angular-charts/@syncfusion/ej2-angular-charts.es5.js");
/* harmony import */ var _resizable_resizable_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../resizable/resizable.module */ "./src/app/resizable/resizable.module.ts");
/* harmony import */ var angular_split__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! angular-split */ "./node_modules/angular-split/fesm5/angular-split.js");











var SensitivityModule = /** @class */ (function () {
    function SensitivityModule() {
    }
    SensitivityModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_sensitivity_sensitivity_component__WEBPACK_IMPORTED_MODULE_3__["SensitivityComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _scenario_scenario_module__WEBPACK_IMPORTED_MODULE_4__["ScenarioModule"],
                _utility_utility_module__WEBPACK_IMPORTED_MODULE_5__["UtilityModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["ChartModule"],
                _resizable_resizable_module__WEBPACK_IMPORTED_MODULE_8__["ResizableModule"],
                angular_split__WEBPACK_IMPORTED_MODULE_9__["AngularSplitModule"]
            ],
            exports: [
                _sensitivity_sensitivity_component__WEBPACK_IMPORTED_MODULE_3__["SensitivityComponent"]
            ],
            providers: [
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["BarSeriesService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["ColumnSeriesService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["CategoryService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["StackingColumnSeriesService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["DateTimeService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["ScrollBarService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["LineSeriesService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["StackingLineSeriesService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["ZoomService"],
                _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["LegendService"], _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_7__["TooltipService"]
            ]
        })
    ], SensitivityModule);
    return SensitivityModule;
}());



/***/ }),

/***/ "./src/app/sensitivity/sensitivity.service.ts":
/*!****************************************************!*\
  !*** ./src/app/sensitivity/sensitivity.service.ts ***!
  \****************************************************/
/*! exports provided: SensitivityService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SensitivityService", function() { return SensitivityService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utility/utilitymanagement.service */ "./src/app/utility/utilitymanagement.service.ts");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _preference_preference_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../preference/preference.service */ "./src/app/preference/preference.service.ts");
/* harmony import */ var _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../product/productmanagement.service */ "./src/app/product/productmanagement.service.ts");
/* harmony import */ var _core_header_header_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../core/header/header.service */ "./src/app/core/header/header.service.ts");








var SensitivityService = /** @class */ (function () {
    function SensitivityService(utilManagementService, utilityService, preferenceService, prodManagementService, headerService) {
        this.utilManagementService = utilManagementService;
        this.utilityService = utilityService;
        this.preferenceService = preferenceService;
        this.prodManagementService = prodManagementService;
        this.headerService = headerService;
    }
    SensitivityService.prototype.ngOnInit = function () {
        this.selectedPriceAtt = Number(this.utilManagementService.priceAtt);
    };
    SensitivityService.prototype.ngOnChanges = function () {
    };
    SensitivityService.prototype.getPriceSensiIndex = function () {
        var sensibilityIndex = '';
        if (!Object(util__WEBPACK_IMPORTED_MODULE_4__["isUndefined"])(this.utilManagementService.priceSensiAtt[0])) {
            for (var i in this.utilManagementService.priceSensiAtt) {
                if (this.utilManagementService.priceSensiAtt[i] === this.utilManagementService.productSet[this.utilManagementService.priceAtt]) {
                    sensibilityIndex = this.utilManagementService.productSet[this.utilManagementService.priceAtt];
                }
            }
        }
        return sensibilityIndex;
    };
    SensitivityService.prototype.selectSegmentLevel = function (level, segment) {
        var segmentPositions = [];
        var selectedLevel = 0;
        this.selectedLevel = level;
        // Get segment positions
        for (var i = 0; i < this.prodManagementService.segments.length; i++) {
            if (this.prodManagementService.segments[i]['cell_1'] === segment) {
                segmentPositions = this.utilManagementService.getSegmentValues(this.prodManagementService.segmentPositions[i]);
                // Get levelId
                var cnt = 0;
                for (var n in this.prodManagementService.segments[i]) {
                    if (String(this.prodManagementService.segments[i]['cell_3_' + cnt]) === String(level)) {
                        selectedLevel = cnt;
                    }
                    cnt++;
                }
            }
        }
        this.getRelativeTotalByLevel(segmentPositions, selectedLevel);
    };
    SensitivityService.prototype.calculateSensitivity = function () {
        if (this.headerService.priceMin < this.headerService.priceMax && this.headerService.increment > 0) {
            this.relativeResult = new Map();
            for (var i = this.headerService.priceMin; i <= this.headerService.priceMax; i += this.headerService.increment) {
                // set current  product attribute
                // const currentProduct = JSON.parse(JSON.stringify(this.selectedProduct));
                // currentProduct.attribute = this.selectedProduct.attribute;
                // currentProduct.attributeValues[this.utilManagementService.priceAtt] = i.toString();
                var tempProdList = [];
                for (var n = 0; n < this.productList.length; n++) {
                    tempProdList.push(JSON.parse(JSON.stringify(this.productList[n])));
                    tempProdList[n].attribute = this.productList[n].attribute;
                    tempProdList[n].attributeValues[this.utilManagementService.priceAtt] = i.toString();
                }
                // get relative result
                this.relativeResult.set(i, this.utilManagementService.getRelativeResult(tempProdList));
            }
        }
        else {
            this.message = 'Error! Please check your price parameters.';
        }
    };
    SensitivityService.prototype.getRelativeTotal = function () {
        var _this = this;
        this.relativeTotal = new Map();
        this.relativeResult.forEach(function (result, key) {
            var temp = new Array();
            var _loop_1 = function (i) {
                var sum = 0;
                result[i].forEach(function (a) { return sum += a; });
                if (sum !== 0) {
                    temp.push((sum / result[i].length).toFixed(1));
                }
                else {
                    temp.push(0);
                }
            };
            for (var i in result) {
                _loop_1(i);
            }
            _this.relativeTotal.set(Number(key.toFixed(2)), temp);
        });
    };
    SensitivityService.prototype.getRelativeTotalByLevel = function (segmentPositions, selectedLevel) {
        var _this = this;
        this.relativeTotal = new Map();
        this.relativeResult.forEach(function (result, key) {
            var temp = new Array();
            var _loop_2 = function (i) {
                var sum = 0;
                var cnt = 0;
                var length_1 = 0;
                result[i].forEach(function (a) {
                    if (Number(segmentPositions[cnt++]) === selectedLevel) {
                        sum += a;
                        length_1++;
                    }
                });
                if (sum !== 0) {
                    temp.push((sum / length_1).toFixed(1));
                }
                else {
                    temp.push(0);
                }
            };
            for (var i in result) {
                _loop_2(i);
            }
            _this.relativeTotal.set(key, temp);
        });
    };
    SensitivityService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_2__["UtilitymanagementService"],
            _service_utility_service__WEBPACK_IMPORTED_MODULE_3__["UtilityService"],
            _preference_preference_service__WEBPACK_IMPORTED_MODULE_5__["PreferenceService"],
            _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_6__["ProductmanagementService"],
            _core_header_header_service__WEBPACK_IMPORTED_MODULE_7__["HeaderService"]])
    ], SensitivityService);
    return SensitivityService;
}());



/***/ }),

/***/ "./src/app/sensitivity/sensitivity/sensitivity.component.css":
/*!*******************************************************************!*\
  !*** ./src/app/sensitivity/sensitivity/sensitivity.component.css ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".resizable-div {\r\n    resize: vertical;\r\n    overflow: auto;\r\n    border: 1px solid #e1e1e1;\r\n    min-height: 3rem;\r\n}\r\ndiv.sticky {\r\n    position: -webkit-sticky!important;\r\n    position: sticky!important;\r\n    top: 0;\r\n}\r\n.btn-primary {\r\n    background-color: #2a6496!important;\r\n    border-color: #2a6496!important;\r\n}\r\n.collapsible {\r\n    background-color: #f7f7f7;\r\n    cursor: pointer;\r\n    padding-left: 5px;\r\n    width: 100%;\r\n    border: #f7f7f7;\r\n    text-align: left;\r\n    outline: none;\r\n    font-size: 1em;\r\n    margin: .5%;\r\n    padding-top: .5%;\r\n    padding-bottom: .5%;\r\n    -webkit-transition: 0.4s;\r\n    transition: 0.4s;\r\n}\r\nbutton.collapsible:after {\r\n    /*content: 'Collapse';*/\r\n    color: white;\r\n    background-color: #2a6496;\r\n    margin-right: 10px;\r\n    float: right;\r\n    align: middle;\r\n}\r\nbutton.collapsible.active:after {\r\n    /*content: 'Expand';*/\r\n}\r\n.active, .collapsible:hover {\r\n    background-color: #f7f7f7;\r\n}\r\n.content {\r\n    padding: 0 18px;\r\n    display: block;\r\n    overflow: hidden;\r\n    /*background-color: #fafafa;*/\r\n    border: none;\r\n}\r\n/*table {*/\r\n/*    display: inline-block;*/\r\n/*    table-layout: fixed;*/\r\n/*    height:100%;*/\r\n/*    overflow-y: auto;*/\r\n/*    border: none;*/\r\n/*    width: 100%!important;*/\r\n/*    table-layout: auto;*/\r\n/*}*/\r\n/*table td, .table th {*/\r\n/*    padding: 5px!important;*/\r\n/*    font-size: .9em;*/\r\n/*    width: 100vw;*/\r\n/*}*/\r\n/*table {*/\r\n/*    display: inline-block;*/\r\n/*    table-layout: fixed;*/\r\n/*    width: 100%;*/\r\n/*}*/\r\n/*td {*/\r\n/*    font-size: .8em;*/\r\n/*    overflow: hidden;*/\r\n/*    white-space: nowrap;*/\r\n/*    text-overflow: ellipsis;*/\r\n/*}*/\r\n/*Splitter*/\r\n#loader {\r\n    color: #008cff;\r\n    height: 40px;\r\n    left: 45%;\r\n    position: absolute;\r\n    top: 45%;\r\n    width: 30%;\r\n}\r\n#template_container {\r\n    margin: 60px auto;\r\n}\r\n.auto-size-content, .template {\r\n    padding: 9px;\r\n}\r\nul li.highlight {\r\n    background-color: #DCDCDC !important;\r\n\r\n}\r\n.overlay {\r\n    position: absolute;\r\n    z-index: 1002;\r\n    background-color: rgba(255, 255, 255, 0.5);\r\n    width: 100%;\r\n    height: 100%;\r\n}\r\n.spinner-wrapper {\r\n    display: -webkit-box;\r\n    display: flex;\r\n    -webkit-box-pack: center;\r\n            justify-content: center;\r\n    justify-items: center;\r\n}\r\nul li {\r\n    cursor: pointer;\r\n}\r\n/*table { width: 100%; table-layout: fixed }*/\r\n/*td { white-space: nowrap;*/\r\n/*    overflow: hidden;*/\r\n/*    text-overflow: ellipsis;*/\r\n/*    font-size: .8em;*/\r\n/*    padding: 5px!important;*/\r\n/*    width: 100vw;*/\r\n/*}*/\r\ntable {\r\n    display: block;\r\n    overflow-y: auto!important;\r\n    border: none;\r\n    width: 100vw;\r\n    margin-bottom: 0;\r\n    table-layout: fixed\r\n}\r\ntable td, .table th {\r\n    padding: 5px!important;\r\n    font-size: .8em;\r\n    width: 100vw;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2Vuc2l0aXZpdHkvc2Vuc2l0aXZpdHkvc2Vuc2l0aXZpdHkuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGdCQUFnQjtJQUNoQixjQUFjO0lBQ2QseUJBQXlCO0lBQ3pCLGdCQUFnQjtBQUNwQjtBQUNBO0lBQ0ksa0NBQWtDO0lBQ2xDLDBCQUEwQjtJQUMxQixNQUFNO0FBQ1Y7QUFFQTtJQUNJLG1DQUFtQztJQUNuQywrQkFBK0I7QUFDbkM7QUFHQTtJQUNJLHlCQUF5QjtJQUN6QixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLFdBQVc7SUFDWCxlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLGFBQWE7SUFDYixjQUFjO0lBQ2QsV0FBVztJQUNYLGdCQUFnQjtJQUNoQixtQkFBbUI7SUFDbkIsd0JBQWdCO0lBQWhCLGdCQUFnQjtBQUNwQjtBQUVBO0lBQ0ksdUJBQXVCO0lBQ3ZCLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWixhQUFhO0FBQ2pCO0FBRUE7SUFDSSxxQkFBcUI7QUFDekI7QUFFQTtJQUNJLHlCQUF5QjtBQUM3QjtBQUVBO0lBQ0ksZUFBZTtJQUNmLGNBQWM7SUFDZCxnQkFBZ0I7SUFDaEIsNkJBQTZCO0lBQzdCLFlBQVk7QUFDaEI7QUFFQSxVQUFVO0FBQ1YsNkJBQTZCO0FBQzdCLDJCQUEyQjtBQUMzQixtQkFBbUI7QUFDbkIsd0JBQXdCO0FBQ3hCLG9CQUFvQjtBQUNwQiw2QkFBNkI7QUFDN0IsMEJBQTBCO0FBQzFCLElBQUk7QUFFSix3QkFBd0I7QUFDeEIsOEJBQThCO0FBQzlCLHVCQUF1QjtBQUN2QixvQkFBb0I7QUFDcEIsSUFBSTtBQUdKLFVBQVU7QUFDViw2QkFBNkI7QUFDN0IsMkJBQTJCO0FBQzNCLG1CQUFtQjtBQUNuQixJQUFJO0FBRUosT0FBTztBQUNQLHVCQUF1QjtBQUN2Qix3QkFBd0I7QUFDeEIsMkJBQTJCO0FBQzNCLCtCQUErQjtBQUMvQixJQUFJO0FBRUosV0FBVztBQUNYO0lBQ0ksY0FBYztJQUNkLFlBQVk7SUFDWixTQUFTO0lBQ1Qsa0JBQWtCO0lBQ2xCLFFBQVE7SUFDUixVQUFVO0FBQ2Q7QUFFQTtJQUNJLGlCQUFpQjtBQUNyQjtBQUVBO0lBQ0ksWUFBWTtBQUNoQjtBQUVBO0lBQ0ksb0NBQW9DOztBQUV4QztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLGFBQWE7SUFDYiwwQ0FBMEM7SUFDMUMsV0FBVztJQUNYLFlBQVk7QUFDaEI7QUFFQTtJQUNJLG9CQUFhO0lBQWIsYUFBYTtJQUNiLHdCQUF1QjtZQUF2Qix1QkFBdUI7SUFDdkIscUJBQXFCO0FBQ3pCO0FBRUE7SUFDSSxlQUFlO0FBQ25CO0FBR0EsNkNBQTZDO0FBQzdDLDRCQUE0QjtBQUM1Qix3QkFBd0I7QUFDeEIsK0JBQStCO0FBQy9CLHVCQUF1QjtBQUN2Qiw4QkFBOEI7QUFDOUIsb0JBQW9CO0FBQ3BCLElBQUk7QUFFSjtJQUNJLGNBQWM7SUFDZCwwQkFBMEI7SUFDMUIsWUFBWTtJQUNaLFlBQVk7SUFDWixnQkFBZ0I7SUFDaEI7QUFDSjtBQUVBO0lBQ0ksc0JBQXNCO0lBQ3RCLGVBQWU7SUFDZixZQUFZO0FBQ2hCIiwiZmlsZSI6InNyYy9hcHAvc2Vuc2l0aXZpdHkvc2Vuc2l0aXZpdHkvc2Vuc2l0aXZpdHkuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yZXNpemFibGUtZGl2IHtcclxuICAgIHJlc2l6ZTogdmVydGljYWw7XHJcbiAgICBvdmVyZmxvdzogYXV0bztcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlMWUxZTE7XHJcbiAgICBtaW4taGVpZ2h0OiAzcmVtO1xyXG59XHJcbmRpdi5zdGlja3kge1xyXG4gICAgcG9zaXRpb246IC13ZWJraXQtc3RpY2t5IWltcG9ydGFudDtcclxuICAgIHBvc2l0aW9uOiBzdGlja3khaW1wb3J0YW50O1xyXG4gICAgdG9wOiAwO1xyXG59XHJcblxyXG4uYnRuLXByaW1hcnkge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzJhNjQ5NiFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItY29sb3I6ICMyYTY0OTYhaW1wb3J0YW50O1xyXG59XHJcblxyXG5cclxuLmNvbGxhcHNpYmxlIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmN2Y3Zjc7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDVweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYm9yZGVyOiAjZjdmN2Y3O1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxuICAgIG1hcmdpbjogLjUlO1xyXG4gICAgcGFkZGluZy10b3A6IC41JTtcclxuICAgIHBhZGRpbmctYm90dG9tOiAuNSU7XHJcbiAgICB0cmFuc2l0aW9uOiAwLjRzO1xyXG59XHJcblxyXG5idXR0b24uY29sbGFwc2libGU6YWZ0ZXIge1xyXG4gICAgLypjb250ZW50OiAnQ29sbGFwc2UnOyovXHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMmE2NDk2O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgYWxpZ246IG1pZGRsZTtcclxufVxyXG5cclxuYnV0dG9uLmNvbGxhcHNpYmxlLmFjdGl2ZTphZnRlciB7XHJcbiAgICAvKmNvbnRlbnQ6ICdFeHBhbmQnOyovXHJcbn1cclxuXHJcbi5hY3RpdmUsIC5jb2xsYXBzaWJsZTpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjdmN2Y3O1xyXG59XHJcblxyXG4uY29udGVudCB7XHJcbiAgICBwYWRkaW5nOiAwIDE4cHg7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAvKmJhY2tncm91bmQtY29sb3I6ICNmYWZhZmE7Ki9cclxuICAgIGJvcmRlcjogbm9uZTtcclxufVxyXG5cclxuLyp0YWJsZSB7Ki9cclxuLyogICAgZGlzcGxheTogaW5saW5lLWJsb2NrOyovXHJcbi8qICAgIHRhYmxlLWxheW91dDogZml4ZWQ7Ki9cclxuLyogICAgaGVpZ2h0OjEwMCU7Ki9cclxuLyogICAgb3ZlcmZsb3cteTogYXV0bzsqL1xyXG4vKiAgICBib3JkZXI6IG5vbmU7Ki9cclxuLyogICAgd2lkdGg6IDEwMCUhaW1wb3J0YW50OyovXHJcbi8qICAgIHRhYmxlLWxheW91dDogYXV0bzsqL1xyXG4vKn0qL1xyXG5cclxuLyp0YWJsZSB0ZCwgLnRhYmxlIHRoIHsqL1xyXG4vKiAgICBwYWRkaW5nOiA1cHghaW1wb3J0YW50OyovXHJcbi8qICAgIGZvbnQtc2l6ZTogLjllbTsqL1xyXG4vKiAgICB3aWR0aDogMTAwdnc7Ki9cclxuLyp9Ki9cclxuXHJcblxyXG4vKnRhYmxlIHsqL1xyXG4vKiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7Ki9cclxuLyogICAgdGFibGUtbGF5b3V0OiBmaXhlZDsqL1xyXG4vKiAgICB3aWR0aDogMTAwJTsqL1xyXG4vKn0qL1xyXG5cclxuLyp0ZCB7Ki9cclxuLyogICAgZm9udC1zaXplOiAuOGVtOyovXHJcbi8qICAgIG92ZXJmbG93OiBoaWRkZW47Ki9cclxuLyogICAgd2hpdGUtc3BhY2U6IG5vd3JhcDsqL1xyXG4vKiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpczsqL1xyXG4vKn0qL1xyXG5cclxuLypTcGxpdHRlciovXHJcbiNsb2FkZXIge1xyXG4gICAgY29sb3I6ICMwMDhjZmY7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICBsZWZ0OiA0NSU7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDQ1JTtcclxuICAgIHdpZHRoOiAzMCU7XHJcbn1cclxuXHJcbiN0ZW1wbGF0ZV9jb250YWluZXIge1xyXG4gICAgbWFyZ2luOiA2MHB4IGF1dG87XHJcbn1cclxuXHJcbi5hdXRvLXNpemUtY29udGVudCwgLnRlbXBsYXRlIHtcclxuICAgIHBhZGRpbmc6IDlweDtcclxufVxyXG5cclxudWwgbGkuaGlnaGxpZ2h0IHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNEQ0RDREMgIWltcG9ydGFudDtcclxuXHJcbn1cclxuXHJcbi5vdmVybGF5IHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHotaW5kZXg6IDEwMDI7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNSk7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxufVxyXG5cclxuLnNwaW5uZXItd3JhcHBlciB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbnVsIGxpIHtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuXHJcbi8qdGFibGUgeyB3aWR0aDogMTAwJTsgdGFibGUtbGF5b3V0OiBmaXhlZCB9Ki9cclxuLyp0ZCB7IHdoaXRlLXNwYWNlOiBub3dyYXA7Ki9cclxuLyogICAgb3ZlcmZsb3c6IGhpZGRlbjsqL1xyXG4vKiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpczsqL1xyXG4vKiAgICBmb250LXNpemU6IC44ZW07Ki9cclxuLyogICAgcGFkZGluZzogNXB4IWltcG9ydGFudDsqL1xyXG4vKiAgICB3aWR0aDogMTAwdnc7Ki9cclxuLyp9Ki9cclxuXHJcbnRhYmxlIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgb3ZlcmZsb3cteTogYXV0byFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICB3aWR0aDogMTAwdnc7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwO1xyXG4gICAgdGFibGUtbGF5b3V0OiBmaXhlZFxyXG59XHJcblxyXG50YWJsZSB0ZCwgLnRhYmxlIHRoIHtcclxuICAgIHBhZGRpbmc6IDVweCFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXNpemU6IC44ZW07XHJcbiAgICB3aWR0aDogMTAwdnc7XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/sensitivity/sensitivity/sensitivity.component.html":
/*!********************************************************************!*\
  !*** ./src/app/sensitivity/sensitivity/sensitivity.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"main\">\r\n    <div style=\"width: 100%; height: 82vh;\">\r\n        <as-split direction=\"horizontal\" (dragEnd)=\"refreshChart()\">\r\n            <as-split-area [size]=\"20\">\r\n                <as-split direction=\"vertical\" (dragEnd)=\"refreshChart()\">\r\n                    <as-split-area [size]=\"45\">\r\n                        <div class=\"row\" style=\"margin-right: .2%!important; font-size: .9em!important\">\r\n                            <div class=\"col\">\r\n                                <p>Select Product and Price Range</p>\r\n                                <select class=\"selectpicker\" style=\"width: 100%\"\r\n                                        (change)=\"selectPriceAttribute($event)\">\r\n                                    <option value=\"{{this.utilManagementService.priceAtt}}\">{{this.utilManagementService.productSet[this.utilManagementService.priceAtt]}}</option>\r\n                                </select>\r\n                                <select class=\"selectpicker\" style=\"width: 100%; margin-top: 5%\"\r\n                                        (change)=\"selectProduct($event)\">\r\n                                    <option *ngFor=\"let product of sceManagementService.selectedScenario.products\">{{product.name}}</option>\r\n                                </select>\r\n\r\n                                <!--                        <div class=\"row\" style=\"width: 100%; margin-right: .5%; margin-left: .5%\">-->\r\n\r\n                                <div class=\"row\"\r\n                                     style=\"padding-top: 5%; width: 100%; margin-right: .5%; margin-left: .5%\">\r\n                                    <div class=\"col-6\" style=\"padding-left: 0; padding-right: 0\">Start Price</div>\r\n                                    <div class=\"col-6\" style=\"padding-left: 0; padding-right: 0\">\r\n                                        <select class=\"selectpicker\" style=\"width: 100%\"\r\n                                                (change)=\"selectPriceMin($event)\">\r\n<!--                                            <option>Select</option>-->\r\n                                            <option *ngFor=\"let price of headerService.priceRange\"\r\n                                                    [selected]=\"price == headerService.priceMin\">{{price}}</option>\r\n                                        </select>\r\n                                    </div>\r\n                                </div>\r\n                                <div class=\"row\"\r\n                                     style=\"padding-top: 5%; width: 100%; margin-right: .5%; margin-left: .5%\">\r\n                                    <div class=\"col-6\" style=\"padding-left: 0; padding-right: 0\">End Price</div>\r\n                                    <div class=\"col-6\" style=\"padding-left: 0; padding-right: 0\">\r\n                                        <select class=\"selectpicker\" style=\"width: 100%\"\r\n                                                (change)=\"selectPriceMax($event)\">\r\n                                            <option *ngFor=\"let price of headerService.priceRange\"\r\n                                                    [selected]=\"price == headerService.priceMax\">{{price}}</option>\r\n                                        </select>\r\n                                    </div>\r\n                                </div>\r\n                                <div class=\"row\"\r\n                                     style=\"padding-top: 5%;width: 100%; margin-right: .5%; margin-left: .5%\">\r\n                                    <div class=\"col-6\" style=\"padding-left: 0; padding-right: 0\">Increment</div>\r\n                                    <div class=\"col-6\" style=\"padding-left: 0; padding-right: 0\">\r\n                                        <input type=\"number\" style=\"width: 100%\" [(ngModel)]=\"headerService.increment\">\r\n                                    </div>\r\n                                </div>\r\n                                <div class=\"row\"\r\n                                     style=\"padding-top: 5%;width: 100%; margin-right: .5%; margin-left: .5%\">\r\n                                    <button class=\"btn btn-sm btn-primary\" style=\"width: 100%\"\r\n                                            (click)=\"calculate()\">Calculate\r\n                                    </button>\r\n                                </div>\r\n                                <div class=\"row\"\r\n                                     style=\"padding-top: 5%;color: darkred; width: 100%; margin-right: .5%; margin-left: .5%\">\r\n                                    <span>{{sensiService.message}}</span>\r\n                                </div>\r\n\r\n\r\n                                <!--                        </div>-->\r\n\r\n                            </div>\r\n                        </div>\r\n                    </as-split-area>\r\n                    <as-split-area [size]=\"55\">\r\n                        <div id=\"segmentSection\" class=\"row\"\r\n                             style=\"padding-top: 5%;width: 100%; margin-right: .5%; margin-left: .5%; display: none; font-size: .9em!important\">\r\n                            <p>Select Segment</p>\r\n                            <ul id=\"myUL\">\r\n                                <li [ngClass]=\"{'highlight': segment['cell_1'] == sensiService.selectedLevel}\"\r\n                                    (mousedown)=\"toggleTree(segment['cell_1'])\"\r\n                                    *ngFor=\"let segment of prodManagementService.segments; let i = index\"\r\n                                     ><span\r\n                                        class=\"caret\">{{segment['cell_1']}}</span>\r\n                                    <ul class=\"nested\">\r\n                                        <li [ngClass]=\"{'highlight': level == sensiService.selectedLevel}\"\r\n                                            (click)=\"calculateLevel(level, segment['cell_1'])\"\r\n                                            *ngFor=\"let level of prodManagementService.segmentLevels[i]\"><span><i\r\n                                                class=\"fa fa-minus\"></i></span> {{level}}</li>\r\n                                    </ul>\r\n                                </li>\r\n                            </ul>\r\n\r\n\r\n\r\n                        </div>\r\n                    </as-split-area>\r\n                </as-split>\r\n            </as-split-area>\r\n            <as-split-area [size]=\"80\">\r\n                <as-split direction=\"vertical\" (dragEnd)=\"refreshChart()\">\r\n                    <as-split-area [size]=\"40\">\r\n                        <div class=\"row\" style=\"align: center; margin: .5%; height: 95%!important; display: block\"\r\n                             id=\"chart-div\">\r\n\r\n                            <ejs-chart #chart id=\"chart-container\" [zoomSettings]=\"zoom\" [tooltip]=\"tooltip\"\r\n                                       [primaryXAxis]=\"xAxis\" [primaryYAxis]=\"yAxis\" style=\"height:inherit!important;\"\r\n                                       [palettes]=\"colorService.color$ | async\" [title]=\"title\" [titleStyle]=\"titleStyle\">\r\n                                                                <e-series-collection>\r\n                                                                    <e-series type='StackingLine' xName=\"price\" yName=\"Product\"></e-series>\r\n                                                                </e-series-collection>\r\n\r\n                            </ejs-chart>\r\n\r\n                        </div>\r\n                        <div class=\"row\" style=\"margin-top: -50px; margin-right: .5%\">\r\n                            <div class=\"col\"></div>\r\n                            <div class=\"col-2\" style=\"padding-right: 0px!important\">\r\n                                <button id=\"exportBtn\" class=\"btn btn-sm btn-primary btn-block\"\r\n                                        (click)=\"openModal(exportModal)\" disabled>Export in Excel\r\n                                </button>\r\n                            </div>\r\n                        </div>\r\n                    </as-split-area>\r\n                    <as-split-area [size]=\"30\">\r\n\r\n                        <button id=\"collapseBtn2\" class=\"collapsible\"\r\n                                style=\"margin: 0px!important; background-color: #2a6496; color: white;\">\r\n                            Sensitivity\r\n                            Table\r\n                        </button>\r\n                        <div  class=\"\"\r\n                             style=\"margin: .2%; padding: .2%\">\r\n                            <table id=\"sensitivityTable2\" class=\"table\" *ngIf=\"sensiService.relativeTotal === undefined\"\r\n                                   style=\"overflow: hidden; alignment: left; margin-top: .2%; width: 100%; display: inline-block\">\r\n                                <tbody>\r\n                                <tr>\r\n                                    <td style=\"width: 100vw; height: 14px\"></td>\r\n                                </tr>\r\n                                <tr>\r\n                                    <td style=\"width: 100vw; height: 14px\"></td>\r\n                                </tr>\r\n                                <tr>\r\n                                    <td style=\"width: 100vw; height: 14px\"></td>\r\n                                </tr>\r\n                                <tr>\r\n                                    <td style=\"width: 100vw; height: 14px\"></td>\r\n                                </tr>\r\n                                </tbody>\r\n                            </table>\r\n                            <table id=\"sensitivityTable\" class=\"table\" *ngIf=\"sensiService.relativeTotal !== undefined\"\r\n                                   style=\"overflow: auto!important; alignment: left; margin-top: .2%; width: 100%;\"\r\n                                   >\r\n                                <thead class=\"thead-light\">\r\n                                <tr>\r\n                                    <th></th>\r\n                                    <th\r\n                                            *ngFor=\"let sensitivity of sensiService.relativeTotal | keyvalue\">{{sensitivity.key}}</th>\r\n                                </tr>\r\n                                </thead>\r\n\r\n\r\n                                <tbody>\r\n\r\n                                <tr *ngFor=\"let product of sensiService.productList; let n = index\">\r\n                                    <td>{{sensiService.productList[n].name}}</td>\r\n                                    <td *ngFor=\"let sensitivity of sensiService.relativeTotal | keyvalue; let i = index;\">\r\n                                        {{sensitivity.value[n]}}</td>\r\n                                </tr>\r\n                                <tr>\r\n                                    <td>None </td>\r\n                                    <td *ngFor=\"let sensitivity of sensiService.relativeTotal | keyvalue; let i = index;\">\r\n                                        {{sensitivity.value[sensiService.productList.length]}}</td>\r\n                                </tr>\r\n\r\n                                </tbody>\r\n                            </table>\r\n                        </div>\r\n                    </as-split-area>\r\n                    <as-split-area [size]=\"30\">\r\n                        <button id=\"collapseBtn\" class=\"collapsible\"\r\n                                style=\"margin: 0px!important; background-color: #2a6496; color: white;\">Products\r\n                        </button>\r\n                        <div id=\"productDiv\" class=\"row content\" style=\"margin: .2%; padding: .2%;\">\r\n                            <table class=\"table\" *ngIf=\"sensiService.relativeTotal === undefined\"\r\n                                   style=\"overflow: hidden; alignment: left; margin-top: .2%; width: 100%; display: inline-block\">\r\n                                <tbody >\r\n                                <tr>\r\n                                    <td style=\"width: 100vw; height: 14px\"></td>\r\n                                </tr>\r\n                                <tr>\r\n                                    <td style=\"width: 100vw; height: 14px\"></td>\r\n                                </tr>\r\n                                <tr>\r\n                                    <td style=\"width: 100vw; height: 14px\"></td>\r\n                                </tr>\r\n                                <tr>\r\n                                    <td style=\"width: 100vw; height: 14px\"></td>\r\n                                </tr>\r\n                                </tbody>\r\n                            </table>\r\n                            <table id=\"productTable\"  class=\"table table-bordered table-hover\" *ngIf=\"sensiService.relativeTotal !== undefined\"\r\n                                   style=\"overflow: auto; alignment: left; margin-top: .2%; width: 100%;\">\r\n<!--                                   (mouseover)=\"resizableGrid('productTable')\">-->\r\n                                <thead class=\"thead-light\" >\r\n                                <tr>\r\n                                    <th></th>\r\n                                    <th\r\n                                            *ngFor=\"let att of sensiService.selectedProduct.attribute | keyvalue: returnZero\">{{att.key}}</th>\r\n                                </tr>\r\n                                </thead>\r\n\r\n                                <tbody>\r\n\r\n                                <tr>\r\n                                    <td>{{sensiService.selectedProduct.name}}</td>\r\n                                    <td style=\"overflow: hidden; text-overflow: ellipsis; white-space: nowrap\" *ngFor=\"let att of sensiService.selectedProduct.attributeValues\">{{att}}</td>\r\n                                </tr>\r\n                                </tbody>\r\n                            </table>\r\n                        </div>\r\n                        <div class=\"row\"></div>\r\n                    </as-split-area>\r\n                </as-split>\r\n\r\n                <button class=\"open-button shadow p-3 mb-5 rounded\" (mousedown)=\"showHelpDesk()\">Help Desk</button>\r\n                <div class=\"chat-popup\" id=\"myForm\">\r\n                    <form class=\"form-container\">\r\n                        <h5>Help Desk</h5>\r\n                        <ul>\r\n                            <li>The price sensitivity tab provides immediate output of preference for one product that\r\n                                has price varied while holding price constant for all other products. You may choose the\r\n                                price range and price increments for the product whose price you wish to vary on the\r\n                                left. The Y axis shows preference share of each product, while the X axis shows the\r\n                                price of the chosen product. Typically, preference share for the chosen product will\r\n                                decrease as the price increases.\r\n                            </li>\r\n                        </ul>\r\n                        <button type=\"button\" class=\"btn btn-sm btn-primary\" (click)=\"showHelpDesk()\">Close</button>\r\n                    </form>\r\n                </div>\r\n            </as-split-area>\r\n        </as-split>\r\n        <!-- Product Modal -->\r\n        <ng-template #productModal let-modal style=\"width: 100vw\">\r\n            <div class=\"modal-header\">\r\n                Define Product\r\n                <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\r\n                    <span aria-hidden=\"true\">&times;</span>\r\n                </button>\r\n            </div>\r\n            <div class=\"modal-body\" style=\"padding-left: 10px\">\r\n                <div class=\"row\" style=\"padding: 5%\">\r\n\r\n                    <app-scenario></app-scenario>\r\n\r\n                </div>\r\n            </div>\r\n            <div class=\"modal-footer\">\r\n\r\n            </div>\r\n        </ng-template>\r\n    </div>\r\n    <!-- Message Modal -->\r\n    <ng-template #messageModal let-modal>\r\n        <div class=\"modal-header\">\r\n            <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\r\n                <span aria-hidden=\"true\">&times;</span>\r\n            </button>\r\n        </div>\r\n        <div class=\"modal-body\" style=\"padding-left: 10px\">\r\n            <p>{{exportStatus}}</p>\r\n        </div>\r\n    </ng-template>\r\n    <!-- export Modal -->\r\n    <ng-template #exportModal let-modal style=\"width: 100vw\">\r\n        <div class=\"modal-header\">\r\n            <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\r\n                <span aria-hidden=\"true\">&times;</span>\r\n            </button>\r\n        </div>\r\n        <div class=\"modal-body\" style=\"padding-left: 10px\">\r\n            <div class=\"row\" style=\"padding: 5%\">\r\n\r\n                <button class=\"btn btn-sm btn-primary btn-block shadow-lg\"\r\n                        (click)=\"saveFile(messageModal); modal.dismiss()\" style=\"font-size: .8em\">Append to an existing file</button>\r\n            </div>\r\n            <div class=\"row\" style=\"padding: 5%\">\r\n                <button class=\"btn btn-sm btn-primary btn-block shadow-lg\"\r\n                        (click)=\"exportAsExcelFile(messageModal); modal.dismiss()\" style=\"font-size: .8em\">Save as new file</button>\r\n            </div>\r\n        </div>\r\n        <div class=\"modal-footer\">\r\n\r\n        </div>\r\n    </ng-template>\r\n\r\n\r\n\r\n\r\n</div>\r\n"

/***/ }),

/***/ "./src/app/sensitivity/sensitivity/sensitivity.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/sensitivity/sensitivity/sensitivity.component.ts ***!
  \******************************************************************/
/*! exports provided: SensitivityComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SensitivityComponent", function() { return SensitivityComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _sensitivity_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../sensitivity.service */ "./src/app/sensitivity/sensitivity.service.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../utility/utilitymanagement.service */ "./src/app/utility/utilitymanagement.service.ts");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../scenario/scenariomanagement.service */ "./src/app/scenario/scenariomanagement.service.ts");
/* harmony import */ var _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../product/productmanagement.service */ "./src/app/product/productmanagement.service.ts");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _core_header_header_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../core/header/header.service */ "./src/app/core/header/header.service.ts");
/* harmony import */ var _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @syncfusion/ej2-angular-charts */ "./node_modules/@syncfusion/ej2-angular-charts/@syncfusion/ej2-angular-charts.es5.js");
/* harmony import */ var _service_chart_color_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../service/chart-color.service */ "./src/app/service/chart-color.service.ts");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! xlsx */ "./node_modules/xlsx/xlsx.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! exceljs/dist/exceljs.min.js */ "./node_modules/exceljs/dist/exceljs.min.js");
/* harmony import */ var exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../service/selected-scenario.service */ "./src/app/service/selected-scenario.service.ts");
/* harmony import */ var browser_nativefs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! browser-nativefs */ "./node_modules/browser-nativefs/dist/index.js");

















var SensitivityComponent = /** @class */ (function () {
    function SensitivityComponent(sensiService, modalService, utilManagementService, utilityService, sceManagementService, headerService, colorService, prodManagementService, selectedScenarioService, router) {
        var _this = this;
        this.sensiService = sensiService;
        this.modalService = modalService;
        this.utilManagementService = utilManagementService;
        this.utilityService = utilityService;
        this.sceManagementService = sceManagementService;
        this.headerService = headerService;
        this.colorService = colorService;
        this.prodManagementService = prodManagementService;
        this.selectedScenarioService = selectedScenarioService;
        this.router = router;
        this.spinnerShow = false;
        this.marker = {
            visible: true,
            height: 10,
            width: 10
        };
        this.utilityService.cast.subscribe(function (utl) {
            if (_this.utilManagementService.priceAtt === '') {
                _this.router.navigate(['/preference']);
            }
            _this.sensiService.priceRange = _this.headerService.priceRange;
            _this.sensiService.selectedPriceAtt = Number(_this.utilManagementService.priceAtt);
            _this.sensiService.selectedProduct = _this.sceManagementService.selectedScenario.products[0];
            if (_this.headerService.increment === 0) {
                _this.resetValues();
            }
            _this.utility = utl;
            _this.sensiService.message = '';
            _this.xAxis = {
                valueType: 'Category',
                title: 'Price'
            };
            _this.yAxis = {
                minimum: 0,
                maximum: 100,
                interval: 20,
                title: 'Preference share in %'
            };
            _this.tooltip = { enable: true, header: 'Preference share in %', format: '<b>${point.x} : ${point.y}</b>' };
            _this.legend = {
                visible: true,
                position: 'Bottom'
            };
            if (_this.headerService.increment === 0) {
                _this.sensiService.relativeTotal = undefined;
            }
            // Calculate min increment
            _this.sensiService.minIncrement = (Number(_this.headerService.priceRange[_this.headerService.priceRange.length - 1]) - Number(_this.headerService.priceRange[0])) * .01;
        });
        this.chartTitle = '';
        this.titleStyle = {
            position: 'bottom'
        };
    }
    SensitivityComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.sensiService.relativeTotal !== undefined) {
            if (this.sensiService.relativeTotal.size > 0)
                this.calculate();
        }
        if (this.sensiService.relativeResult === undefined) {
            this.sensiService.selectedPriceAtt = Number(this.utilManagementService.priceAtt);
        }
        this.selectedScenarioService.cast.subscribe(function (selectedSce) {
            _this.sensiService.selectedProduct = _this.sceManagementService.selectedScenario.products[0];
            _this.sensiService.productList = selectedSce.products;
        });
    };
    SensitivityComponent.prototype.ngAfterViewInit = function () {
        // if (this.sensiService.relativeTotal !== undefined) {
        //     if (this.sensiService.relativeTotal.size > 0) this.calculate();
        // }
    };
    SensitivityComponent.prototype.ngOnChanges = function (changes) {
    };
    SensitivityComponent.prototype.refreshChart = function () {
        this.chartObj.refresh();
    };
    SensitivityComponent.prototype.toggleTree = function (segment) {
        this.sensiService.selectedLevel = segment;
        var toggler = document.getElementsByClassName('caret');
        for (var i = 0; i < toggler.length; i++) {
            toggler[i].addEventListener('click', function () {
                this.parentElement.querySelector('.nested').classList.toggle('active');
                this.classList.toggle('caret-down');
            });
        }
        this.calculate();
    };
    SensitivityComponent.prototype.showHelpDesk = function () {
        var helpdesk = document.getElementById('myForm');
        if (helpdesk.style.display === 'none') {
            helpdesk.style.display = 'block';
        }
        else {
            helpdesk.style.display = 'none';
        }
    };
    SensitivityComponent.prototype.openModal = function (targetModal) {
        this.modalService.open(targetModal, {
            centered: true,
            backdrop: 'static',
            size: 'sm'
        });
    };
    SensitivityComponent.prototype.returnZero = function () {
        return 0;
    };
    SensitivityComponent.prototype.selectPriceAttribute = function (event) {
        this.sensiService.selectedPriceAtt = Number(event.target.value);
    };
    SensitivityComponent.prototype.selectProduct = function (event) {
        this.productList = this.sceManagementService.selectedScenario.products;
        var product = this.productList.find(function (prod) { return prod.name === event.target.value; });
        this.sensiService.selectedProduct = product;
        this.resetValues();
    };
    SensitivityComponent.prototype.selectPriceMin = function (event) {
        this.headerService.priceMin = Number(event.target.value);
    };
    SensitivityComponent.prototype.selectPriceMax = function (event) {
        this.headerService.priceMax = Number(event.target.value);
    };
    SensitivityComponent.prototype.resetValues = function () {
        this.sensiService.relativeTotal = undefined;
        /* Enable export button*/
        if (document.getElementById('exportBtn'))
            document.getElementById('exportBtn').disabled = true;
        /* Hide segment section*/
        if (document.getElementById('segmentSection'))
            document.getElementById('segmentSection').style.display = 'none';
    };
    SensitivityComponent.prototype.calculate = function () {
        try {
            this.sensiService.message = '';
            if (this.headerService.priceMin !== 0 && this.headerService.priceMax !== 0 && this.headerService.increment >= this.sensiService.minIncrement) {
                this.sensiService.calculateSensitivity();
                this.sensiService.getRelativeTotal();
                var sensitivity_1 = [];
                var names_1 = [];
                if (!Object(util__WEBPACK_IMPORTED_MODULE_8__["isUndefined"])(this.chartObj)) {
                    this.chartObj.series = [];
                }
                this.sensiService.relativeTotal.forEach(function (value, key) {
                    sensitivity_1.push(value);
                    names_1.push(key);
                });
                // Transpose
                var maxLen = sensitivity_1.reduce(function (max, _a) {
                    var length = _a.length;
                    return Math.max(max, length);
                }, 0);
                sensitivity_1 = Array.from({ length: maxLen }, function (_, i) { return sensitivity_1.map(function (row) { return row[i]; }); });
                for (var i in sensitivity_1) {
                    if (this.chartObj.series.length === (sensitivity_1.length - 1)) {
                        this.addSeries(sensitivity_1[i], 'None');
                    }
                    else {
                        this.addSeries(sensitivity_1[i], this.sensiService.productList[i].name);
                    }
                }
                if (this.sensiService.selectedLevel) {
                    this.title = this.sensiService.selectedLevel + ': Total';
                }
            }
            else {
                this.sensiService.message = 'Error! Please check your price parameters. Price increment should be at least 1% of price range.';
            }
        }
        catch (e) {
            console.log(e);
            this.title = '';
            this.sensiService.relativeTotal = undefined;
            this.sensiService.message = 'Error! Please check price parameters!';
        }
        if (this.sensiService.relativeTotal !== undefined) {
            /* Enable export button*/
            document.getElementById('exportBtn').disabled = false;
            document.getElementById('segmentSection').style.display = 'block';
        }
    };
    SensitivityComponent.prototype.calculateLevel = function (level, segment) {
        try {
            this.sensiService.message = '';
            if (this.headerService.priceMin !== 0 && this.headerService.priceMax !== 0) {
                // this.sensiService.selectedProduct = this.sceManagementService.selectedScenario.products[0];
                this.sensiService.calculateSensitivity();
                this.sensiService.selectSegmentLevel(level, segment);
            }
            var sensitivity_2 = [];
            var names_2 = [];
            if (!Object(util__WEBPACK_IMPORTED_MODULE_8__["isUndefined"])(this.chartObj)) {
                this.chartObj.series = [];
            }
            this.sensiService.relativeTotal.forEach(function (value, key) {
                sensitivity_2.push(value);
                names_2.push(key);
            });
            // Transpose
            var maxLen = sensitivity_2.reduce(function (max, _a) {
                var length = _a.length;
                return Math.max(max, length);
            }, 0);
            sensitivity_2 = Array.from({ length: maxLen }, function (_, i) { return sensitivity_2.map(function (row) { return row[i]; }); });
            for (var i in sensitivity_2) {
                if (this.chartObj.series.length === (sensitivity_2.length - 1)) {
                    this.addSeries(sensitivity_2[i], 'None');
                }
                else {
                    this.addSeries(sensitivity_2[i], this.sensiService.productList[i].name);
                }
            }
            if (level) {
                this.title = segment + ': ' + level;
            }
            else {
                this.title = segment + ': Total';
            }
        }
        catch (e) {
            this.title = '';
            this.sensiService.message = 'Error! Please check price parameters!';
        }
    };
    SensitivityComponent.prototype.addSeries = function (data, seriesName) {
        var chartData = [];
        var i = 0;
        this.sensiService.relativeTotal.forEach(function (value, key) {
            chartData.push({ price: Number(key), Product: Number(data[i++]) });
        });
        if (!Object(util__WEBPACK_IMPORTED_MODULE_8__["isUndefined"])(this.chartObj)) {
            this.chartObj.addSeries([{
                    type: 'Line',
                    dataSource: chartData,
                    xName: 'price',
                    yName: 'Product',
                    // marker: this.marker,
                    name: seriesName
                }]);
        }
    };
    SensitivityComponent.prototype.exportAsExcelFile = function (targetModal) {
        var _this = this;
        var sce = this.sceManagementService.selectedScenario;
        var workbook = new exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_13__["Workbook"]();
        var title = 'SimPRO Price Sensitivity';
        var worksheet = workbook.addWorksheet('Price Sensitivity');
        // const worksheet2 = workbook.addWorksheet('Chart');
        // Add Row and formatting
        // const titleRow = worksheet.addRow([title]);
        // titleRow.font = {name: 'Arial', underline: 'double', bold: true};
        worksheet.addRow([]);
        worksheet.addRow([this.utility.name]);
        worksheet.addRow([]);
        var sceRow = worksheet.addRow([sce.name, sce.savingDate]);
        sceRow.font = { name: 'Arial' };
        sceRow.alignment = { vertical: 'middle', horizontal: 'left' };
        worksheet.addRow([]);
        // Product table
        var tableRow = worksheet.addRow(['Table of Products']);
        tableRow.font = { bold: true };
        tableRow.alignment = { vertical: 'middle', horizontal: 'left' };
        var header = new Array();
        header.push('Product');
        sce.products[0].attribute.forEach(function (value, key) {
            header.push(key);
        });
        var headRow = worksheet.addRow(header);
        headRow.font = { bold: true };
        headRow.alignment = { vertical: 'middle', horizontal: 'left' };
        var _loop_1 = function (prod) {
            var product = new Array();
            product.push(prod.name);
            prod.attributeValues.forEach(function (value, key) {
                product.push(value);
            });
            var prodTable = worksheet.addRow(product);
            prodTable.alignment = { vertical: 'middle', horizontal: 'left' };
        };
        for (var _i = 0, _a = sce.products; _i < _a.length; _i++) {
            var prod = _a[_i];
            _loop_1(prod);
        }
        worksheet.addRow([]);
        // Sensitivity table
        var simulation = worksheet.addRow(['Simulation']);
        simulation.font = { name: 'Arial', italic: true };
        var prefHeadRow = new Array();
        var sensitivity = [];
        this.sensiService.relativeTotal.forEach(function (value, key) {
            prefHeadRow.push(key);
            sensitivity.push(value);
        });
        var prefHead = worksheet.addRow(prefHeadRow);
        prefHead.font = { bold: true };
        prefHead.alignment = { vertical: 'middle', horizontal: 'left' };
        // Transpose map
        var maxLen = sensitivity.reduce(function (max, _a) {
            var length = _a.length;
            return Math.max(max, length);
        }, 0);
        sensitivity = Array.from({ length: maxLen }, function (_, i) { return sensitivity.map(function (row) { return row[i]; }); });
        for (var i in sensitivity) {
            var prefRow = sensitivity[i];
            var sensiRow = worksheet.addRow(prefRow);
            sensiRow.alignment = { vertical: 'middle', horizontal: 'left' };
        }
        var options = {
            // List of allowed MIME types, defaults to `*/*`.
            mimeTypes: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
            // List of allowed file extensions (with leading '.'), defaults to `''`.
            extensions: ['.xlsx'],
        };
        workbook.xlsx.writeBuffer().then(function (data2) {
            var blob = new Blob([data2], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            _this.saveAsNewFile(targetModal, blob, options).then(function (z) {
                _this.exportStatus = 'File successfully exported.';
                _this.modalService.open(targetModal, {
                    centered: true,
                    backdrop: 'static',
                    size: 'sm'
                });
            }).catch(function (e) {
                _this.exportStatus = 'Error! Please make sure file is closed.';
                _this.modalService.open(targetModal, {
                    centered: true,
                    backdrop: 'static',
                    size: 'sm'
                });
            });
        });
    };
    SensitivityComponent.prototype.saveFile = function (targetModal) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var workbook, fileReader, options2, blob;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        workbook = new exceljs_dist_exceljs_min_js__WEBPACK_IMPORTED_MODULE_13__["Workbook"]();
                        fileReader = new FileReader();
                        options2 = {
                            // List of allowed MIME types, defaults to `*/*`.
                            mimeTypes: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
                            // List of allowed file extensions (with leading '.'), defaults to `''`.
                            extensions: ['.xlsx'],
                            // Set to `true` for allowing multiple files, defaults to `false`.
                            multiple: false,
                        };
                        return [4 /*yield*/, Object(browser_nativefs__WEBPACK_IMPORTED_MODULE_16__["fileOpen"])(options2)];
                    case 1:
                        blob = _a.sent();
                        // @ts-ignore
                        fileReader.readAsBinaryString(new Blob([blob], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
                        fileReader.onload = function (z) {
                            var wb = xlsx__WEBPACK_IMPORTED_MODULE_12__["read"](fileReader.result, { type: 'binary' });
                            var sheetNames = wb.SheetNames;
                            // Copy sheets
                            if (sheetNames.indexOf('Price Sensitivity') < 0) {
                                workbook.addWorksheet('Price Sensitivity');
                            }
                            for (var j in sheetNames) {
                                var workSheet = workbook.addWorksheet(sheetNames[j]);
                                workSheet.addRow([]);
                                // Add utility name
                                var rows = xlsx__WEBPACK_IMPORTED_MODULE_12__["utils"].sheet_to_json(wb.Sheets[sheetNames[j]], { raw: false });
                                workSheet.addRow([Object.keys(rows[0])[0]]);
                                // Add Row and formatting
                                // const title = 'SimPRO Price Sensitivity';
                                // const titleRow = workSheet.addRow([title]);
                                // titleRow.font = {name: 'Arial', family: 4, size: 13, underline: 'double', bold: true};
                                for (var _i = 0, _a = xlsx__WEBPACK_IMPORTED_MODULE_12__["utils"].sheet_to_json(wb.Sheets[sheetNames[j]], { raw: false }); _i < _a.length; _i++) {
                                    var i = _a[_i];
                                    var tempArr = [];
                                    for (var n in i) {
                                        tempArr.push(i[n]);
                                    }
                                    if (tempArr[0] === 'Table of Products' || tempArr[0] === 'Simulation') {
                                        workSheet.addRow([]);
                                        var row = workSheet.addRow(tempArr);
                                        row.font = { bold: true, italic: true };
                                        row.alignment = { vertical: 'middle', horizontal: 'left' };
                                    }
                                    else if (tempArr[0] === 'Product') {
                                        var row = workSheet.addRow(tempArr);
                                        row.font = { bold: true };
                                        row.alignment = { vertical: 'middle', horizontal: 'left' };
                                    }
                                    else {
                                        var row = workSheet.addRow(tempArr);
                                        row.alignment = { vertical: 'middle', horizontal: 'left' };
                                    }
                                }
                            }
                            // @ts-ignore
                            _this.addSheet(workbook.getWorksheet('Price Sensitivity'), workbook, blob.handle, targetModal);
                        };
                        return [2 /*return*/];
                }
            });
        });
    };
    SensitivityComponent.prototype.addSheet = function (worksheet, workbook, fileHandle, targetModal) {
        var _this = this;
        var sce = this.sceManagementService.selectedScenario;
        worksheet.addRow([]);
        // Add Row and formatting
        // const title = 'SimPRO Price Sensitivity';
        // const titleRow = worksheet.addRow([title]);
        // titleRow.font = {name: 'Arial', family: 4, size: 13, underline: 'double', bold: true};
        //
        // worksheet.addRow([]);
        worksheet.addRow([this.utility.name]);
        var sceRow = worksheet.addRow([sce.name, sce.savingDate]);
        sceRow.alignment = { vertical: 'middle', horizontal: 'left' };
        worksheet.addRow([]);
        // Product table
        var tableRow = worksheet.addRow(['Table of Products']);
        tableRow.font = { bold: true, italic: true };
        tableRow.alignment = { vertical: 'middle', horizontal: 'left' };
        var header = new Array();
        header.push('Product');
        sce.products[0].attribute.forEach(function (value, key) {
            header.push(key);
        });
        var headRow = worksheet.addRow(header);
        headRow.font = { bold: true };
        headRow.alignment = { vertical: 'middle', horizontal: 'left' };
        var _loop_2 = function (prod) {
            var product = new Array();
            product.push(prod.name);
            prod.attributeValues.forEach(function (value, key) {
                product.push(value);
            });
            var prodTable = worksheet.addRow(product);
            prodTable.alignment = { vertical: 'middle', horizontal: 'left' };
        };
        for (var _i = 0, _a = sce.products; _i < _a.length; _i++) {
            var prod = _a[_i];
            _loop_2(prod);
        }
        worksheet.addRow([]);
        // Sensitivity table
        var simulation = worksheet.addRow(['Simulation']);
        simulation.font = { name: 'Arial', bold: true, italic: true };
        var prefHeadRow = new Array();
        var sensitivity = [];
        this.sensiService.relativeTotal.forEach(function (value, key) {
            prefHeadRow.push(key);
            sensitivity.push(value);
        });
        var prefHead = worksheet.addRow(prefHeadRow);
        prefHead.font = { bold: true };
        prefHead.alignment = { vertical: 'middle', horizontal: 'left' };
        // Transpose map
        var maxLen = sensitivity.reduce(function (max, _a) {
            var length = _a.length;
            return Math.max(max, length);
        }, 0);
        sensitivity = Array.from({ length: maxLen }, function (_, i) { return sensitivity.map(function (row) { return row[i]; }); });
        for (var i in sensitivity) {
            var prefRow = sensitivity[i];
            var sensiRow = worksheet.addRow(prefRow);
            sensiRow.alignment = { vertical: 'middle', horizontal: 'left' };
        }
        setTimeout(function () {
            workbook.xlsx.writeBuffer().then(function (data2) {
                var blob = new Blob([data2], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                var options = {
                    // Suggested file name to use, defaults to `''`.
                    fileName: 'TMTG_simpro_export.xlsx',
                    // Suggested file extensions (with leading '.'), defaults to `''`.
                    extensions: ['.xlsx'],
                };
                // this.saveAsNewFile(targetModal, blob, options).then((z) => {
                _this.writeFile(fileHandle, data2).then(function (z) {
                    _this.exportStatus = 'File successfully exported.';
                    _this.modalService.open(targetModal, {
                        centered: true,
                        backdrop: 'static',
                        size: 'sm'
                    });
                }).catch(function (e) {
                    console.log(e);
                    _this.exportStatus = 'Error! Please make sure file is closed.';
                    _this.modalService.open(targetModal, {
                        centered: true,
                        backdrop: 'static',
                        size: 'sm'
                    });
                });
            });
        }, 1500);
    };
    SensitivityComponent.prototype.saveAsNewFile = function (targetModal, blob, options) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Object(browser_nativefs__WEBPACK_IMPORTED_MODULE_16__["fileSave"])(blob, options)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    SensitivityComponent.prototype.writeFile = function (fileHandle, contents) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var writable;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, fileHandle.createWritable()];
                    case 1:
                        writable = _a.sent();
                        // Write the contents of the file to the stream.
                        return [4 /*yield*/, writable.write(contents)];
                    case 2:
                        // Write the contents of the file to the stream.
                        _a.sent();
                        // Close the file and write the contents to disk.
                        return [4 /*yield*/, writable.close()];
                    case 3:
                        // Close the file and write the contents to disk.
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    SensitivityComponent.prototype.resizableGrid = function (tableId) {
        var row = document.getElementById(tableId).getElementsByTagName('tr')[0];
        var cols = row ? row.children : undefined;
        if (!cols)
            return;
        document.getElementById(tableId).style.overflow = 'hidden';
        var tableHeight = document.getElementById(tableId).offsetHeight;
        for (var i = 0; i < cols.length; i++) {
            var div = this.createDiv(tableHeight);
            cols[i].appendChild(div);
            cols[i].style.position = 'relative';
            this.setListeners(div);
        }
    };
    SensitivityComponent.prototype.setListeners = function (div) {
        var _this = this;
        var pageX, curCol, nxtCol, curColWidth, nxtColWidth;
        div.addEventListener('mousedown', function (e) {
            curCol = e.target.parentElement;
            nxtCol = curCol.nextElementSibling;
            pageX = e.pageX;
            var padding = _this.paddingDiff(curCol);
            curColWidth = curCol.offsetWidth - padding;
            if (nxtCol) {
                nxtColWidth = nxtCol.offsetWidth - padding;
            }
        });
        div.addEventListener('mouseover', function (e) {
            e.target.style.borderRight = '2px solid #0000ff';
        });
        div.addEventListener('mouseout', function (e) {
            e.target.style.borderRight = '';
        });
        window.document.addEventListener('mousemove', function (e) {
            if (curCol) {
                var diffX = e.pageX - pageX;
                if (nxtCol) {
                    nxtCol.style.width = (nxtColWidth - (diffX)) + 'px';
                }
                curCol.style.width = (curColWidth + diffX) + 'px';
            }
        });
        document.addEventListener('mouseup', function (e) {
            curCol = undefined;
            nxtCol = undefined;
            pageX = undefined;
            nxtColWidth = undefined;
            curColWidth = undefined;
        });
    };
    SensitivityComponent.prototype.createDiv = function (height) {
        var div = window.document.createElement('div');
        div.style.top = '0';
        div.style.right = '0';
        div.style.width = '5px';
        div.style.position = 'absolute';
        div.style.cursor = 'col-resize';
        div.style.userSelect = 'none';
        div.style.height = height + 'px';
        return div;
    };
    SensitivityComponent.prototype.paddingDiff = function (col) {
        if (this.getStyleVal(col, 'box-sizing') === 'border-box') {
            return 0;
        }
        var padLeft = this.getStyleVal(col, 'padding-left');
        var padRight = this.getStyleVal(col, 'padding-right');
        // tslint:disable-next-line:radix
        return (parseInt(padLeft) + parseInt(padRight));
    };
    SensitivityComponent.prototype.getStyleVal = function (elm, css) {
        return (window.getComputedStyle(elm, null).getPropertyValue(css));
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('screen'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], SensitivityComponent.prototype, "screen", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('canvas'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], SensitivityComponent.prototype, "canvas", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('downloadLink'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], SensitivityComponent.prototype, "downloadLink", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('chart'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _syncfusion_ej2_angular_charts__WEBPACK_IMPORTED_MODULE_10__["ChartComponent"])
    ], SensitivityComponent.prototype, "chartObj", void 0);
    SensitivityComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-sensitivity',
            template: __webpack_require__(/*! ./sensitivity.component.html */ "./src/app/sensitivity/sensitivity/sensitivity.component.html"),
            styles: [__webpack_require__(/*! ./sensitivity.component.css */ "./src/app/sensitivity/sensitivity/sensitivity.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_sensitivity_service__WEBPACK_IMPORTED_MODULE_2__["SensitivityService"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_3__["NgbModal"],
            _utility_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_4__["UtilitymanagementService"],
            _service_utility_service__WEBPACK_IMPORTED_MODULE_5__["UtilityService"],
            _scenario_scenariomanagement_service__WEBPACK_IMPORTED_MODULE_6__["ScenariomanagementService"],
            _core_header_header_service__WEBPACK_IMPORTED_MODULE_9__["HeaderService"],
            _service_chart_color_service__WEBPACK_IMPORTED_MODULE_11__["ChartColorService"],
            _product_productmanagement_service__WEBPACK_IMPORTED_MODULE_7__["ProductmanagementService"],
            _service_selected_scenario_service__WEBPACK_IMPORTED_MODULE_15__["SelectedScenarioService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_14__["Router"]])
    ], SensitivityComponent);
    return SensitivityComponent;
}());



/***/ }),

/***/ "./src/app/service/chart-color.service.ts":
/*!************************************************!*\
  !*** ./src/app/service/chart-color.service.ts ***!
  \************************************************/
/*! exports provided: ChartColorService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChartColorService", function() { return ChartColorService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");



var ChartColorService = /** @class */ (function () {
    function ChartColorService() {
        this._color = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]([]);
        this.color$ = this._color.asObservable();
    }
    Object.defineProperty(ChartColorService.prototype, "color", {
        get: function () {
            return this._color.getValue();
        },
        set: function (val) {
            this._color.next(val);
        },
        enumerable: true,
        configurable: true
    });
    ChartColorService.prototype.addColor = function (color) {
        this.color = this.color.concat([
            color
        ]);
    };
    ChartColorService.prototype.editColor = function (index, color) {
        this.color[index] = color;
        this.color = this.color.slice();
    };
    ChartColorService.prototype.setColors = function (palette) {
        this.color = palette;
    };
    ChartColorService.prototype.resetColor = function () {
        this.color = [];
    };
    ChartColorService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ChartColorService);
    return ChartColorService;
}());



/***/ }),

/***/ "./src/app/service/product.service.ts":
/*!********************************************!*\
  !*** ./src/app/service/product.service.ts ***!
  \********************************************/
/*! exports provided: ProductService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductService", function() { return ProductService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");



var ProductService = /** @class */ (function () {
    function ProductService() {
        this._products = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]([]);
        this.products$ = this._products.asObservable();
    }
    Object.defineProperty(ProductService.prototype, "products", {
        get: function () {
            return this._products.getValue();
        },
        set: function (val) {
            this._products.next(val);
        },
        enumerable: true,
        configurable: true
    });
    ProductService.prototype.addProducts = function (proName, attValues) {
        this.products = this.products.concat([
            { id: this.products.length + 1, name: proName, attribute: '', attributeValues: attValues }
        ]);
    };
    ProductService.prototype.removeProduct = function (id) {
        this.products = this.products.filter(function (product) { return product.id !== id; });
    };
    ProductService.prototype.removeAllProducts = function () {
        this.products = [];
    };
    ProductService.prototype.addNewProduct = function (proName, att, attValues) {
        this.products = [
            { id: this.products.length + 1, name: proName, attribute: att, attributeValues: attValues }
        ];
    };
    ProductService.prototype.editProduct = function (name, attributeValues) {
        var product = this.products.find(function (pro) { return pro.name === name; });
        if (product) {
            var index = this.products.indexOf(product);
            this.products[index] = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, product, { attributeValues: attributeValues });
            this.products = this.products.slice();
        }
    };
    ProductService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ProductService);
    return ProductService;
}());



/***/ }),

/***/ "./src/app/service/scenario.service.ts":
/*!*********************************************!*\
  !*** ./src/app/service/scenario.service.ts ***!
  \*********************************************/
/*! exports provided: ScenarioService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ScenarioService", function() { return ScenarioService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");



var ScenarioService = /** @class */ (function () {
    function ScenarioService() {
        this._scenarios = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]([]);
        this.scenarios$ = this._scenarios.asObservable();
    }
    Object.defineProperty(ScenarioService.prototype, "scenarios", {
        get: function () {
            return this._scenarios.getValue();
        },
        set: function (val) {
            this._scenarios.next(val);
        },
        enumerable: true,
        configurable: true
    });
    ScenarioService.prototype.addScenarios = function (title, productList) {
        this.scenarios = this.scenarios.concat([
            { id: this.scenarios.length, name: title, savingDate: new Date(), creationDate: new Date(), description: 'This is a description', products: productList }
        ]);
    };
    ScenarioService.prototype.removeScenario = function (id) {
        this.scenarios = this.scenarios.filter(function (scenario) { return scenario.id !== id; });
    };
    ScenarioService.prototype.editScenario = function (id, name, description) {
        var scenario = this.scenarios.find(function (sce) { return sce.id === id; });
        if (scenario) {
            var index = this.scenarios.indexOf(scenario);
            this.scenarios[index] = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, scenario, { name: name,
                description: description });
            this.scenarios = this.scenarios.slice();
        }
    };
    ScenarioService.prototype.duplicateScenario = function (id, name) {
        var scenario = this.scenarios.find(function (sce) { return sce.id === id; });
        if (scenario) {
            var index = this.scenarios[this.scenarios.length - 1].id;
            this.scenarios = this.scenarios.concat([
                this.scenarios[this.scenarios.length]
            ]);
            this.scenarios[this.scenarios.length - 1] = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, scenario, { id: index + 1, name: 'Scenario_' + (index + 1) });
        }
    };
    ScenarioService.prototype.resetScenario = function () {
        this.scenarios = [];
    };
    ScenarioService.prototype.updateProduct = function (name, products) {
        var scenario = this.scenarios.find(function (sce) { return sce.name === name; });
        if (scenario) {
            var index = this.scenarios.indexOf(scenario);
            this.scenarios[index] = tslib__WEBPACK_IMPORTED_MODULE_0__["__assign"]({}, scenario, { products: products });
            this.scenarios = this.scenarios.slice();
        }
    };
    ScenarioService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ScenarioService);
    return ScenarioService;
}());



/***/ }),

/***/ "./src/app/service/selected-scenario.service.ts":
/*!******************************************************!*\
  !*** ./src/app/service/selected-scenario.service.ts ***!
  \******************************************************/
/*! exports provided: SelectedScenarioService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectedScenarioService", function() { return SelectedScenarioService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");



var SelectedScenarioService = /** @class */ (function () {
    function SelectedScenarioService() {
        // @ts-ignore
        this.selectedScenario = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]([]);
        this.cast = this.selectedScenario.asObservable();
    }
    SelectedScenarioService.prototype.editScenario = function (scenario) {
        this.selectedScenario.next(scenario);
    };
    SelectedScenarioService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], SelectedScenarioService);
    return SelectedScenarioService;
}());



/***/ }),

/***/ "./src/app/service/user-auth.service.ts":
/*!**********************************************!*\
  !*** ./src/app/service/user-auth.service.ts ***!
  \**********************************************/
/*! exports provided: UserAuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserAuthService", function() { return UserAuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var UserAuthService = /** @class */ (function () {
    function UserAuthService(router) {
        this.router = router;
        this.loggedInStatus = JSON.parse(sessionStorage.getItem('loggedIn') || 'false');
        this.isLogin = false;
        this.roleAs = 'ROLE_USER';
        this.enableElasticity = 'false';
    }
    UserAuthService.prototype.isloggedIn = function () {
        return JSON.parse(sessionStorage.getItem('loggedIn') || this.loggedInStatus.toString());
    };
    UserAuthService.prototype.isLoggedIn = function () {
        var loggedIn = sessionStorage.getItem('STATE');
        if (loggedIn === 'true') {
            this.isLogin = true;
        }
        else {
            this.isLogin = false;
        }
        return this.isLogin;
    };
    UserAuthService.prototype.setLoggedIn = function (value, user) {
        this.loggedInStatus = value;
        this.user = JSON.parse(user);
        if (this.getStatus() === '2')
            this.roleAs = 'ROLE_ADMIN';
        sessionStorage.setItem('user', this.user['username']);
        sessionStorage.setItem('loggedIn', 'true');
        sessionStorage.setItem('level', this.getStatus());
        sessionStorage.setItem('STATE', 'true');
        sessionStorage.setItem('ROLE', this.roleAs);
    };
    UserAuthService.prototype.getRole = function () {
        this.roleAs = sessionStorage.getItem('ROLE');
        return this.roleAs;
    };
    UserAuthService.prototype.getUser = function () {
        return sessionStorage.getItem('user');
    };
    UserAuthService.prototype.getStatus = function () {
        return this.user.level;
    };
    UserAuthService.prototype.getLevel = function () {
        return sessionStorage.getItem('level');
    };
    UserAuthService.prototype.setEnableElasticity = function (value) {
        sessionStorage.set('ELASTICITY', value);
        this.enableElasticity = value;
    };
    UserAuthService.prototype.getEnableElasticity = function () {
        return sessionStorage.getItem('ELASTICITY');
    };
    UserAuthService.prototype.logout = function () {
        sessionStorage.removeItem('loggedIn');
        sessionStorage.removeItem('level');
        location.reload();
    };
    UserAuthService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], UserAuthService);
    return UserAuthService;
}());



/***/ }),

/***/ "./src/app/service/users.service.ts":
/*!******************************************!*\
  !*** ./src/app/service/users.service.ts ***!
  \******************************************/
/*! exports provided: UsersService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersService", function() { return UsersService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");



var UsersService = /** @class */ (function () {
    function UsersService() {
        this._users = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]([]);
        this.users$ = this._users.asObservable();
    }
    Object.defineProperty(UsersService.prototype, "users", {
        get: function () {
            return this._users.getValue();
        },
        set: function (val) {
            this._users.next(val);
        },
        enumerable: true,
        configurable: true
    });
    UsersService.prototype.setUsers = function (users) {
        this.users = users;
    };
    UsersService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], UsersService);
    return UsersService;
}());



/***/ }),

/***/ "./src/app/service/utilities.service.ts":
/*!**********************************************!*\
  !*** ./src/app/service/utilities.service.ts ***!
  \**********************************************/
/*! exports provided: UtilitiesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilitiesService", function() { return UtilitiesService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");



var UtilitiesService = /** @class */ (function () {
    function UtilitiesService() {
        this._utilities = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]([]);
        this.utilities$ = this._utilities.asObservable();
    }
    Object.defineProperty(UtilitiesService.prototype, "utilities", {
        get: function () {
            return this._utilities.getValue();
        },
        set: function (val) {
            this._utilities.next(val);
        },
        enumerable: true,
        configurable: true
    });
    UtilitiesService.prototype.addUtilities = function (cnt, title, fname, xml) {
        this.utilities = this.utilities.concat([
            { id: cnt, name: title, fileName: fname, utl_xml: xml, utl_val: null }
        ]);
    };
    UtilitiesService.prototype.removeUtility = function (id) {
        // this.scenarios = this.scenarios.filter(scenario => scenario.name !== name);
        this.utilities = this.utilities.filter(function (utility) { return utility.id !== id; });
    };
    UtilitiesService.prototype.setUtilities = function (utls) {
        this.utilities = utls;
    };
    UtilitiesService.prototype.resetUtilities = function () {
        this.utilities = [];
    };
    UtilitiesService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], UtilitiesService);
    return UtilitiesService;
}());



/***/ }),

/***/ "./src/app/service/utility.service.ts":
/*!********************************************!*\
  !*** ./src/app/service/utility.service.ts ***!
  \********************************************/
/*! exports provided: UtilityService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilityService", function() { return UtilityService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");



var UtilityService = /** @class */ (function () {
    function UtilityService() {
        // @ts-ignore
        this.utility = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]([]);
        this.cast = this.utility.asObservable();
    }
    UtilityService.prototype.editUtility = function (newUtility) {
        this.utility.next(newUtility);
    };
    UtilityService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], UtilityService);
    return UtilityService;
}());



/***/ }),

/***/ "./src/app/startup.service.ts":
/*!************************************!*\
  !*** ./src/app/startup.service.ts ***!
  \************************************/
/*! exports provided: StartupService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StartupService", function() { return StartupService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _connection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./connection.service */ "./src/app/connection.service.ts");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var _service_utilities_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./service/utilities.service */ "./src/app/service/utilities.service.ts");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/fesm5/ngx-spinner.js");






var StartupService = /** @class */ (function () {
    function StartupService(svc, utilityService, utilitiesService, spinner) {
        this.svc = svc;
        this.utilityService = utilityService;
        this.utilitiesService = utilitiesService;
        this.spinner = spinner;
    }
    // Method you want to call at bootstrap
    // Must return a promise
    StartupService.prototype.load = function () {
        var _this = this;
        this._startupData = null;
        // return this.svc.doGet('api/utilities/')
        //            .toPromise()
        //            .then((response: any) => this._startupData = response)
        //            .catch((err: any) => Promise.resolve());
        // this.spinner.show();
        return new Promise(function (resolve, reject) {
            _this.svc.doGet('api/utilities/').subscribe(function (response) {
                var data = Object.values(response)[0];
                for (var i = 0; i < data.length; i++) {
                    _this.utilitiesService.addUtilities(data[i].id, data[i].name, data[i].name.toString().split('_upload')[0], data[i].utlXml);
                }
                resolve(true);
            }, function (err) {
            });
        });
    };
    Object.defineProperty(StartupService.prototype, "startupData", {
        get: function () {
            return this._startupData;
        },
        enumerable: true,
        configurable: true
    });
    StartupService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_connection_service__WEBPACK_IMPORTED_MODULE_2__["ConnectionService"],
            _service_utility_service__WEBPACK_IMPORTED_MODULE_3__["UtilityService"],
            _service_utilities_service__WEBPACK_IMPORTED_MODULE_4__["UtilitiesService"],
            ngx_spinner__WEBPACK_IMPORTED_MODULE_5__["NgxSpinnerService"]])
    ], StartupService);
    return StartupService;
}());



/***/ }),

/***/ "./src/app/user/user-list/user-list.component.css":
/*!********************************************************!*\
  !*** ./src/app/user/user-list/user-list.component.css ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "body {\r\n    padding: 0;\r\n    margin: 0;\r\n}\r\n#header {\r\n    position: fixed;\r\n    top: 0px;\r\n    left: 0px;\r\n    right: 0px;\r\n    height: 8%;\r\n    /*background-color: #f8f9fa;*/\r\n}\r\n#sidebar {\r\n    position: fixed;\r\n    top: 0px;\r\n    left: 0px;\r\n    bottom: 0px;\r\n    width: 15%;\r\n    background-color: #f8f9fa;\r\n}\r\n#parent {\r\n    margin-top: 50px;\r\n    margin-left: 200px;\r\n    background-color: blue;\r\n}\r\n.container{\r\n    margin-left: 0px;\r\n    padding-left: 0px;\r\n}\r\ntable {\r\n    width: 100%;\r\n    font: .9em Verdana;\r\n    border: none;\r\n}\r\nth, td {\r\n    border: solid 1px #999999;\r\n    border-collapse: collapse;\r\n    padding: 3px;\r\n    text-align: left;\r\n    font-family: Lato, sans-serif;\r\n    white-space: normal!important;\r\n    font-size: .9em;\r\n    width: 100vw;\r\n    margin-right: 10px\r\n}\r\nth {\r\n    font-weight: bold;\r\n}\r\ntable tr.highlight {\r\n    background-color: #4b4b4b !important;\r\n    color: #ffffff;\r\n}\r\nh1,h2,h3,h5,h6,p {\r\n    font-family: Lato, sans-serif;\r\n}\r\n.btn-primary {\r\n    background-color: #2a6496;\r\n    border-color: #2a6496;\r\n}\r\n.btn-blk {\r\n    background-color: #4b4b4b;\r\n    border-color: #4b4b4b;\r\n    color: #F0F0F0;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci91c2VyLWxpc3QvdXNlci1saXN0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxVQUFVO0lBQ1YsU0FBUztBQUNiO0FBQ0E7SUFDSSxlQUFlO0lBQ2YsUUFBUTtJQUNSLFNBQVM7SUFDVCxVQUFVO0lBQ1YsVUFBVTtJQUNWLDZCQUE2QjtBQUNqQztBQUNBO0lBQ0ksZUFBZTtJQUNmLFFBQVE7SUFDUixTQUFTO0lBQ1QsV0FBVztJQUNYLFVBQVU7SUFDVix5QkFBeUI7QUFDN0I7QUFDQTtJQUNJLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFDbEIsc0JBQXNCO0FBQzFCO0FBRUE7SUFDSSxnQkFBZ0I7SUFDaEIsaUJBQWlCO0FBQ3JCO0FBRUE7SUFDSSxXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLFlBQVk7QUFDaEI7QUFDQTtJQUNJLHlCQUF5QjtJQUN6Qix5QkFBeUI7SUFDekIsWUFBWTtJQUNaLGdCQUFnQjtJQUNoQiw2QkFBNkI7SUFDN0IsNkJBQTZCO0lBQzdCLGVBQWU7SUFDZixZQUFZO0lBQ1o7QUFDSjtBQUNBO0lBQ0ksaUJBQWlCO0FBQ3JCO0FBRUE7SUFDSSxvQ0FBb0M7SUFDcEMsY0FBYztBQUNsQjtBQUVBO0lBQ0ksNkJBQTZCO0FBQ2pDO0FBRUE7SUFDSSx5QkFBeUI7SUFDekIscUJBQXFCO0FBQ3pCO0FBRUE7SUFDSSx5QkFBeUI7SUFDekIscUJBQXFCO0lBQ3JCLGNBQWM7QUFDbEIiLCJmaWxlIjoic3JjL2FwcC91c2VyL3VzZXItbGlzdC91c2VyLWxpc3QuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbImJvZHkge1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIG1hcmdpbjogMDtcclxufVxyXG4jaGVhZGVyIHtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIHRvcDogMHB4O1xyXG4gICAgbGVmdDogMHB4O1xyXG4gICAgcmlnaHQ6IDBweDtcclxuICAgIGhlaWdodDogOCU7XHJcbiAgICAvKmJhY2tncm91bmQtY29sb3I6ICNmOGY5ZmE7Ki9cclxufVxyXG4jc2lkZWJhciB7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICB0b3A6IDBweDtcclxuICAgIGxlZnQ6IDBweDtcclxuICAgIGJvdHRvbTogMHB4O1xyXG4gICAgd2lkdGg6IDE1JTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmOGY5ZmE7XHJcbn1cclxuI3BhcmVudCB7XHJcbiAgICBtYXJnaW4tdG9wOiA1MHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwMHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogYmx1ZTtcclxufVxyXG5cclxuLmNvbnRhaW5lcntcclxuICAgIG1hcmdpbi1sZWZ0OiAwcHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDBweDtcclxufVxyXG5cclxudGFibGUge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBmb250OiAuOWVtIFZlcmRhbmE7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbn1cclxudGgsIHRkIHtcclxuICAgIGJvcmRlcjogc29saWQgMXB4ICM5OTk5OTk7XHJcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG4gICAgcGFkZGluZzogM3B4O1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIGZvbnQtZmFtaWx5OiBMYXRvLCBzYW5zLXNlcmlmO1xyXG4gICAgd2hpdGUtc3BhY2U6IG5vcm1hbCFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXNpemU6IC45ZW07XHJcbiAgICB3aWR0aDogMTAwdnc7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHhcclxufVxyXG50aCB7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxufVxyXG5cclxudGFibGUgdHIuaGlnaGxpZ2h0IHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM0YjRiNGIgIWltcG9ydGFudDtcclxuICAgIGNvbG9yOiAjZmZmZmZmO1xyXG59XHJcblxyXG5oMSxoMixoMyxoNSxoNixwIHtcclxuICAgIGZvbnQtZmFtaWx5OiBMYXRvLCBzYW5zLXNlcmlmO1xyXG59XHJcblxyXG4uYnRuLXByaW1hcnkge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzJhNjQ5NjtcclxuICAgIGJvcmRlci1jb2xvcjogIzJhNjQ5NjtcclxufVxyXG5cclxuLmJ0bi1ibGsge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzRiNGI0YjtcclxuICAgIGJvcmRlci1jb2xvcjogIzRiNGI0YjtcclxuICAgIGNvbG9yOiAjRjBGMEYwO1xyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/user/user-list/user-list.component.html":
/*!*********************************************************!*\
  !*** ./src/app/user/user-list/user-list.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"main \">\n    <div style=\"width: 100%; height: 82vh; \">\n        <as-split direction=\"horizontal\">\n            <as-split-area [size]=\"20\"><br/>\n                <div class=\"row\" style=\"height:auto; width: auto; border: #999999; padding: .5%; margin: .5%\">\n                    <table class=\"table table-bordered ed\" style=\"align: left!important; padding-right: 0px; display: block!important; margin: .5%; \">\n                        <tbody>\n                        <tr *ngFor=\"let user of users\" (click)=\"highlightUserRow(user)\"\n                            [ngClass]=\"{'highlight' : user.user == selectedUser}\">\n                            <td>{{ user.user}}</td>\n                        </tr>\n                        </tbody>\n                    </table>\n                </div>\n            </as-split-area>\n            <as-split-area [size]=\"80\">\n                <div>\n                    <p></p>\n                    <h5 align=\"center\">Manage Users</h5>\n                    <form [formGroup]=\"addUserForm\"\n                          style=\" padding: 10px; margin-left: 10px\">\n                        <div class=\"form-group row\" style=\"padding-left: 10px\">\n                            <label class=\"col-form-label-sm col-sm-2\" for=\"user\">Login: </label>\n                            <div class=\"col-sm-6\">\n                                <input id=\"user\" type=\"text\" class=\"form-control form-control-sm\"\n                                       formControlName=\"user\">\n                            </div>\n                        </div>\n                        <div class=\"form-group row\" style=\"padding-left: 10px\">\n                            <label for=\"password\" class=\"col-form-label-sm col-sm-2\">Password: </label>\n                            <div class=\"col-sm-6\">\n                                <input id=\"password\" type=\"password\" class=\"form-control form-control-sm\"\n                                       formControlName=\"password\">\n                                <input type=\"checkbox\" (click)=\"showPassword()\">\n                            </div>\n                        </div>\n                        <div class=\"form-group row\" style=\"padding-left: 10px\">\n                            <label for=\"date\" class=\"col-form-label-sm col-sm-2\">Expiration Date: </label>\n                            <div class=\"col-sm-6\">\n                                <input id=\"date\" type=\"date\" class=\"form-control form-control-sm \"\n                                       formControlName=\"date\">\n                            </div>\n                        </div>\n                        <div style=\"max-height: 40vh; overflow-y: auto; width: auto; border: #999999; padding: .5%; margin: .5%\">\n                            <table class=\"table table-bordered ed\" style=\"align: left!important; padding-right: 0px; display: block!important;\">\n                                <tbody *ngFor=\"let utility of utlSvc.utilities$ | async\">\n                                <tr (click)=\"onUtilityRowClick(utility)\"\n                                    [class.highlight]=\"rowIsSelected(utility.id)\">\n                                    <td>{{utility.name}}</td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </form>\n                    <div class=\"row\" style=\"padding-left: 20px\">\n                        <div class=\"col-md-2\">\n                            <button type=\"submit\" class=\"btn btn-sm btn-blk\" (click)=\"addUser(messageModal)\">Add\n                                account\n                            </button>\n                        </div>\n                        <div class=\"col-md-2\">\n                            <button type=\"submit\" class=\"btn btn-sm btn-blk\" (click)=\"updateUser(messageModal)\">Update\n                                account\n                            </button>\n                        </div>\n                        <div class=\"col-md-2\">\n                            <button type=\"submit\" class=\"btn btn-sm btn-blk\" (click)=\"disableUser(messageModal)\">Disable\n                                account\n                            </button>\n                        </div>\n                        <div class=\"col-md-2\">\n                            <button type=\"submit\" class=\"btn btn-sm btn-blk\" (click)=\"deleteUser(messageModal)\">Delete\n                                account\n                            </button>\n                        </div>\n                    </div>\n                </div>\n            </as-split-area>\n        </as-split>\n    </div>\n    <!-- Message Modal -->\n    <ng-template #messageModal let-modal>\n        <div class=\"modal-header\">\n            <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\n                <span aria-hidden=\"true\">&times;</span>\n            </button>\n        </div>\n        <div class=\"modal-body\" style=\"padding-left: 10px\">\n            <p>{{status}}</p>\n        </div>\n    </ng-template>\n\n\n</div>\n"

/***/ }),

/***/ "./src/app/user/user-list/user-list.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/user/user-list/user-list.component.ts ***!
  \*******************************************************/
/*! exports provided: UserListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserListComponent", function() { return UserListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _models_User__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../models/User */ "./src/app/models/User.ts");
/* harmony import */ var _connection_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../connection.service */ "./src/app/connection.service.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _service_utilities_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../service/utilities.service */ "./src/app/service/utilities.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/fesm5/ngx-spinner.js");
/* harmony import */ var _service_users_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../service/users.service */ "./src/app/service/users.service.ts");
/* harmony import */ var _service_user_auth_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../service/user-auth.service */ "./src/app/service/user-auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");












var UserListComponent = /** @class */ (function () {
    function UserListComponent(spinner, svc, modalService, fb, utlSvc, datePipe, usersService, userAuthService, router) {
        var _this = this;
        this.spinner = spinner;
        this.svc = svc;
        this.modalService = modalService;
        this.fb = fb;
        this.utlSvc = utlSvc;
        this.datePipe = datePipe;
        this.usersService = usersService;
        this.userAuthService = userAuthService;
        this.router = router;
        this.selectedUtilityIds = new Set();
        this.selectedUtilities = [];
        this.usersService.users$.subscribe(function (users) { return _this.users = users; });
        this.utlSvc.utilities$.subscribe(function (utlList) { return _this.utilities = utlList; });
        this.editUserForm = this.fb.group({
            user_name: [''],
            user_password: [''],
            limit_date: ['']
        });
        this.addUserForm = this.fb.group({
            user: [''],
            password: [''],
            date: [''],
            utility: []
        });
        this.addUtilityForm = this.fb.group({
            utl_name: [''],
            utl: []
        });
        if (userAuthService.getLevel() === '1') {
            this.router.navigate(['/preference']);
        }
        // this.spinner.show();
        // this.loadUsers().then( res => this.spinner.hide());
    }
    UserListComponent.prototype.ngOnInit = function () {
    };
    UserListComponent.prototype.ngAfterViewInit = function () {
        this.spinner.hide();
    };
    UserListComponent.prototype.loadUsers = function () {
        var _this = this;
        this.svc.doGet('api/users/').subscribe(function (response) {
            _this.response = Object.values(response);
            _this.users = _this.response[0];
        });
        //eanDebug do something with users
        return new Promise(function (resolve, reject) {
            resolve();
        });
    };
    UserListComponent.prototype.addUser = function (targetModal) {
        var _this = this;
        this.modalService.dismissAll();
        var formVal = this.addUserForm.getRawValue();
        var user = new _models_User__WEBPACK_IMPORTED_MODULE_2__["User"]();
        var utilities = new Array();
        user.user = formVal['user'];
        user.password = formVal['password'];
        user.limitDate = formVal['date'];
        // user.utilities = this.selectedUtilities;
        this.selectedUtilityIds.forEach(function (value, key) {
            var utility = _this.utilities.find(function (utl) { return utl.id === key; });
            utilities.push(utility.id);
        });
        console.log("eanDebug: sending user info -> ", user.user, user.password);
        this.svc.doPost('api/user/insert/', { 'user': user.user, 'limitDate': user.limitDate,
            'password': user.password, 'utilities': utilities }).subscribe(function (response) {
            _this.status = 'User added to database!';
            _this.refreshUserList();
            _this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static',
                size: 'sm'
            });
        }, function (error) {
            console.log(error);
            _this.status = 'Error adding user to database!';
            _this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static',
                size: 'sm'
            });
        });
    };
    UserListComponent.prototype.deleteUser = function (targetModal) {
        var _this = this;
        var user = this.users.find(function (usr) { return usr.user === _this.selectedUser; });
        this.svc.doGet('api/user/delete/' + user.userID).subscribe(function (response) {
            _this.status = 'User deleted!';
            _this.refreshUserList();
            _this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static',
                size: 'sm'
            });
            _this.editUserForm = _this.fb.group({
                user_name: [''],
                user_password: [''],
                limit_date: ['']
            });
        }, function (error) {
            _this.status = 'Error';
            _this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static',
                size: 'sm'
            });
        });
    };
    UserListComponent.prototype.disableUser = function (targetModal) {
        var _this = this;
        var user = this.users.find(function (usr) { return usr.user === _this.selectedUser; });
        this.svc.doGet('api/user/disable/' + user.userID).subscribe(function (response) {
            _this.status = 'User disabled!';
            _this.refreshUserList();
            _this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static',
                size: 'sm'
            });
        }, function (error) {
            _this.status = 'Error!';
            _this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static',
                size: 'sm'
            });
        });
    };
    UserListComponent.prototype.updateUser = function (targetModal) {
        var _this = this;
        var utilities = new Array();
        var formVal = this.addUserForm.getRawValue();
        var user = this.users.find(function (usr) { return usr.user === _this.selectedUser; });
        user.user = formVal['user'];
        user.password = formVal['password'];
        user.limitDate = formVal['date'];
        var _loop_1 = function (key) {
            var utility = this_1.utilities.find(function (utl) { return utl.id === key; });
            utilities.push(utility.id);
        };
        var this_1 = this;
        // this.selectedUtilityIds.forEach( (value: any, key: any) => {
        for (var _i = 0, _a = Array.from(this.selectedUtilityIds); _i < _a.length; _i++) {
            var key = _a[_i];
            _loop_1(key);
        }
        this.svc.doPost('api/user/update/' + user.userID, { 'user': user.user, 'limitDate': user.limitDate,
            'password': user.password, 'utilities': utilities }).subscribe(function (response) {
            _this.status = 'Account updated!';
            _this.refreshUserList();
            _this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static',
                size: 'sm'
            });
        }, function (error) {
            _this.status = 'Error updating account!';
            _this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static',
                size: 'sm'
            });
        });
    };
    UserListComponent.prototype.onUtilityRowClick = function (utility) {
        if (this.selectedUtilityIds.has(utility.id)) {
            this.selectedUtilityIds.delete(utility.id);
        }
        else {
            this.selectedUtilityIds.add(utility.id);
        }
    };
    UserListComponent.prototype.rowIsSelected = function (id) {
        return this.selectedUtilityIds.has(id);
    };
    UserListComponent.prototype.highlightUserRow = function (user) {
        this.selectedUtilityIds = new Set();
        var userAccnt = this.users.find(function (usr) { return usr.userID === user.userID; });
        for (var utl in Object.values(userAccnt.accesUtilitiesName)) {
            this.onUtilityRowClick(userAccnt.accesUtilitiesName[utl]);
        }
        this.selectedUser = user.user;
        this.addUserForm = this.fb.group({
            user: user.user,
            password: "deprecated",
            date: this.datePipe.transform(user.limitDate, 'yyyy-MM-dd')
        });
    };
    UserListComponent.prototype.showPassword = function () {
        var password = document.getElementById('password');
        if (password.type === 'password') {
            password.type = 'text';
        }
        else {
            password.type = 'password';
        }
    };
    UserListComponent.prototype.refreshUserList = function () {
        var _this = this;
        this.svc.doGet('api/users/').subscribe(function (response) {
            _this.response = Object.values(response);
            _this.users = _this.response[0];
        });
    };
    UserListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-user-list',
            template: __webpack_require__(/*! ./user-list.component.html */ "./src/app/user/user-list/user-list.component.html"),
            styles: [__webpack_require__(/*! ./user-list.component.css */ "./src/app/user/user-list/user-list.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [ngx_spinner__WEBPACK_IMPORTED_MODULE_8__["NgxSpinnerService"],
            _connection_service__WEBPACK_IMPORTED_MODULE_3__["ConnectionService"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__["NgbModal"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"],
            _service_utilities_service__WEBPACK_IMPORTED_MODULE_6__["UtilitiesService"],
            _angular_common__WEBPACK_IMPORTED_MODULE_7__["DatePipe"],
            _service_users_service__WEBPACK_IMPORTED_MODULE_9__["UsersService"],
            _service_user_auth_service__WEBPACK_IMPORTED_MODULE_10__["UserAuthService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_11__["Router"]])
    ], UserListComponent);
    return UserListComponent;
}());



/***/ }),

/***/ "./src/app/user/user.module.ts":
/*!*************************************!*\
  !*** ./src/app/user/user.module.ts ***!
  \*************************************/
/*! exports provided: UserModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserModule", function() { return UserModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _user_list_user_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./user-list/user-list.component */ "./src/app/user/user-list/user-list.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/fesm5/ngx-spinner.js");
/* harmony import */ var angular_split__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! angular-split */ "./node_modules/angular-split/fesm5/angular-split.js");









var UserModule = /** @class */ (function () {
    function UserModule() {
    }
    UserModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_user_list_user_list_component__WEBPACK_IMPORTED_MODULE_3__["UserListComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbModule"],
                ngx_spinner__WEBPACK_IMPORTED_MODULE_7__["NgxSpinnerModule"],
                angular_split__WEBPACK_IMPORTED_MODULE_8__["AngularSplitModule"]
            ],
            exports: [
                _user_list_user_list_component__WEBPACK_IMPORTED_MODULE_3__["UserListComponent"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"],
            ]
        })
    ], UserModule);
    return UserModule;
}());



/***/ }),

/***/ "./src/app/utility/utility-list/utility-list.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/utility/utility-list/utility-list.component.css ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "table {\r\n    width: 100%;\r\n    font: .9em Verdana;\r\n    border: none;\r\n}\r\nth, td {\r\n    border: solid 1px #999999;\r\n    border-collapse: collapse;\r\n    padding: 3px;\r\n    text-align: left;\r\n    font-family: Lato, sans-serif;\r\n    white-space: normal!important;\r\n    font-size: .9em;\r\n    width: 100vw;\r\n    margin-right: 10px\r\n}\r\nth {\r\n    font-weight: bold;\r\n}\r\ntable tr.highlight {\r\n    background-color: #4b4b4b !important;\r\n    color: #ffffff;\r\n}\r\nh1,h2,h3,h5,h6,p {\r\n    font-family: Lato, sans-serif;\r\n}\r\n.btn-primary {\r\n    background-color: #2a6496;\r\n    border-color: #2a6496;\r\n}\r\n.container{\r\n    margin-left: 0px;\r\n    padding-left: 0px;\r\n}\r\n.btn-blk {\r\n    background-color: #4b4b4b;\r\n    border-color: #4b4b4b;\r\n    color: #F0F0F0;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXRpbGl0eS91dGlsaXR5LWxpc3QvdXRpbGl0eS1saXN0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLFlBQVk7QUFDaEI7QUFDQTtJQUNJLHlCQUF5QjtJQUN6Qix5QkFBeUI7SUFDekIsWUFBWTtJQUNaLGdCQUFnQjtJQUNoQiw2QkFBNkI7SUFDN0IsNkJBQTZCO0lBQzdCLGVBQWU7SUFDZixZQUFZO0lBQ1o7QUFDSjtBQUNBO0lBQ0ksaUJBQWlCO0FBQ3JCO0FBQ0E7SUFDSSxvQ0FBb0M7SUFDcEMsY0FBYztBQUNsQjtBQUVBO0lBQ0ksNkJBQTZCO0FBQ2pDO0FBRUE7SUFDSSx5QkFBeUI7SUFDekIscUJBQXFCO0FBQ3pCO0FBQ0E7SUFDSSxnQkFBZ0I7SUFDaEIsaUJBQWlCO0FBQ3JCO0FBQ0E7SUFDSSx5QkFBeUI7SUFDekIscUJBQXFCO0lBQ3JCLGNBQWM7QUFDbEIiLCJmaWxlIjoic3JjL2FwcC91dGlsaXR5L3V0aWxpdHktbGlzdC91dGlsaXR5LWxpc3QuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbInRhYmxlIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZm9udDogLjllbSBWZXJkYW5hO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG59XHJcbnRoLCB0ZCB7XHJcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjOTk5OTk5O1xyXG4gICAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcclxuICAgIHBhZGRpbmc6IDNweDtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICBmb250LWZhbWlseTogTGF0bywgc2Fucy1zZXJpZjtcclxuICAgIHdoaXRlLXNwYWNlOiBub3JtYWwhaW1wb3J0YW50O1xyXG4gICAgZm9udC1zaXplOiAuOWVtO1xyXG4gICAgd2lkdGg6IDEwMHZ3O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4XHJcbn1cclxudGgge1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxudGFibGUgdHIuaGlnaGxpZ2h0IHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM0YjRiNGIgIWltcG9ydGFudDtcclxuICAgIGNvbG9yOiAjZmZmZmZmO1xyXG59XHJcblxyXG5oMSxoMixoMyxoNSxoNixwIHtcclxuICAgIGZvbnQtZmFtaWx5OiBMYXRvLCBzYW5zLXNlcmlmO1xyXG59XHJcblxyXG4uYnRuLXByaW1hcnkge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzJhNjQ5NjtcclxuICAgIGJvcmRlci1jb2xvcjogIzJhNjQ5NjtcclxufVxyXG4uY29udGFpbmVye1xyXG4gICAgbWFyZ2luLWxlZnQ6IDBweDtcclxuICAgIHBhZGRpbmctbGVmdDogMHB4O1xyXG59XHJcbi5idG4tYmxrIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM0YjRiNGI7XHJcbiAgICBib3JkZXItY29sb3I6ICM0YjRiNGI7XHJcbiAgICBjb2xvcjogI0YwRjBGMDtcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/utility/utility-list/utility-list.component.html":
/*!******************************************************************!*\
  !*** ./src/app/utility/utility-list/utility-list.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"main \">\n    <div style=\"width: 100%; height: 80vh; \">\n        <as-split direction=\"horizontal\">\n            <as-split-area [size]=\"20\">\n                <div class=\"row\" style=\"height:auto; width: auto; border: #999999; padding: .5%; margin: .5%\">\n                    <table class=\"table table-bordered ed\" style=\"align: left!important; padding-right: 0px; display: block!important; margin: .5%; \">\n                        <tbody>\n                                <tr *ngFor=\"let utility of utilities\" (click)=\"highlightUtilityRow(utility)\"\n                                    [ngClass]=\"{'highlight'  : utility.name == selectedUtility}\">\n                                    <td>{{ utility.fileName}}</td>\n                                </tr>\n                            </tbody>\n                    </table>\n                    </div>\n            </as-split-area>\n            <as-split-area [size]=\"80\">\n                    <p></p>\n                <h5 align=\"center\">Manage Utilities</h5>\n\n                    <!--Utility Form-->\n                    <div class=\"row\"><br></div>\n                    <form [formGroup]=\"utilityForm\">\n                        <div class=\"row\" style=\"padding-left: 10px\">\n                            <label class=\"col-form-label-sm col-sm-2\" for=\"utility\">Utility Name: </label>\n                            <div class=\"col-sm-6\">\n                                <input id=\"utility\" type=\"text\" class=\"form-control form-control-sm\"\n                                       formControlName=\"utilityName\">\n                            </div>\n                        </div>\n                        <label class=\"col-form-label-sm\" style=\"padding-left: 10px\">Segments</label>\n                        <div class=\"row\" style=\"padding-left: 10px\">\n                            <div id=\"segmentDiv\" class=\"col\"\n                                 style=\"width: 80%; height: 10em; display: block; border: 1px; overflow-y: scroll\">\n                                <div #spreadsheet style=\"display: none\" id=\"segmentTable\"></div>\n                                <table *ngIf=\"selectedUtility === undefined\" style=\"height: 8em; width: 70%; alignment: left\"><tbody ><tr><td></td></tr> <tr><td> </td></tr><tr><td> </td></tr><tr><td> </td></tr></tbody></table>\n\n                            </div>\n                        </div>\n                        <label class=\"col-form-label-sm\" style=\"padding-left: 10px\">Attributes</label>\n                        <div class=\"row\" style=\"padding-left: 10px\">\n                            <div class=\"col\" >\n\n                                <table  style=\"height: 8em; width: 70%; alignment: left\">\n                                    <tbody *ngIf=\"selectedUtility !== undefined\" ><tr *ngFor=\"let value of this.utlService.productSetB; let i = index\" disabled [class.highlight]=\"rowIsInterpolable2(i)\"><td>{{value}}</td></tr></tbody>\n                                    <tbody *ngIf=\"selectedUtility === undefined\" ><tr><td></td></tr> <tr><td> </td></tr><tr><td> </td></tr><tr><td> </td></tr></tbody>\n                                </table>\n                            </div>\n                        </div>\n\n                        <br>\n                        <div class=\"row\" style=\"padding-left: 10px\">\n                            <label class=\"col-form-label-sm col-sm-2\" for=\"price\">Price Attribute: </label>\n                            <div class=\"col-sm-6\">\n                                <select id=\"price\" type=\"text\" class=\"form-control form-control-sm\"\n                                                 formControlName=\"priceAtt\" >\n                                <option value=\"\">No price sensitivity</option>\n                                <option value=\"{{value}}\" *ngFor=\"let value of this.utlService.priceSensiAttB; let i = index\" >{{value}}</option>\n                            </select>\n                            </div>\n                        </div>\n                        <div class=\"row\" style=\"padding-left: 10px\">\n                            <label class=\"col-form-label-sm col-sm-2\" for=\"utilityAdj\">Utility Adjustment: </label>\n                            <div class=\"col-sm-6\">\n                                <input id=\"utilityAdj\" type=\"text\" class=\"form-control form-control-sm\"\n                                       formControlName=\"utilityAdj\">\n                            </div>\n                        </div>\n                        <div class=\"row\" style=\"padding-left: 10px\">\n                            <label class=\"col-form-label-sm col-sm-2\" for=\"noneWeight\">Set None Weight: </label>\n                            <div class=\"col-sm-6\">\n                                <input id=\"noneWeight\" type=\"text\" class=\"form-control form-control-sm\"\n                                       formControlName=\"noneWeight\" >\n                            </div>\n                        </div>\n\n                        <div class=\"row\" style=\"padding-left: 10px\">\n                            <label class=\"col-form-label-sm col-sm-4\" for=\"disable-weight\">Disable respondents'\n                                weight </label>\n                            <div class=\"col-sm-6\"><input type=\"checkbox\" class=\"form-check-input\" id=\"disable-weight\" formControlName=\"disableWeight\"></div>\n                        </div>\n                        <div class=\"row\" style=\"padding-left: 10px\">\n                            <label class=\"col-form-label-sm col-sm-4\" for=\"disable-elasticity\">Disable price elasticity\n                                tab</label>\n                            <div class=\"col-sm-6\"><input type=\"checkbox\" class=\"form-check-input\" id=\"disable-elasticity\" formControlName=\"disableElasticity\" >\n                            </div>\n                        </div>\n                        <div class=\"row\" style=\"alignment: left\">\n                            <div class=\"col-sm-9\" align=\"center\">\n                                <button id=\"prohibitBtn\" type=\"button\" class=\"btn btn-sm btn-blk\" style=\"width: 98%;\"\n                                        (click)=\"openProhibitions(prohibitionsModal)\" disabled>Prohibitions\n                                </button>\n                            </div>\n                        </div>\n                    </form>\n                    <div class=\"row\">\n                        <div class=\"col-2 m-2\">\n                            <button id=\"importUtlBtn\" type=\"button\" class=\"btn btn-sm btn-blk\" style=\"width: 10vw\"\n                                    (click)=\"openModal(importModal)\">Import Utility\n                            </button>\n                        </div>\n                        <div class=\"col-2 m-2\">\n                            <button id=\"updateUtlBtn\" type=\"button\" class=\"btn btn-sm btn-blk\" style=\"width: 10vw\"\n                                    (click)=\"updateUtility(messageModal)\">Update Utility\n                            </button>\n                        </div>\n                        <div class=\"col-2 m-2\">\n                            <button id=\"deleteUtlBtn\" type=\"button\" class=\"btn btn-sm btn-blk\" style=\"width: 10vw\"\n                                    (click)=\"deleteUtility(messageModal)\">Delete Utility\n                            </button>\n                        </div>\n                        <div class=\"col-2 m-2\">\n                            <button type=\"button\" class=\"btn btn-sm btn-blk\" style=\"width: 10vw\"\n                                    (click)=\"refreshUtilities()\">Refresh Utility\n                            </button>\n                        </div>\n                    </div>\n\n                <!-- Message Modal -->\n                <ng-template #messageModal let-modal>\n                    <div class=\"modal-header\">\n                        <button type=\"button\" class=\"close\" (click)=\"modal.dismiss()\" aria-label=\"Close\">\n                            <span aria-hidden=\"true\">&times;</span>\n                        </button>\n                    </div>\n                    <div class=\"modal-body\" style=\"padding-left: 10px\">\n                        <p id=\"status\">{{status}}</p>\n                    </div>\n                </ng-template>\n\n\n                <!-- Prohibitions Modal -->\n                <ng-template #prohibitionsModal let-modal>\n                    <div class=\"modal-header\">\n                        Prohibit values\n                        <button type=\"button\" class=\"close\" (click)=\"modal.dismiss();this.utlService.clearProhibitionData()\" aria-label=\"Close\">\n                            <span aria-hidden=\"true\">&times;</span>\n                        </button>\n                    </div>\n                    <div class=\"modal-body\" style=\"padding-left: 20px\">\n                        <div class=\"row\">\n                            <div class=\"col-3\" style=\"border: 1px\">\n\n                                    <label>Prohibit levels of</label>\n                                <div class=\"row\" style=\"margin: 10px\">\n                                    <table>\n                                        <tbody>\n                                        <tr *ngFor=\"let value of this.utlService.productSetB\" (click)=\"highlightLevel1(value, messageModal)\"\n                                            [ngClass]=\"{'highlight' : value == selectedLevel1}\">\n                                            <td>{{value}}</td>\n                                        </tr>\n                                        </tbody>\n                                    </table>\n                                </div>\n                                <hr>\n\n                                    <label>From appearing with levels of</label>\n                                    <div class=\"row\" style=\"margin: 10px\">\n                                    <table>\n                                        <tbody>\n                                        <tr *ngFor=\"let value of this.utlService.productSetB\" (click)=\"highlightLevel2(value, messageModal)\"\n                                            [ngClass]=\"{'highlight' : value == selectedLevel2}\">\n                                            <td>{{value}}</td>\n                                        </tr>\n                                        <tr></tr>\n                                        </tbody>\n                                    </table>\n                                </div>\n                            </div>\n                            <div class=\"col\" style=\"background-color: lightgrey; padding: 10px; margin-right: 10px;\">\n                                <table align=\"middle\">\n                                    <tbody>\n                                        <tr><td></td><td *ngFor=\"let level1 of this.utlService.attLevels1\">{{level1}}</td></tr>\n                                        <tr *ngFor=\"let combi of this.utlService.levelCombi; let i = index\">\n                                            <td>{{this.utlService.attLevels2[i]}}</td>\n                                            <td *ngFor=\"let val of combi\"><input id=\"{{val}}\" type=\"checkbox\"  (change)=\"setProhibition(val)\" ></td>\n                                        </tr>\n                                    </tbody>\n                                </table>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"modal-footer\">\n                        <div style=\"height: 20%\"></div>\n                        <div class=\"row\" style=\"padding-left: 10px;\">\n                            <div class=\"col\">\n                                <button id=\"saveProhibitBtn\" class=\"btn btn-sm btn-blk\" style=\"width: 100%\"\n                                        (click)=\"saveProhibition(messageModal)\">Save\n                                </button>\n                            </div>\n                        </div>\n                    </div>\n\n                </ng-template>\n\n\n                <!-- Import Utility Modal -->\n                <ng-template #importModal let-modal>\n                    <div class=\"modal-header\">\n                        Import Utility\n                        <button type=\"button\" class=\"close\" (click)=\"modal.dismiss(); clearData()\" aria-label=\"Close\">\n                            <span aria-hidden=\"true\">&times;</span>\n                        </button>\n                    </div>\n                    <div class=\"modal-body\" style=\"padding-left: 10px\">\n                        <form [formGroup]=\"utilityForm\">\n                                <div class=\"form-group row\" style=\"padding-left: 10px;\">\n                                <label class=\"col-sm-4\" for=\"fileName\">Choose file: </label>\n                                <div class=\"col-sm-8\">\n                                    <input id=\"fileName\" type=\"file\" multiple=\"false\"\n                                           (change)=\"this.utlService.onFileChange($event); \"/>\n                                </div>\n                            </div>\n                            <div class=\"form-group row\" style=\"padding-left: 20px;\">\n                                <div class=\"col\"\n                                     style=\"width: 100%; height: 25vh; overflow-y: scroll; background-color: #e1e1e1\">\n\n                                    <table id=\"utilityTable\" class=\"table table-bordered ed\" *ngIf=\"this.utlService.dataSet !== undefined\">\n                                        <thead></thead>\n                                        <tbody style=\"font-size: 12px\">\n                                            <tr *ngFor=\"let row of this.utlService.dataSet; let i = index;\" [class.highlight]=\"rowHasError(i)\">\n                                                <td *ngFor=\"let cell of row\">{{cell}}</td>\n                                            </tr>\n                                        </tbody>\n                                    </table>\n\n                                </div>\n\n                            </div>\n                            <div class=\"form-group row\" style=\"padding-left: 10px;\">\n                                <div class=\"col\">\n                                    <button type=\"button\" class=\"btn btn-sm btn-blk\" style=\"width: 100%\"\n                                            (click)=\"convertToXml()\">Check file\n                                    </button>\n                                </div>\n                            </div>\n\n                            <label class=\"col-sm-4\" for=\"checkingConsole\">Checking console: </label>\n                            <div class=\"form-group row\" style=\"padding-left: 10px;\">\n                                <div class=\"col\">\n                                <textarea class=\"col\" id=\"checkingConsole\"\n                                          style=\"width: 100%; height: 30vh; overflow-y: scroll; font-size: 12px\"\n                                          [value]=\"this.utlService.message\"></textarea>\n                                </div>\n                            </div>\n\n                            <div class=\"row\" style=\"padding-left: 10px;\">\n                                <div class=\"col\">\n                                    <button id=\"importBtn\" class=\"btn btn-sm btn-blk\" style=\"width: 100%\" disabled\n                                            (click)=\"importXml(messageModal)\">Import\n                                    </button>\n                                </div>\n                            </div>\n                        </form>\n                    </div>\n                    <div class=\"modal-footer\">\n\n                    </div>\n                </ng-template>\n\n            </as-split-area>\n        </as-split>\n    </div>\n</div>\n<ngx-spinner bdColor=\"rgba(0, 0, 0, 0.8)\" size = \"medium\" color=\"#fff\" type = \"ball-spin\" [fullScreen] = \"true\" ><p style=\"color: white\" > Loading... </p></ngx-spinner>\n\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\n"

/***/ }),

/***/ "./src/app/utility/utility-list/utility-list.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/utility/utility-list/utility-list.component.ts ***!
  \****************************************************************/
/*! exports provided: UtilityListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilityListComponent", function() { return UtilityListComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _utilitymanagement_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utilitymanagement.service */ "./src/app/utility/utilitymanagement.service.ts");
/* harmony import */ var _service_utilities_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../service/utilities.service */ "./src/app/service/utilities.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _models_Utility__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../models/Utility */ "./src/app/models/Utility.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _connection_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../connection.service */ "./src/app/connection.service.ts");
/* harmony import */ var jexcel__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! jexcel */ "./node_modules/jexcel/dist/jexcel.js");
/* harmony import */ var jexcel__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(jexcel__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/fesm5/ngx-spinner.js");
/* harmony import */ var _service_user_auth_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../service/user-auth.service */ "./src/app/service/user-auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../service/utility.service */ "./src/app/service/utility.service.ts");














var UtilityListComponent = /** @class */ (function () {
    function UtilityListComponent(utlService, utlSvc, spinner, formBuilder, modalService, connectService, userAuthService, utilitySvc, router) {
        var _this = this;
        this.utlService = utlService;
        this.utlSvc = utlSvc;
        this.spinner = spinner;
        this.formBuilder = formBuilder;
        this.modalService = modalService;
        this.connectService = connectService;
        this.userAuthService = userAuthService;
        this.utilitySvc = utilitySvc;
        this.router = router;
        this.errorRows = new Set();
        this.utlSvc.utilities$.subscribe(function (utlList) { return _this.utilities = utlList; });
        this.utilityForm = this.formBuilder.group({
            utilityName: [''],
            priceAtt: [''],
            productLimit: [''],
            formula: [''],
            utilityAdj: [''],
            noneWeight: [''],
            disableWeight: [false],
            disableElasticity: [false]
        });
        if (userAuthService.getLevel() === '1') {
            this.router.navigate(['/preference']);
        }
    }
    UtilityListComponent.prototype.ngOnInit = function () {
        this.segmentTable = jexcel__WEBPACK_IMPORTED_MODULE_9__(this.spreadsheet.nativeElement, {
            data: null,
            colWidths: [150, 150, 150, 150],
            minDimensions: [0, 0],
            columnSorting: false,
        });
    };
    UtilityListComponent.prototype.ngAfterViewInit = function () {
        // this.utilitySvc.cast.subscribe(utility => {
        //     const temp = this.utilities.filter(utl => utility.name === utl.name);
        //     this.highlightUtilityRow(temp[0]);
        // });
    };
    UtilityListComponent.prototype.ngOnChanges = function () {
    };
    UtilityListComponent.prototype.highlightLevel1 = function (level, targetModal) {
        if (level !== this.selectedLevel2) {
            this.selectedLevel1 = level;
            if (this.selectedLevel2 !== undefined) {
                this.getProhibitTable();
            }
        }
        else {
            this.status = 'Error! Cannot select same levels';
            this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static'
            });
        }
    };
    UtilityListComponent.prototype.highlightLevel2 = function (level, targetModal) {
        if (level !== this.selectedLevel1) {
            this.selectedLevel2 = level;
            if (this.selectedLevel1 !== undefined) {
                this.getProhibitTable();
            }
        }
        else {
            this.status = 'Error! Cannot select same levels';
            this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static'
            });
        }
    };
    UtilityListComponent.prototype.highlightUtilityRow = function (utility) {
        var _this = this;
        this.selectedUtility = utility.name;
        this.utlService.productSensitivityIdsB = new Set();
        this.utlService.prohibitionListB = new Array();
        this.utlService.phAttriListB = new Array();
        this.selectedLevel1 = undefined;
        this.selectedLevel2 = undefined;
        this.sensibilityIndex = -1;
        /* Clear prohibition list*/
        this.utlService.prohibitionListB = new Array();
        this.utlService.phAttriListB = new Array();
        this.utlService.attLevels1 = new Array();
        this.utlService.attLevels2 = new Array();
        this.utlService.levelCombi = new Array();
        this.utlService.priceSensiAttB = new Array();
        // Get utility
        this.utility = this.utilities.find(function (utl) { return utl.name === _this.selectedUtility; });
        this.utlService.parseXMLFile2(this.utility.utl_xml);
        this.utilityForm = this.formBuilder.group({
            utilityName: this.utlService.utilityNameB,
            priceAtt: (this.utlService.productSensitivityIdsB.has(Number(this.utlService.priceAttB)) ? this.utlService.productSetB[this.utlService.priceAttB] : ''),
            productLimit: this.utlService.productLimitB,
            formula: this.utlService.formulaB,
            utilityAdj: this.utlService.utilityAdjB,
            noneWeight: this.utlService.noneMultiplicatorB,
            disableWeight: (/true/i).test(this.utlService.disableWeightB),
            disableElasticity: (/true/i).test(this.utlService.disableElasticityB)
        });
        document.getElementById('segmentTable').style.display = 'block';
        this.segmentTable.destroy();
        this.segmentTable = jexcel__WEBPACK_IMPORTED_MODULE_9__(this.spreadsheet.nativeElement, {
            data: this.utlService.segmentSetB,
            colWidths: [200, 200, 200, 200],
            minDimensions: [this.utlService.segmentSetB[0].length, (this.utlService.segmentSetB.length - 1)],
            columnSorting: false,
        });
        this.segmentTable.hideIndex();
        for (var i in this.utlService.segmentSetB[0]) {
            this.segmentTable.setHeader(i, this.utlService.segmentSetB[0][i]);
        }
        this.utlService.segmentSetB.splice(0, 1);
        this.segmentTable.setData([]);
        this.segmentTable.setData(this.utlService.segmentSetB);
        /* Enable prohibition button*/
        document.getElementById('prohibitBtn').disabled = false;
    };
    UtilityListComponent.prototype.openModal = function (targetModal) {
        this.modalService.open(targetModal, {
            centered: true,
            backdrop: 'static',
            size: 'lg'
        });
        this.utilityForm = this.formBuilder.group({
            utilityFile: ['']
        });
    };
    UtilityListComponent.prototype.convertToXml = function () {
        var _this = this;
        this.message = new Array();
        this.error = new Array();
        this.segments = new Map();
        this.productAtt = new Map();
        this.weight = 0;
        this.tune = 0;
        this.errorRows = new Set();
        this.utlService.message = this.utlService.message.concat('\nChecking Segments ...');
        var productKey = '';
        var priceAttKeys = new Array();
        try {
            for (var i in this.utlService.dataSet) {
                for (var n in this.utlService.dataSet[i]) {
                    if (String(this.utlService.dataSet[0][n]).toLowerCase().startsWith('seg')
                        && Number(i) > 3) {
                        if (!this.segments.has(this.utlService.dataSet[3][n])) {
                            this.segments.set(this.utlService.dataSet[3][n], [this.utlService.dataSet[i][n]]);
                        }
                        else if (this.segments.has(this.utlService.dataSet[3][n])) {
                            var tempArray = this.segments.get(this.utlService.dataSet[3][n]);
                            if (!tempArray.includes(this.utlService.dataSet[i][n])) {
                                tempArray.push(this.utlService.dataSet[i][n]);
                                this.segments.set(this.utlService.dataSet[3][n], tempArray);
                            }
                        }
                    }
                    else if (String(this.utlService.dataSet[0][n]).toLowerCase().startsWith('utl') && Number(i) === 2) {
                        if (!Object(util__WEBPACK_IMPORTED_MODULE_7__["isNull"])(this.utlService.dataSet[1][n])) {
                            productKey = this.utlService.dataSet[1][n];
                            this.productAtt.set(this.utlService.dataSet[1][n], [this.utlService.dataSet[2][n]]);
                        }
                        else if (Object(util__WEBPACK_IMPORTED_MODULE_7__["isNull"])(this.utlService.dataSet[1][n]) && productKey !== '') {
                            var tempArray = this.productAtt.get(productKey);
                            tempArray.push(this.utlService.dataSet[i][n]);
                            this.productAtt.set(productKey, tempArray);
                        }
                    }
                    else if (String(this.utlService.dataSet[0][n]).toLowerCase().startsWith('wgt') && (Number(i) === 0)) {
                        this.weight = n;
                    }
                    else if (String(this.utlService.dataSet[0][n]).toLowerCase().startsWith('tune') && (Number(i) === 0)) {
                        this.tune = n;
                    }
                }
            }
            var segCnt_1 = 1;
            if (this.segments.size !== 0) {
                this.segments.forEach(function (value, key) {
                    _this.utlService.message = _this.utlService.message.concat('\n\tChecking Seg' + segCnt_1++);
                    if (value.includes('null')) {
                        _this.utlService.message = _this.utlService.message.concat('\n\t\tError found on segment levels');
                    }
                    else {
                        _this.utlService.message = _this.utlService.message.concat('\n\t\tThere are ' + value.length + ' levels');
                    }
                });
            }
            else {
                this.error.push('\nError! No segments found');
            }
            this.utlService.message = this.utlService.message.concat('\nChecking attributes');
            var attCnt_1 = 0;
            if (this.productAtt.size !== 0) {
                this.productAtt.forEach(function (value, key) {
                    _this.utlService.message = _this.utlService.message.concat('\n\tChecking ' + key);
                    if (value.includes('null')) {
                        _this.utlService.message = _this.utlService.message.concat('\n\t\tError found on attribute values');
                    }
                    else {
                        if (_this.isInterpolable(value)) {
                            priceAttKeys.push(attCnt_1);
                        }
                        _this.utlService.message = _this.utlService.message.concat('\n\t\tThere are ' + value.length + ' attribute levels');
                    }
                    attCnt_1++;
                });
            }
            else {
                this.error.push('\nError! No product attributes found');
            }
            /* Get perfect value */
            this.utlService.getPerfectValue();
            var xmlDoc_1 = document.implementation.createDocument('', '', null);
            /* Utility properties */
            var utilityElem = xmlDoc_1.createElement('utility');
            utilityElem.setAttribute('fileName', this.utlService.file.name.replace('.xlsx', ''));
            utilityElem.setAttribute('name', this.utlService.file.name.replace('.xlsx', ''));
            utilityElem.setAttribute('adjustement', '1.0');
            utilityElem.setAttribute('noneMultiplicator', '1.0');
            utilityElem.setAttribute('perfectValue', (this.utlService.perfectValue).toString());
            utilityElem.setAttribute('maxProductInSimulation', '');
            utilityElem.setAttribute('weightDisabled', '');
            utilityElem.setAttribute('elasticityDisabled', '');
            utilityElem.setAttribute('resultPrecision', '1');
            xmlDoc_1.appendChild(utilityElem);
            /* Sensitivity Access properties */
            var sensitivityElem = xmlDoc_1.createElement('sensitivityAccess');
            for (var i in priceAttKeys) {
                sensitivityElem.setAttribute('attributeAuthorized_' + i, priceAttKeys[i]);
            }
            /* Sensitivity Selected properties */
            var sensitivitySelectedElem = xmlDoc_1.createElement('sensitivitySelected');
            sensitivitySelectedElem.append('0');
            sensitivityElem.appendChild(sensitivitySelectedElem);
            utilityElem.appendChild(sensitivityElem);
            /* References */
            var referencesElem_1 = xmlDoc_1.createElement('references');
            utilityElem.appendChild(referencesElem_1);
            /* Add segment values to references */
            this.segments.forEach(function (value, key) {
                var colElem = xmlDoc_1.createElement('col');
                colElem.setAttribute('cell_0', '1');
                colElem.setAttribute('cell_1', key);
                for (var _i = 0, value_1 = value; _i < value_1.length; _i++) {
                    var i = value_1[_i];
                    // if (i > 0 ) {
                    //     colElem.setAttribute('cell_2_' + (i - 1), i);
                    // } else {
                    colElem.setAttribute('cell_2_' + i, i);
                    // }
                }
                for (var _a = 0, _b = value.sort(); _a < _b.length; _a++) {
                    var i = _b[_a];
                    colElem.setAttribute('cell_3_' + (i), ('name_' + i));
                }
                referencesElem_1.appendChild(colElem);
            });
            /* Weight */
            this.utlService.message = this.utlService.message.concat('\nChecking weight...');
            if (this.weight !== 0) {
                var weightElem = xmlDoc_1.createElement('col');
                weightElem.setAttribute('cell_0', '2');
                weightElem.setAttribute('cell_1', 'WEIGHT');
                referencesElem_1.appendChild(weightElem);
            }
            else {
                this.error.push('\nError! No weight found');
            }
            /* Tune */
            this.utlService.message = this.utlService.message.concat('\nChecking tune...');
            if (this.tune !== 0) {
                var tuneElem = xmlDoc_1.createElement('col');
                tuneElem.setAttribute('cell_0', '3');
                tuneElem.setAttribute('cell_1', 'TUNE');
                referencesElem_1.appendChild(tuneElem);
            }
            else {
                this.error.push('\nError! No tune found');
            }
            /* Add product attributes to references */
            this.productAtt.forEach(function (value, key) {
                for (var valueKey in value) {
                    var colElem = xmlDoc_1.createElement('col');
                    colElem.setAttribute('cell_0', '4');
                    colElem.setAttribute('cell_1', key);
                    colElem.setAttribute('cell_2', value[valueKey]);
                    colElem.setAttribute('cell_3', '0');
                    referencesElem_1.appendChild(colElem);
                }
            });
            this.productAtt.forEach(function (value, key) {
                for (var valueKey in value) {
                    if (key.toString().toLowerCase() !== 'none') {
                        var colElem = xmlDoc_1.createElement('col');
                        colElem.setAttribute('cell_0', '5');
                        colElem.setAttribute('cell_1', key);
                        colElem.setAttribute('cell_2', value[valueKey]);
                        colElem.setAttribute('cell_3', '0');
                        referencesElem_1.appendChild(colElem);
                    }
                }
            });
            /* Values */
            var valuesElem = xmlDoc_1.createElement('values');
            for (var i in this.utlService.dataSet) {
                var colElem = xmlDoc_1.createElement('col');
                if (Number(i) > 3) {
                    for (var n in this.utlService.dataSet[i]) {
                        if (!isNaN(this.utlService.dataSet[i][n]) && !Object(util__WEBPACK_IMPORTED_MODULE_7__["isNull"])(this.utlService.dataSet[i][n])) {
                            colElem.setAttribute('cell_' + (Number(n) - 1), this.utlService.dataSet[i][n]);
                        }
                        else {
                            this.error.push('\n\nERROR FOUND ON VALUES! Check row ' + i + 'cell ' + n);
                            this.errorRows.add(Number(i));
                        }
                    }
                    valuesElem.appendChild(colElem);
                }
            }
            utilityElem.appendChild(valuesElem);
            /* Enable import xml btn */
            if (this.error.length) {
                this.utlService.message = this.utlService.message.concat(this.error.join(','));
                document.getElementById('checkingConsole').style.backgroundColor = 'red';
                document.getElementById('importBtn').disabled = true;
            }
            else {
                this.utlService.message = this.utlService.message.concat('\n\nNO ERROR FOUND');
                document.getElementById('checkingConsole').style.backgroundColor = '#FFFFE0';
                document.getElementById('importBtn').disabled = false;
            }
            var serializer = new XMLSerializer();
            var xmlStr = serializer.serializeToString(xmlDoc_1);
            this.utility = new _models_Utility__WEBPACK_IMPORTED_MODULE_5__["Utility"]();
            this.utility.name = this.utlService.file.name;
            this.utility.utl_xml = xmlStr;
        }
        catch (e) {
            this.utlService.message = 'Error reading file!';
        }
    };
    UtilityListComponent.prototype.importXml = function (targetModal) {
        var _this = this;
        this.connectService.doPost('api/utility/insert/', {
            'name': this.utility.name,
            'utl_xml': this.utility.utl_xml
        }).subscribe(function (response) {
            _this.utility.id = response['utilityID'];
            _this.utlSvc.addUtilities(_this.utility.id, _this.utility.name, _this.utility.name, _this.utility.utl_xml);
            _this.status = 'Successfully imported to database!';
            _this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static',
                size: 'sm'
            });
        }, function (error) {
            _this.status = 'Error!';
            _this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static',
                size: 'sm'
            });
        });
        this.utilities.sort();
        this.utlService.file = null;
        this.utlService.dataSet = new Array();
        this.utlService.message = '';
        this.message = new Array();
        this.utilityForm = this.formBuilder.group({
            utilityName: [''],
            priceAtt: [''],
            productLimit: [''],
            formula: [''],
            utilityAdj: [''],
            noneWeight: [''],
            disableWeight: [false],
            disableElasticity: [false]
        });
        // this.utlService.updateUtilityList();
        this.segmentTable.destroy();
        this.utlService.segmentSet = undefined;
        this.utlService.productSet = undefined;
    };
    UtilityListComponent.prototype.updateUtility = function (targetModal) {
        var _this = this;
        var formData = this.utilityForm.getRawValue();
        var oParser = new DOMParser();
        var xmlDoc = oParser.parseFromString(this.utility.utl_xml.toString(), 'application/xml');
        var newSegment = [];
        xmlDoc.getElementsByTagName('utility')[0].getAttributeNode('name').nodeValue = formData.utilityName;
        xmlDoc.getElementsByTagName('utility')[0].getAttributeNode('weightDisabled').nodeValue = formData.disableWeight;
        xmlDoc.getElementsByTagName('utility')[0].getAttributeNode('elasticityDisabled').nodeValue = formData.disableElasticity;
        xmlDoc.getElementsByTagName('utility')[0].getAttributeNode('noneMultiplicator').nodeValue = formData.noneWeight;
        xmlDoc.getElementsByTagName('utility')[0].getAttributeNode('adjustement').nodeValue = formData.utilityAdj;
        /* Get segment data and transpose */
        this.utlService.segmentSetB = new Array();
        this.utlService.segmentSetB.push(this.segmentTable.getHeaders().toString().split(','));
        for (var _i = 0, _a = this.segmentTable.getData(); _i < _a.length; _i++) {
            var i = _a[_i];
            this.utlService.segmentSetB.push(i);
        }
        var maxLen = this.utlService.segmentSetB.reduce(function (max, _a) {
            var length = _a.length;
            return Math.max(max, length);
        }, 0);
        this.utlService.segmentSetB = Array.from({ length: maxLen }, function (_, i) { return _this.utlService.segmentSetB.map(function (row) { return row[i]; }); });
        for (var i in this.utlService.segmentSetB) {
            this.utlService.segmentSetB[i] = this.utlService.segmentSetB[i].filter(function (x) { return x !== ''; });
            newSegment.push(this.utlService.segmentSetB[i].toString().split(','));
            // newSegment[i] = newSegment[i].reverse() as Array<any>;
        }
        /* Update segment table */
        try {
            /* Update segment values */
            var rowCnt = 0;
            do {
                var temp = xmlDoc.getElementsByTagName('references')[0].getElementsByTagName('col')[rowCnt];
                if (temp.getAttributeNode('cell_0').nodeValue === '1') {
                    for (var i in newSegment) {
                        if (temp.getAttributeNode('cell_1').nodeValue === newSegment[i][0]) {
                            var segCnt = 1;
                            // let n = 0;
                            for (var n = 0; n <= (newSegment.length); n++) {
                                if (!Object(util__WEBPACK_IMPORTED_MODULE_7__["isNull"])(temp.getAttributeNode('cell_3_' + n))) {
                                    temp.getAttributeNode('cell_3_' + n).nodeValue = newSegment[i][segCnt++];
                                }
                            }
                        }
                    }
                }
            } while (xmlDoc.getElementsByTagName('references')[0].getElementsByTagName('col')[++rowCnt]);
            if (formData.priceAtt !== '' && formData.priceAtt !== null) {
                if (xmlDoc.getElementsByTagName('sensitivitySelected')[0].childNodes[0] === undefined) {
                    xmlDoc.getElementsByTagName('sensitivitySelected')[0].append(this.utlService.productSetB.findIndex(function (i) { return i[0] === formData.priceAtt.toString(); }));
                }
                else {
                    xmlDoc.getElementsByTagName('sensitivitySelected')[0].childNodes[0].nodeValue = this.utlService.productSetB.findIndex(function (i) { return i[0] === formData.priceAtt.toString(); });
                }
            }
            else {
                xmlDoc.getElementsByTagName('sensitivitySelected')[0].childNodes[0].nodeValue = '';
            }
            /* Update prohibition list */
            if (this.utlService.phAttriListB[0] !== undefined) {
                var phbElem = xmlDoc.createElement('phb');
                for (var n in this.utlService.phAttriListB) {
                    var phElem = xmlDoc.createElement('ph');
                    for (var i in this.utlService.phAttriListB[n]) {
                        phElem.setAttribute('a' + (Number(i) + 1), this.utlService.phAttriListB[n][i]);
                    }
                    phbElem.appendChild(phElem);
                    var cbElem = xmlDoc.createElement('cb');
                    for (var i in this.utlService.prohibitionListB[n]) {
                        cbElem.setAttribute('b' + (Number(i) + 1), this.utlService.prohibitionListB[n][i]);
                    }
                    phElem.appendChild(cbElem);
                }
                if (xmlDoc.getElementsByTagName('phb')[0] === undefined) {
                    xmlDoc.getElementsByTagName('utility')[0].appendChild(phbElem);
                }
                else if (xmlDoc.getElementsByTagName('phb')[0] !== undefined) {
                    xmlDoc.getElementsByTagName('utility')[0].replaceChild(phbElem, xmlDoc.getElementsByTagName('phb')[0]);
                    // xmlDoc.getElementsByTagName('utility')[0].appendChild(phbElem);
                }
            }
            var serializer = new XMLSerializer();
            var xmlStr = serializer.serializeToString(xmlDoc);
            this.utility.utl_xml = xmlStr;
            this.connectService.doPost('api/utility/update/' + this.utility.id, {
                'name': this.utility.name,
                'utl_xml': this.utility.utl_xml
            }).subscribe(function (response) {
                _this.status = 'Successfully updated!';
                _this.modalService.open(targetModal, {
                    centered: true,
                    backdrop: 'static',
                    size: 'sm'
                });
            }, function (error) {
                _this.status = 'Error!';
                _this.modalService.open(targetModal, {
                    centered: true,
                    backdrop: 'static'
                });
            });
        }
        catch (e) {
            console.log(e);
            this.status = 'Error!';
            this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static'
            });
        }
    };
    UtilityListComponent.prototype.isInterpolable = function (attributeLevels) {
        var interpolable = true;
        for (var i in attributeLevels) {
            if (isNaN(Number(attributeLevels[i]))) {
                interpolable = false;
            }
        }
        return interpolable;
    };
    UtilityListComponent.prototype.deleteUtility = function (targetModal) {
        var _this = this;
        this.connectService.doGet('api/utility/delete/' + this.utility.id).subscribe(function (response) {
            _this.status = 'Successfully deleted!';
            _this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static',
                size: 'sm'
            });
        }, function (error) {
            _this.status = 'Error!';
            _this.modalService.open(targetModal, {
                centered: true,
                backdrop: 'static',
                size: 'sm'
            });
        });
        // update utility list
        this.utlSvc.removeUtility(this.utility.id);
        this.utilityForm = this.formBuilder.group({
            utilityName: [''],
            priceAtt: [''],
            productLimit: [''],
            formula: [''],
            utilityAdj: [''],
            noneWeight: [''],
            disableWeight: [false],
            disableElasticity: [false]
        });
    };
    UtilityListComponent.prototype.refreshUtilities = function () {
        var _this = this;
        this.spinner.show();
        this.utlService.updateUtilityList().then(function (e) {
            _this.spinner.hide();
        });
    };
    UtilityListComponent.prototype.openProhibitions = function (targetModal) {
        if ((this.selectedLevel2 !== undefined) && (this.selectedLevel2 !== undefined)) {
            this.getProhibitTable();
        }
        this.modalService.open(targetModal, {
            centered: true,
            backdrop: 'static',
            size: 'lg'
        });
    };
    UtilityListComponent.prototype.getProhibitTable = function () {
        var _this = this;
        this.utlService.getAttributeLevels(this.selectedLevel1, this.selectedLevel2, this.utility.utl_xml);
        setTimeout(function () {
            for (var _i = 0, _a = _this.utlService.levelCombi; _i < _a.length; _i++) {
                var level = _a[_i];
                for (var _b = 0, level_1 = level; _b < level_1.length; _b++) {
                    var prohibitVar = level_1[_b];
                    if (_this.prohibitionChecked(prohibitVar)) {
                        document.getElementById(prohibitVar).checked = true;
                    }
                }
            }
        }, 200);
    };
    UtilityListComponent.prototype.rowIsInterpolable = function (index) {
        return this.utlService.productSensitivityIds.has(index);
    };
    UtilityListComponent.prototype.rowIsInterpolable2 = function (index) {
        return this.utlService.productSensitivityIdsB.has(index);
    };
    UtilityListComponent.prototype.setProhibition = function (prohibitVar) {
        var index = this.utlService.prohibitionListB.indexOf(prohibitVar);
        var index2 = this.utlService.phAttriListB.indexOf([this.selectedLevel1, this.selectedLevel2]);
        if (!this.prohibitionChecked(prohibitVar)) {
            this.utlService.phAttriListB.push(new Array(this.selectedLevel1, this.selectedLevel2));
            this.utlService.prohibitionListB.push(prohibitVar.split(' | '));
            document.getElementById(prohibitVar).checked = true;
        }
        else {
            this.utlService.phAttriListB.splice(index2, 1);
            this.utlService.prohibitionListB.splice(index, 1);
            document.getElementById(prohibitVar).checked = false;
        }
    };
    UtilityListComponent.prototype.saveProhibition = function (targetModal) {
        this.status = 'Prohibition saved';
        this.modalService.open(targetModal, {
            centered: true,
            backdrop: 'static',
            size: 'sm'
        });
    };
    UtilityListComponent.prototype.prohibitionChecked = function (prohibitVar) {
        var checked = true;
        var temp = prohibitVar.split(' | ');
        for (var _i = 0, _a = Object.values(this.utlService.prohibitionListB); _i < _a.length; _i++) {
            var value = _a[_i];
            checked = true;
            for (var i in temp) {
                if (value.indexOf(temp[i].toString()) === -1) {
                    checked = false;
                }
            }
            if (checked) {
                return true;
            }
        }
        if (this.utlService.prohibitionListB.length === 0) {
            checked = false;
        }
        return checked;
    };
    UtilityListComponent.prototype.clearData = function () {
        this.utlService.file = null;
        this.utlService.dataSet = new Array();
        this.utlService.message = '';
        this.errorRows = new Set();
    };
    UtilityListComponent.prototype.rowHasError = function (id) {
        return this.errorRows.has(id);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('spreadsheet'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], UtilityListComponent.prototype, "spreadsheet", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('utilitySheet'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], UtilityListComponent.prototype, "utilitysheet", void 0);
    UtilityListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-utility-list',
            template: __webpack_require__(/*! ./utility-list.component.html */ "./src/app/utility/utility-list/utility-list.component.html"),
            styles: [__webpack_require__(/*! ./utility-list.component.css */ "./src/app/utility/utility-list/utility-list.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_utilitymanagement_service__WEBPACK_IMPORTED_MODULE_2__["UtilitymanagementService"],
            _service_utilities_service__WEBPACK_IMPORTED_MODULE_3__["UtilitiesService"],
            ngx_spinner__WEBPACK_IMPORTED_MODULE_10__["NgxSpinnerService"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbModal"],
            _connection_service__WEBPACK_IMPORTED_MODULE_8__["ConnectionService"],
            _service_user_auth_service__WEBPACK_IMPORTED_MODULE_11__["UserAuthService"],
            _service_utility_service__WEBPACK_IMPORTED_MODULE_13__["UtilityService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_12__["Router"]])
    ], UtilityListComponent);
    return UtilityListComponent;
}());



/***/ }),

/***/ "./src/app/utility/utility.module.ts":
/*!*******************************************!*\
  !*** ./src/app/utility/utility.module.ts ***!
  \*******************************************/
/*! exports provided: UtilityModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilityModule", function() { return UtilityModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _utility_list_utility_list_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utility-list/utility-list.component */ "./src/app/utility/utility-list/utility-list.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-spinner */ "./node_modules/ngx-spinner/fesm5/ngx-spinner.js");
/* harmony import */ var angular_split__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! angular-split */ "./node_modules/angular-split/fesm5/angular-split.js");









var UtilityModule = /** @class */ (function () {
    function UtilityModule() {
    }
    UtilityModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_utility_list_utility_list_component__WEBPACK_IMPORTED_MODULE_3__["UtilityListComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbModule"],
                ngx_spinner__WEBPACK_IMPORTED_MODULE_7__["NgxSpinnerModule"],
                angular_split__WEBPACK_IMPORTED_MODULE_8__["AngularSplitModule"]
            ],
            exports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"]
            ]
        })
    ], UtilityModule);
    return UtilityModule;
}());



/***/ }),

/***/ "./src/app/utility/utilitymanagement.service.ts":
/*!******************************************************!*\
  !*** ./src/app/utility/utilitymanagement.service.ts ***!
  \******************************************************/
/*! exports provided: UtilitymanagementService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilitymanagementService", function() { return UtilitymanagementService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _service_utility_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/utility.service */ "./src/app/service/utility.service.ts");
/* harmony import */ var _service_utilities_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service/utilities.service */ "./src/app/service/utilities.service.ts");
/* harmony import */ var read_excel_file__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! read-excel-file */ "./node_modules/read-excel-file/index.js");
/* harmony import */ var xml2js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! xml2js */ "./node_modules/xml2js/lib/xml2js.js");
/* harmony import */ var xml2js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(xml2js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _connection_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../connection.service */ "./src/app/connection.service.ts");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! util */ "./node_modules/util/util.js");
/* harmony import */ var util__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(util__WEBPACK_IMPORTED_MODULE_7__);








var UtilitymanagementService = /** @class */ (function () {
    function UtilitymanagementService(utilityService, utlService, connectionService, utlSvc) {
        this.utilityService = utilityService;
        this.utlService = utlService;
        this.connectionService = connectionService;
        this.utlSvc = utlSvc;
        // SEGMENT TYPE KEY (For an Excel import)
        this.SEGMENT_TYPE = '1';
        // WEIGHT TYPE KEY (For an Excel import)
        this.WEIGHT_TYPE = '2';
        // TUNE TYPE KEY (For an Excel import)
        this.TUNE_TYPE = '3';
        // ATTRIBUTE TYPE KEY (Relative to other products - For an Excel import)
        this.ATTRIBUTE_TYPE_1 = '4';
        // ATTRIBUTE TYPE KEY (Relative to ideal - For an Excel import)
        this.ATTRIBUTE_TYPE_2 = '5';
        // ID KEY (For an Excel import)
        this.ID = 6;
        // Interpolated Values
        this.interpolatedValues = new Map();
        this.data = [];
        this.message = '';
        this.productSensitivityIds = new Set();
        this.productSensitivityIdsB = new Set();
        // this.utilityService.cast.subscribe(utility => this.utility = utility);
        this.prohibitionList = new Array();
        this.prohibitionListB = new Array();
        this.phAttriList = new Array();
        this.phAttriListB = new Array();
        this.priceSensiAtt = new Array();
        this.priceSensiAttB = new Array();
        this.priceAtt = '';
        this.priceAttB = '';
    }
    UtilitymanagementService.prototype.onFileChange = function (evt) {
        var _this = this;
        document.getElementById('checkingConsole').style.backgroundColor = 'white';
        this.dataSet = new Array();
        this.utilityData = new Array();
        this.file = evt.target.files[0];
        this.segments = new Map();
        this.message = '';
        Object(read_excel_file__WEBPACK_IMPORTED_MODULE_4__["default"])(this.file).then(function (rows) {
            _this.dataSet = rows;
        });
    };
    UtilitymanagementService.prototype.parseXMLFile = function (data) {
        var _this = this;
        this.segmentSet = new Array();
        this.productSet = new Array();
        this.productSet2 = new Array();
        this.priceSensiAtt = new Array();
        this.prohibitionList = new Array();
        this.attLevels = new Array();
        this.productCol = new Map();
        this.productCol2 = new Map();
        this.productSensitivityIds = new Set();
        var attributeLevels = new Array();
        var attributeLevels2 = new Array();
        xml2js__WEBPACK_IMPORTED_MODULE_5___default.a.parseString(data, { explicitArray: false }, function (error, result) {
            _this.utilityName = result.utility.$.name;
            _this.priceAtt = result.utility.sensitivityAccess.sensitivitySelected;
            _this.productLimit = result.utility.$.maxProductInSimulation;
            _this.formula = result.utility.$.formulaType;
            _this.utilityAdj = result.utility.$.adjustement;
            _this.noneMultiplicator = result.utility.$.noneMultiplicator;
            _this.disableWeight = result.utility.$.weightDisabled;
            _this.disableElasticity = result.utility.$.elasticityDisabled;
            _this.perfectValue = result.utility.$.perfectValue;
            /* Parse references */
            for (var i in result.utility.references) {
                var segArray = new Array();
                var segment = '';
                for (var n in result.utility.references[i]) {
                    var temp = result.utility.references[i][n];
                    var cnt = 0;
                    if (temp.$.cell_0 === _this.TUNE_TYPE) {
                        _this.tunePosition = Number(n);
                    }
                    else if (temp.$.cell_0 === _this.WEIGHT_TYPE) {
                        _this.weightPosition = Number(n);
                    }
                    else if (temp.$.cell_0 === _this.SEGMENT_TYPE) {
                        do {
                            // const first = false;
                            var cell = 'cell_3_' + cnt;
                            if (temp.$[cell] !== undefined) {
                                if (temp.$.cell_0 === '1' && segment === '') {
                                    segment = temp.$.cell_1;
                                    segArray.push(segment);
                                    segArray.push(temp.$[cell]);
                                }
                                else if (temp.$.cell_0 === '1' && temp.$.cell_1 === segment) {
                                    segArray.push(temp.$[cell]);
                                }
                                else if (temp.$.cell_0 === '1' && temp.$.cell_1 !== segment) {
                                    _this.segmentSet.push(segArray);
                                    segment = temp.$.cell_1;
                                    segArray = new Array();
                                    segArray.push(segment);
                                    segArray.push(temp.$[cell]);
                                }
                            }
                            cnt++;
                        } while (temp.$['cell_3_' + cnt] || Object.entries(temp.$).length - 1 > cnt);
                    }
                    else if (temp.$.cell_0 === _this.ATTRIBUTE_TYPE_1 && temp.$.cell_1 !== 'None') {
                        // BAD CODE change it!
                        if (!Object(util__WEBPACK_IMPORTED_MODULE_7__["isNull"])(segArray)) {
                            _this.segmentSet.push(segArray);
                            segArray = null;
                        }
                        if (_this.productSet.indexOf(temp.$.cell_1) === -1 && attributeLevels.length === 0) {
                            _this.productSet.push(temp.$.cell_1);
                            attributeLevels.push(temp.$.cell_2);
                        }
                        else if (_this.productSet.indexOf(temp.$.cell_1) === -1 && attributeLevels.length > 0) {
                            _this.attLevels.push(attributeLevels);
                            _this.productCol.set(Number(n) - (attributeLevels.length - 1), attributeLevels);
                            attributeLevels = new Array();
                            _this.productSet.push(temp.$.cell_1);
                            attributeLevels.push(temp.$.cell_2);
                        }
                        else {
                            attributeLevels.push(temp.$.cell_2);
                        }
                    }
                    else if (temp.$.cell_0 === _this.ATTRIBUTE_TYPE_1 && temp.$.cell_1 === 'None') {
                        _this.productCol.set((Number(n) - (attributeLevels.length - 1)), attributeLevels);
                        _this.attLevels.push(attributeLevels);
                        _this.nonePosition = Number(n) + 1;
                    }
                    else if (temp.$.cell_0 === _this.ATTRIBUTE_TYPE_2) {
                        if (_this.productSet2.indexOf(temp.$.cell_1) === -1 && attributeLevels2.length === 0) {
                            _this.productSet2.push(temp.$.cell_1);
                            attributeLevels2.push(temp.$.cell_2);
                        }
                        else if (_this.productSet2.indexOf(temp.$.cell_1) === -1 && attributeLevels2.length > 0) {
                            _this.productCol2.set(Number(n) - (attributeLevels2.length - 1), attributeLevels2);
                            attributeLevels2 = new Array();
                            _this.productSet2.push(temp.$.cell_1);
                            attributeLevels2.push(temp.$.cell_2);
                        }
                        else {
                            attributeLevels2.push(temp.$.cell_2);
                        }
                    }
                }
            }
            // Set contact data
            _this.setContacts(result.utility.values);
            /* Parse sensitivityAccess */
            var temp2 = result.utility.sensitivityAccess.$;
            // this.productSensitivityIds.add(0);
            // this.priceSensiAtt.push('No price sensitivity');
            for (var i in temp2) {
                _this.productSensitivityIds.add(Number(temp2[i]));
                _this.priceSensiAtt.push(_this.productSet[Number(temp2[i])]);
            }
            /* Parse phb*/
            if (!Object(util__WEBPACK_IMPORTED_MODULE_7__["isUndefined"])(result.utility.phb)) {
                if (!Object(util__WEBPACK_IMPORTED_MODULE_7__["isUndefined"])(result.utility.phb.ph)) {
                    var phb = result.utility.phb.ph;
                    if (phb.length !== undefined) {
                        for (var ph in phb) {
                            _this.phAttriList.push(new Array(phb[ph].$.a1, phb[ph].$.a2));
                            _this.prohibitionList.push(new Array(phb[ph].cb.$.b1, phb[ph].cb.$.b2));
                        }
                    }
                    else {
                        _this.phAttriList.push(new Array(phb.$.a1, phb.$.a2));
                        _this.prohibitionList.push(new Array(phb.cb.$.b1, phb.cb.$.b2));
                    }
                }
            }
            // console.log('Prohibition list:', this.prohibitionList);
            // tslint:disable-next-line:forin
            for (var i in _this.productSet) {
                _this.productSet[i] = [_this.productSet[i]];
            }
            // this.segmentSet = this.segmentSet[0].map((col, i) => this.segmentSet.map(row => row[i]));
            var maxLen = _this.segmentSet.reduce(function (max, _a) {
                var length = _a.length;
                return Math.max(max, length);
            }, 0);
            _this.segmentSet = Array.from({ length: maxLen }, function (_, i) { return _this.segmentSet.map(function (row) { return row[i]; }); });
        });
    };
    UtilitymanagementService.prototype.parseXMLFile2 = function (data) {
        var _this = this;
        this.segmentSetB = new Array();
        this.productSetB = new Array();
        this.productSet2B = new Array();
        this.priceSensiAttB = new Array();
        this.prohibitionListB = new Array();
        this.attLevelsB = new Array();
        this.productColB = new Map();
        this.productCol2B = new Map();
        var attributeLevels = new Array();
        var attributeLevels2 = new Array();
        xml2js__WEBPACK_IMPORTED_MODULE_5___default.a.parseString(data, { explicitArray: false }, function (error, result) {
            _this.utilityNameB = result.utility.$.name;
            _this.priceAttB = result.utility.sensitivityAccess.sensitivitySelected;
            _this.productLimitB = result.utility.$.maxProductInSimulation;
            _this.formulaB = result.utility.$.formulaType;
            _this.utilityAdjB = result.utility.$.adjustement;
            _this.noneMultiplicatorB = result.utility.$.noneMultiplicator;
            _this.disableWeightB = result.utility.$.weightDisabled;
            _this.disableElasticityB = result.utility.$.elasticityDisabled;
            _this.perfectValueB = result.utility.$.perfectValue;
            /* Parse references */
            for (var i in result.utility.references) {
                var segArray = new Array();
                var segment = '';
                for (var n in result.utility.references[i]) {
                    var temp = result.utility.references[i][n];
                    var cnt = 0;
                    if (temp.$.cell_0 === _this.TUNE_TYPE) {
                        _this.tunePosition = Number(n);
                    }
                    else if (temp.$.cell_0 === _this.WEIGHT_TYPE) {
                        _this.weightPosition = Number(n);
                    }
                    else if (temp.$.cell_0 === _this.SEGMENT_TYPE) {
                        do {
                            // const first = false;
                            var cell = 'cell_3_' + cnt;
                            if (temp.$[cell] !== undefined) {
                                if (temp.$.cell_0 === '1' && segment === '') {
                                    segment = temp.$.cell_1;
                                    segArray.push(segment);
                                    segArray.push(temp.$[cell]);
                                }
                                else if (temp.$.cell_0 === '1' && temp.$.cell_1 === segment) {
                                    segArray.push(temp.$[cell]);
                                }
                                else if (temp.$.cell_0 === '1' && temp.$.cell_1 !== segment) {
                                    _this.segmentSetB.push(segArray);
                                    segment = temp.$.cell_1;
                                    segArray = new Array();
                                    segArray.push(segment);
                                    segArray.push(temp.$[cell]);
                                }
                            }
                            cnt++;
                        } while (temp.$['cell_3_' + cnt] || Object.entries(temp.$).length - 1 > cnt);
                    }
                    else if (temp.$.cell_0 === _this.ATTRIBUTE_TYPE_1 && temp.$.cell_1 !== 'None') {
                        // BAD CODE change it!
                        if (!Object(util__WEBPACK_IMPORTED_MODULE_7__["isNull"])(segArray)) {
                            _this.segmentSetB.push(segArray);
                            segArray = null;
                        }
                        if (_this.productSetB.indexOf(temp.$.cell_1) === -1 && attributeLevels.length === 0) {
                            _this.productSetB.push(temp.$.cell_1);
                            attributeLevels.push(temp.$.cell_2);
                        }
                        else if (_this.productSetB.indexOf(temp.$.cell_1) === -1 && attributeLevels.length > 0) {
                            _this.attLevelsB.push(attributeLevels);
                            _this.productColB.set(Number(n) - (attributeLevels.length - 1), attributeLevels);
                            attributeLevels = new Array();
                            _this.productSetB.push(temp.$.cell_1);
                            attributeLevels.push(temp.$.cell_2);
                        }
                        else {
                            attributeLevels.push(temp.$.cell_2);
                        }
                    }
                    else if (temp.$.cell_0 === _this.ATTRIBUTE_TYPE_1 && temp.$.cell_1 === 'None') {
                        _this.productColB.set((Number(n) - (attributeLevels.length - 1)), attributeLevels);
                        _this.attLevelsB.push(attributeLevels);
                        _this.nonePositionB = Number(n) + 1;
                    }
                    else if (temp.$.cell_0 === _this.ATTRIBUTE_TYPE_2) {
                        if (_this.productSet2B.indexOf(temp.$.cell_1) === -1 && attributeLevels2.length === 0) {
                            _this.productSet2B.push(temp.$.cell_1);
                            attributeLevels2.push(temp.$.cell_2);
                        }
                        else if (_this.productSet2B.indexOf(temp.$.cell_1) === -1 && attributeLevels2.length > 0) {
                            _this.productCol2B.set(Number(n) - (attributeLevels2.length - 1), attributeLevels2);
                            attributeLevels2 = new Array();
                            _this.productSet2B.push(temp.$.cell_1);
                            attributeLevels2.push(temp.$.cell_2);
                        }
                        else {
                            attributeLevels2.push(temp.$.cell_2);
                        }
                    }
                }
            }
            // console.log('Position: ', this.tunePosition, this.weightPosition, this.utilityAdj, this.nonePosition, this.priceAtt);
            // Set contact data
            _this.setContacts(result.utility.values);
            /* Parse sensitivityAccess */
            var temp2 = result.utility.sensitivityAccess.$;
            // this.productSensitivityIds.add(0);
            // this.priceSensiAtt.push('No price sensitivity');
            for (var i in temp2) {
                _this.productSensitivityIdsB.add(Number(temp2[i]));
                _this.priceSensiAttB.push(_this.productSetB[Number(temp2[i])]);
            }
            /* Parse phb*/
            if (!Object(util__WEBPACK_IMPORTED_MODULE_7__["isUndefined"])(result.utility.phb)) {
                if (!Object(util__WEBPACK_IMPORTED_MODULE_7__["isUndefined"])(result.utility.phb.ph)) {
                    var phb = result.utility.phb.ph;
                    if (phb.length !== undefined) {
                        for (var ph in phb) {
                            _this.phAttriListB.push(new Array(phb[ph].$.a1, phb[ph].$.a2));
                            _this.prohibitionListB.push(new Array(phb[ph].cb.$.b1, phb[ph].cb.$.b2));
                        }
                    }
                    else {
                        _this.phAttriListB.push(new Array(phb.$.a1, phb.$.a2));
                        _this.prohibitionListB.push(new Array(phb.cb.$.b1, phb.cb.$.b2));
                    }
                }
            }
            // console.log('Prohibition list:', this.prohibitionList);
            // tslint:disable-next-line:forin
            for (var i in _this.productSetB) {
                _this.productSetB[i] = [_this.productSetB[i]];
            }
            // this.segmentSet = this.segmentSet[0].map((col, i) => this.segmentSet.map(row => row[i]));
            var maxLen = _this.segmentSetB.reduce(function (max, _a) {
                var length = _a.length;
                return Math.max(max, length);
            }, 0);
            _this.segmentSetB = Array.from({ length: maxLen }, function (_, i) { return _this.segmentSetB.map(function (row) { return row[i]; }); });
        });
    };
    UtilitymanagementService.prototype.getAttributeLevels = function (attribute1, attribute2, data) {
        var _this = this;
        this.attLevels1 = new Array();
        this.attLevels2 = new Array();
        this.levelCombi = new Array();
        xml2js__WEBPACK_IMPORTED_MODULE_5___default.a.parseString(data, { explicitArray: false }, function (error, result) {
            /* Parse references */
            for (var i in result.utility.references) {
                for (var n in result.utility.references[i]) {
                    var temp = result.utility.references[i][n];
                    if (temp.$.cell_0 === _this.ATTRIBUTE_TYPE_1 && temp.$.cell_1 === attribute1[0]) {
                        _this.attLevels1.push(temp.$.cell_2);
                    }
                    else if (temp.$.cell_0 === _this.ATTRIBUTE_TYPE_1 && temp.$.cell_1 === attribute2[0]) {
                        _this.attLevels2.push(temp.$.cell_2);
                    }
                }
            }
        });
        for (var i in this.attLevels2) {
            var tempArray = new Array();
            for (var n in this.attLevels1) {
                tempArray.push(this.attLevels2[i].toString().concat(' | ' + this.attLevels1[n]));
            }
            this.levelCombi.push(tempArray);
        }
    };
    UtilitymanagementService.prototype.getPerfectValue = function () {
        var utlPattern = new RegExp('UTL(0[1-9]{1}|[1-9]{1}[0-9]{1})$');
        var maxList = new Array();
        for (var row in this.dataSet) {
            var maxSum = 0;
            var maxValue = 0;
            if (Number(row) > 3) {
                for (var cell in this.dataSet[row]) {
                    if (utlPattern.test(this.dataSet[0][cell].toString())) {
                        /* First attribute level */
                        if (this.dataSet[1][cell] !== null) {
                            maxSum += maxValue;
                            maxValue = this.dataSet[row][cell];
                        }
                        else {
                            if (maxValue < this.dataSet[row][cell]) {
                                maxValue = this.dataSet[row][cell];
                            }
                        }
                    }
                }
                maxList.push(maxSum + maxValue);
            }
        }
        var perfectProduct = 0;
        for (var i in maxList) {
            perfectProduct += maxList[i];
        }
        this.perfectValue = (perfectProduct / maxList.length) * 100 / 100;
    };
    UtilitymanagementService.prototype.updateUtilityList = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this.utlSvc.resetUtilities();
                        return [4 /*yield*/, this.connectionService.doGet('api/utilities/').subscribe(function (response) {
                                var utl = Object.values(response)[0];
                                var _loop_1 = function (i) {
                                    xml2js__WEBPACK_IMPORTED_MODULE_5___default.a.parseString(utl[i].utlXml, { explicitArray: false }, function (error, result) {
                                        _this.utlSvc.addUtilities(utl[i].id, utl[i].name, result.utility.$.name, utl[i].utlXml);
                                    });
                                };
                                // tslint:disable-next-line:prefer-for-of
                                for (var i = 0; i < utl.length; i++) {
                                    _loop_1(i);
                                }
                            }, function (error) {
                                console.log(error);
                            })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    UtilitymanagementService.prototype.clearProhibitionData = function () {
        // this.attLevels1 = new Array<any>();
        // this.attLevels2 = new Array<any>();
        // this.levelCombi = new Array();
        // this.prohibitionList = new Array();
        // this.phAttriList = new Array();
    };
    UtilitymanagementService.prototype.setContacts = function (data) {
        this.contacts = new Array();
        for (var row in data.col) {
            this.contacts[row] = new Array();
            var column = 0;
            var cell = 'cell_' + column;
            do {
                this.contacts[row].push(data.col[row].$[cell]);
                cell = 'cell_' + (column++);
            } while (data.col[row].$[cell]);
        }
    };
    UtilitymanagementService.prototype.getProductCol = function (product) {
        var columns = new Set();
        var i = 0;
        this.productCol.forEach(function (value, key) {
            if (value.indexOf(product.attributeValues[i].toString()) !== -1) {
                for (var n in value) {
                    if (value[n] === product.attributeValues[i]) {
                        columns.add(Number(key) + Number(n));
                        i++;
                    }
                }
            }
            else {
                columns.add(Number(key));
            }
        });
        return columns;
    };
    UtilitymanagementService.prototype.getIdealProductCol = function (product) {
        var columns = new Set();
        var i = 0;
        this.productCol2.forEach(function (value, key) {
            if (value.indexOf(product.attributeValues[i].toString()) !== -1) {
                for (var n in value) {
                    if (value[n] === product.attributeValues[i]) {
                        columns.add(Number(key) + Number(n));
                        i++;
                    }
                }
            }
            else {
                columns.add(Number(key));
            }
        });
        return columns;
    };
    UtilitymanagementService.prototype.getIdealRelativeResult = function (products) {
        var mean = new Array();
        var prodAverageList = new Array();
        var none = new Array();
        // Clear ideal interpolated value
        this.interpolatedValues = new Map();
        // Get average and none
        for (var n in products) {
            this.getAttributeValues(products[n], 2);
            var colList = this.getIdealProductCol(products[n]);
            var prodAverage = new Array();
            // Get average and none
            for (var row in this.contacts) {
                prodAverage[row] = 0;
                var attCnt = 0;
                for (var col in this.contacts[row]) {
                    if (colList.has(Number(col))) {
                        if (this.interpolatedValues.get(attCnt + '_' + products[n].attributeValues[attCnt])) {
                            // Interpolated
                            var temp = this.interpolatedValues.get(attCnt + '_' + products[n].attributeValues[attCnt]);
                            prodAverage[row] += Number(temp[row]) * parseFloat(this.utilityAdj) * parseFloat(this.contacts[row][this.tunePosition]);
                        }
                        else {
                            prodAverage[row] += Number(this.contacts[row][col]) * parseFloat(this.utilityAdj) * parseFloat(this.contacts[row][this.tunePosition]);
                        }
                        attCnt++;
                    }
                    else if (Number(col) === this.nonePosition) {
                        none.push(Number(this.contacts[row][col]) * parseFloat(this.utilityAdj) * parseFloat(this.contacts[row][this.tunePosition]));
                        // Push none
                        mean.push(Number(this.contacts[row][col]) * parseFloat(this.utilityAdj) * parseFloat(this.contacts[row][this.tunePosition]) * this.noneMultiplicator);
                    }
                }
            }
            prodAverageList[n] = prodAverage;
        }
        return prodAverageList;
    };
    UtilitymanagementService.prototype.getRelativeResult = function (products) {
        var mean = new Array();
        var prodAverageList = new Array();
        var none = new Array();
        // Clear interpolated value
        this.interpolatedValues = new Map();
        // Get average and none
        for (var n in products) {
            this.getAttributeValues(products[n], 1);
            var colList = this.getProductCol(products[n]);
            var prodAverage = new Array();
            // Get average and none
            for (var row in this.contacts) {
                prodAverage[row] = 0;
                var attCnt = 0;
                for (var col in this.contacts[row]) {
                    if (colList.has(Number(col))) {
                        if (this.interpolatedValues.get(attCnt + '_' + products[n].attributeValues[attCnt])) {
                            // Interpolated
                            var temp = this.interpolatedValues.get(attCnt + '_' + products[n].attributeValues[attCnt]);
                            prodAverage[row] += Number(temp[row]) * parseFloat(this.utilityAdj) * parseFloat(this.contacts[row][this.tunePosition]);
                        }
                        else {
                            prodAverage[row] += Number(this.contacts[row][col]) * parseFloat(this.utilityAdj) * parseFloat(this.contacts[row][this.tunePosition]);
                        }
                        attCnt++;
                    }
                    else if (Number(col) === this.nonePosition && none.length <= this.contacts.length) {
                        none.push(Number(this.contacts[row][col]) * parseFloat(this.utilityAdj) * parseFloat(this.contacts[row][this.tunePosition]));
                        // Push none
                        mean.push(Number(this.contacts[row][col]) * parseFloat(this.utilityAdj) * parseFloat(this.contacts[row][this.tunePosition]) * this.noneMultiplicator);
                    }
                }
            }
            prodAverageList[n] = prodAverage;
        }
        // Get mean
        for (var i in prodAverageList) {
            for (var n in prodAverageList[i]) {
                mean[n] += prodAverageList[i][n];
            }
        }
        for (var i in mean) {
            mean[i] = mean[i] / (prodAverageList.length + 1);
        }
        // Add none to the list
        prodAverageList.push(none);
        var sumExpList = [];
        var expList = [];
        // exp(utl[n] - mean)
        for (var i in prodAverageList) {
            var temp = [];
            for (var n in prodAverageList[i]) {
                temp[n] = Math.pow(2.71828182845904, (prodAverageList[i][n] - mean[n]));
                if (Object(util__WEBPACK_IMPORTED_MODULE_7__["isUndefined"])(sumExpList[n])) {
                    sumExpList[n] = temp[n];
                }
                else {
                    sumExpList[n] += temp[n];
                }
            }
            expList.push(temp);
        }
        // (exp[n] / sumExp) * 100
        var prefList = [];
        for (var i in expList) {
            var temp = new Array();
            for (var n in expList[i]) {
                temp.push(Number(((expList[i][n] / sumExpList[n]) * 100).toFixed(1)));
            }
            prefList.push(temp);
        }
        // Get total
        var prefSumList = new Array();
        for (var i in prefList) {
            var sum = 0;
            for (var n in prefList[i]) {
                sum += Number(prefList[i][n]);
            }
            prefSumList.push((sum / prefList[i].length).toFixed(1));
        }
        return prefList;
    };
    UtilitymanagementService.prototype.getSegmentValues = function (segmentPosition) {
        var segValues = new Array();
        for (var row in this.contacts) {
            for (var col in this.contacts[row]) {
                if (Number(col) === segmentPosition) {
                    segValues.push(this.contacts[row][col]);
                }
            }
        }
        return segValues;
    };
    UtilitymanagementService.prototype.getAttributeValues = function (product, attributeType) {
        var _this = this;
        var _loop_2 = function (n) {
            var i = 0;
            product.attribute.forEach(function (value, key) {
                // Check if index is interpolable
                if (_this.priceSensiAtt[n] === key && value.indexOf(product.attributeValues[Number(i)]) === -1) {
                    var pos = _this.getAttributePosition(value[0], attributeType);
                    var lowerPosition = _this.getLowerPosition(product.attributeValues[i], pos, attributeType);
                    var upperPosition = _this.getUpperPosition(product.attributeValues[i], pos, attributeType);
                    _this.interpolatedValues.set((i + '_' + product.attributeValues[i]), _this.addInterpolatedValue(product.attributeValues[i], lowerPosition, upperPosition, value[lowerPosition - pos], value[upperPosition - pos]));
                }
                i++;
            });
        };
        for (var n in this.priceSensiAtt) {
            _loop_2(n);
        }
    };
    UtilitymanagementService.prototype.getAttributePosition = function (attribute, attributeType) {
        var pos = 0;
        if (attributeType === 1) {
            this.productCol.forEach(function (value, key) {
                if (value[0] === attribute.toString()) {
                    pos = key;
                }
            });
        }
        else if (attributeType === 2) {
            this.productCol2.forEach(function (value, key) {
                if (value[0] === attribute.toString()) {
                    pos = key;
                }
            });
        }
        return pos;
    };
    UtilitymanagementService.prototype.getLowerPosition = function (value, pos, attributeType) {
        var lowerPos = null;
        if (attributeType === 1) {
            this.productCol.forEach(function (val, key) {
                if (Number(key) === Number(pos)) {
                    for (var n in val) {
                        if (val[n] < Number(value)) {
                            lowerPos = Number(key) + Number(n);
                        }
                    }
                }
            });
        }
        else if (attributeType === 2) {
            this.productCol2.forEach(function (val, key) {
                if (Number(key) === Number(pos)) {
                    for (var n in val) {
                        if (val[n] < Number(value)) {
                            lowerPos = Number(key) + Number(n);
                        }
                    }
                }
            });
        }
        return lowerPos;
    };
    UtilitymanagementService.prototype.getUpperPosition = function (value, pos, attributeType) {
        var upperPos = null;
        if (attributeType === 1) {
            this.productCol.forEach(function (val, key) {
                if (Number(key) === Number(pos)) {
                    for (var n in val) {
                        if (val[n] > Number(value) && upperPos === null) {
                            upperPos = Number(key) + Number(n);
                        }
                    }
                }
            });
        }
        else if (attributeType === 2) {
            this.productCol2.forEach(function (val, key) {
                if (Number(key) === Number(pos)) {
                    for (var n in val) {
                        if (val[n] > Number(value) && upperPos === null) {
                            upperPos = Number(key) + Number(n);
                        }
                    }
                }
            });
        }
        return upperPos;
    };
    UtilitymanagementService.prototype.addInterpolatedValue = function (attributeLevel, lowerPosition, upperPosition, lowerN, upperN) {
        var value = new Array();
        var diffTt = Number(upperN) - Number(lowerN);
        var diffInf = Number(attributeLevel) - Number(lowerN);
        for (var row in this.contacts) {
            var lowerV = Number(this.contacts[row][lowerPosition]);
            var upperV = Number(this.contacts[row][upperPosition]);
            var diffV = upperV - lowerV;
            // console.log(lowerV, upperV, diffTt, diffInf);
            var v = diffInf * diffV;
            v = v / diffTt;
            value.push(Number((v + lowerV).toFixed(2)));
        }
        return value;
    };
    UtilitymanagementService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_service_utility_service__WEBPACK_IMPORTED_MODULE_2__["UtilityService"], _service_utilities_service__WEBPACK_IMPORTED_MODULE_3__["UtilitiesService"], _connection_service__WEBPACK_IMPORTED_MODULE_6__["ConnectionService"], _service_utilities_service__WEBPACK_IMPORTED_MODULE_3__["UtilitiesService"]])
    ], UtilitymanagementService);
    return UtilitymanagementService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! hammerjs */ "./node_modules/hammerjs/hammer.js");
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\PROJECTS\simprov2 - Copy\src\main.ts */"./src/main.ts");


/***/ }),

/***/ 1:
/*!**********************!*\
  !*** util (ignored) ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 2:
/*!**********************!*\
  !*** util (ignored) ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 3:
/*!************************!*\
  !*** buffer (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 4:
/*!************************!*\
  !*** crypto (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 5:
/*!********************!*\
  !*** fs (ignored) ***!
  \********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 6:
/*!************************!*\
  !*** crypto (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 7:
/*!************************!*\
  !*** stream (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map