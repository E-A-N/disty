(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[7],{

/***/ "./node_modules/browser-fs-access/dist/legacy/file-open.mjs":
/*!******************************************************************!*\
  !*** ./node_modules/browser-fs-access/dist/legacy/file-open.mjs ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(__webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// @license © 2020 Google LLC. Licensed under the Apache License, Version 2.0.
/* harmony default export */ __webpack_exports__["default"] = (async(e={})=>new Promise(((t,n)=>{const i=document.createElement("input");i.type="file";const s=[...e.mimeTypes?e.mimeTypes:[],e.extensions?e.extensions:[]].join();i.multiple=e.multiple||!1,i.accept=s||"*/*";const o=()=>{window.removeEventListener("focus",o),0===i.files.length&&n(new DOMException("The user aborted a request.","AbortError"))};i.addEventListener("click",(()=>{window.addEventListener("focus",o,!0)})),i.addEventListener("change",(()=>{t(i.multiple?i.files:i.files[0])})),i.click()})));

/***/ })

}]);
//# sourceMappingURL=7.js.map