(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[16],{

/***/ "./node_modules/browser-nativefs/dist/nativefs/file-open.mjs":
/*!*******************************************************************!*\
  !*** ./node_modules/browser-nativefs/dist/nativefs/file-open.mjs ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(__webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// @license © 2020 Google LLC. Licensed under the Apache License, Version 2.0.
const e=async e=>{const t=await e.getFile();return t.handle=e,t};/* harmony default export */ __webpack_exports__["default"] = (async(t={})=>{const i={};t.mimeTypes?t.mimeTypes.map((e=>{i[e]=t.extensions||[]})):i["*/*"]=t.extensions||[];const n=await window.showOpenFilePicker({types:[{description:t.description||"",accept:i}],multiple:t.multiple||!1}),s=await Promise.all(n.map(e));return t.multiple?s:s[0]});

/***/ })

}]);
//# sourceMappingURL=16.js.map