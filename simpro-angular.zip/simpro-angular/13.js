(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[13],{

/***/ "./node_modules/browser-nativefs/dist/nativefs-legacy/file-open.mjs":
/*!**************************************************************************!*\
  !*** ./node_modules/browser-nativefs/dist/nativefs-legacy/file-open.mjs ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(__webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// @license © 2020 Google LLC. Licensed under the Apache License, Version 2.0.
const e=async e=>{const t=await e.getFile();return t.handle=e,t};/* harmony default export */ __webpack_exports__["default"] = (async(t={})=>{const i=await window.chooseFileSystemEntries({accepts:[{description:t.description||"",mimeTypes:t.mimeTypes||["*/*"],extensions:t.extensions||[""]}],multiple:t.multiple||!1});return t.multiple?Promise.all(i.map(e)):e(i)});

/***/ })

}]);
//# sourceMappingURL=13.js.map