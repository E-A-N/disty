(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[6],{

/***/ "./node_modules/browser-fs-access/dist/legacy/directory-open.mjs":
/*!***********************************************************************!*\
  !*** ./node_modules/browser-fs-access/dist/legacy/directory-open.mjs ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(__webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// @license © 2020 Google LLC. Licensed under the Apache License, Version 2.0.
/* harmony default export */ __webpack_exports__["default"] = (async(e={})=>(e.recursive=e.recursive||!1,new Promise(((t,r)=>{const i=document.createElement("input");i.type="file",i.webkitdirectory=!0;const n=()=>{window.removeEventListener("focus",n),0===i.files.length&&r(new DOMException("The user aborted a request.","AbortError"))};i.addEventListener("click",(()=>{window.addEventListener("focus",n,!0)})),i.addEventListener("change",(()=>{let r=Array.from(i.files);e.recursive||(r=r.filter((e=>2===e.webkitRelativePath.split("/").length))),t(r)})),i.click()}))));

/***/ })

}]);
//# sourceMappingURL=6.js.map