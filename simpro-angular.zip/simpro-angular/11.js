(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[11],{

/***/ "./node_modules/browser-nativefs/dist/legacy/file-save.mjs":
/*!*****************************************************************!*\
  !*** ./node_modules/browser-nativefs/dist/legacy/file-save.mjs ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(__webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// @license © 2020 Google LLC. Licensed under the Apache License, Version 2.0.
/* harmony default export */ __webpack_exports__["default"] = (async(e,t={})=>{const c=document.createElement("a");c.download=t.fileName||"Untitled",c.href=URL.createObjectURL(e),c.addEventListener("click",(()=>{setTimeout((()=>URL.revokeObjectURL(c.href)),3e4)})),c.click()});

/***/ })

}]);
//# sourceMappingURL=11.js.map