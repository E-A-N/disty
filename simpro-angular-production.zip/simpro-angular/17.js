(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[17],{

/***/ "./node_modules/browser-nativefs/dist/nativefs/file-save.mjs":
/*!*******************************************************************!*\
  !*** ./node_modules/browser-nativefs/dist/nativefs/file-save.mjs ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(__webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// @license © 2020 Google LLC. Licensed under the Apache License, Version 2.0.
/* harmony default export */ __webpack_exports__["default"] = (async(e,t={},i=null)=>{t.fileName=t.fileName||"Untitled";const a={};t.mimeTypes?(t.mimeTypes.push(e.type),t.mimeTypes.map((e=>{a[e]=t.extensions||[]}))):a[e.type]=t.extensions||[],i=i||await window.showSaveFilePicker({types:[{description:t.description||"",accept:a}]});const s=await i.createWritable();return await s.write(e),await s.close(),i});

/***/ })

}]);
//# sourceMappingURL=17.js.map