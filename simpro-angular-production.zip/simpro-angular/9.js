(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[9],{

/***/ "./node_modules/browser-nativefs/dist/legacy/directory-open.mjs":
/*!**********************************************************************!*\
  !*** ./node_modules/browser-nativefs/dist/legacy/directory-open.mjs ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(__webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// @license © 2020 Google LLC. Licensed under the Apache License, Version 2.0.
/* harmony default export */ __webpack_exports__["default"] = (async(e={})=>(e.recursive=e.recursive||!1,new Promise((t=>{const r=document.createElement("input");r.type="file",r.webkitdirectory=!0,r.addEventListener("change",(()=>{let i=Array.from(r.files);e.recursive||(i=i.filter((e=>2===e.webkitRelativePath.split("/").length))),t(i)})),r.click()}))));

/***/ })

}]);
//# sourceMappingURL=9.js.map